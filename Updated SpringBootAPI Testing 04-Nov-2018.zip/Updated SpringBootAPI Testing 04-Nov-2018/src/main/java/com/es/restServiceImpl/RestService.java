package com.es.restServiceImpl;

import java.util.List;

public interface RestService {


public boolean isUserAuthenticated(String authentication);

}
