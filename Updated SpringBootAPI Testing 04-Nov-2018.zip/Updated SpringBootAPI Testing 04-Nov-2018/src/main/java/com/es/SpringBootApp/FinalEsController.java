package com.es.SpringBootApp;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.es.model.AttachCount;
import com.es.model.CandidateCount;
import com.es.model.JobModel;
import com.es.restServiceImpl.RestServiceImpl;

@RestController
public class FinalEsController {
	RestServiceImpl restService = new RestServiceImpl();
	RestTemplate restTemplate = new RestTemplate();
	String sortParam = "";
	String candidateObjectIds;

	/*
	 * Industry & Functional Area
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/ElasticAPI/getList")
	public @ResponseBody String getdata(@RequestParam("type") String type, @RequestHeader HttpHeaders headers)
			throws Exception {
		// if (!headers.containsKey("authorization")) {
		// System.out.println("No Authentication");
		// return "{\"error\":\"Please Provide The Authentication\"}";
		// }
		// String authString = headers.getFirst("authorization");
		// if (!restService.isUserAuthenticated(authString)) {
		// System.out.println("Wrong Authentication.....");
		// return "{\"error\":\"User not authenticated\"}";
		// }
		//
		String authString = headers.getFirst("token");

		String validity = CognitoAuthentication.getValidAuthentication(authString);

		if (validity.equals("valid")) {
			String urlAttach = "";

			String url = "";

			if (type.equalsIgnoreCase("industry")) {
				url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/industrydata/_search?default_operator=AND&q=(_id:\"1\")&size=200&from=0&_source=industry.id,industry.name";

				System.out.println("url..." + url);
				String json = restTemplate.getForObject(url, String.class);

				org.json.JSONObject jsonObject = new org.json.JSONObject(json).getJSONObject("hits")
						.getJSONArray("hits").getJSONObject(0).getJSONObject("_source");

				return jsonObject.toString();

			} else if (type.equalsIgnoreCase("functionalarea")) {
				url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/functionalarea/_search?default_operator=AND&q=(_id:\"1\")&size=200&from=0&_source=f_area.id,f_area.name";

				System.out.println("url..." + url);
				String json = restTemplate.getForObject(url, String.class);

				org.json.JSONObject jsonObject = new org.json.JSONObject(json).getJSONObject("hits")
						.getJSONArray("hits").getJSONObject(0).getJSONObject("_source");

				return jsonObject.toString();

			} else if (type.equalsIgnoreCase("industrycount")) {

				String result = "";
				JSONObject jsonMain = new JSONObject();

				String[] arr = { "NBFCs", "EPC", "CRS", "FMCD", "Automobile",
						"Business & Information,Manufacturing & Process", "Telecommunication", "Technology Services",
						"Shared Services", "Manufacturing & Process", "Energy,Power", "Utilities",
						"Industrial Goods & Services", "Legal", "Shared Services/BPO/KPO", "Pharmaceuticals",
						"Management Consulting", "Telecom Services,Telecommunication Services",
						"Business & Information", "Logistics & Warehousing", "Information Technology",
						"Technology Products", "Oil & Gas", "Investment Banking", "Technology",
						"E-Commerce,Technology Ecommerce,Travel & Tours", "Consumer Goods", "Construction",
						"Manufacturing & Process,FMCG" };

				for (String s : arr) {

					if (s.contains("&"))
						url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""
								+ s.replace("&", "") + "\")&size=10&from=0&pretty=true&_source=id,industry";// id,
					else
						url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""
								+ s + "\")&size=10&from=0&pretty=true&_source=id,industry";// id,

					result = restTemplate.getForObject(url, String.class);

					org.json.JSONObject jsonObject = new org.json.JSONObject(result).getJSONObject("hits");
					jsonMain.put(s, jsonObject.get("total"));
				}

				return jsonMain.toString();
			} else if (type.equalsIgnoreCase("university")) {

				String urlData = "";

				url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?size=10000&"
						+ "_source=education.ug.institute,education.pg.institute,education.doctorate.institute,"
						+ "education.diploma.institute,education.twelveth.institute,education.tenth.institute";

				System.out.println(url);
				urlData = restTemplate.getForObject(url, String.class);
				org.json.JSONObject response = new org.json.JSONObject();
				org.json.JSONObject universities = new org.json.JSONObject();

				HashSet<String> university = new HashSet<String>();
				HashSet<String> colleges = new HashSet<String>();
				HashSet<String> school = new HashSet<String>();

				org.json.JSONObject hits1 = new org.json.JSONObject(urlData).getJSONObject("hits");
				org.json.JSONArray hitsArr = hits1.getJSONArray("hits");

				for (int i = 0; i < hitsArr.length(); i++) {
					org.json.JSONObject arrobj = (org.json.JSONObject) hitsArr.get(i);
					org.json.JSONObject _source = arrobj.getJSONObject("_source");

					if (_source.has("education")) {
						org.json.JSONObject education = _source.getJSONObject("education");

						if (education.has("ug")) {
							org.json.JSONObject ug = education.getJSONObject("ug");
							if (ug.has("institute") && ug.getString("institute").toLowerCase().contains("university"))
								university.add(ug.getString("institute"));
							else if (ug.has("institute"))
								colleges.add(ug.getString("institute"));
						}
						if (education.has("pg")) {
							org.json.JSONObject pg = education.getJSONObject("pg");
							if (pg.has("institute") && pg.getString("institute").toLowerCase().contains("university"))
								university.add(pg.getString("institute"));
							else if (pg.has("institute"))
								colleges.add(pg.getString("institute"));
						}

						if (education.has("doctorate")) {
							org.json.JSONObject doctorate = education.getJSONObject("doctorate");
							if (doctorate.has("institute")
									&& doctorate.getString("institute").toLowerCase().contains("university"))
								university.add(doctorate.getString("institute"));
							else if (doctorate.has("institute"))
								colleges.add(doctorate.getString("institute"));
						}

						if (education.has("diploma")) {
							org.json.JSONObject diploma = education.getJSONObject("diploma");
							if (diploma.has("institute")
									&& diploma.getString("institute").toLowerCase().contains("university"))
								university.add(diploma.getString("institute"));
							else if (diploma.has("institute"))
								colleges.add(diploma.getString("institute"));
						}

						if (education.has("twelveth")) {
							org.json.JSONObject twelveth = education.getJSONObject("twelveth");
							if (twelveth.has("institute"))
								school.add(twelveth.getString("institute"));
						}

						if (education.has("tenth")) {
							org.json.JSONObject tenth = education.getJSONObject("tenth");
							if (tenth.has("institute"))
								school.add(tenth.getString("institute"));
						}

					}
				}

				universities.put("unversity", university);
				universities.put("college", colleges);
				universities.put("school", school);
				response.put("response", universities);

				return response.toString();
			} else if (type.equalsIgnoreCase("suggester")) {

				String urlData = "";

				url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?"
						+ "size=10000&_source=employment.current.organization,employment.previous.organization,"
						+ "skills.keySkill,experiencedIndustry";

				System.out.println(url);
				urlData = restTemplate.getForObject(url, String.class);

				org.json.JSONObject response = new org.json.JSONObject();
				org.json.JSONObject list = new org.json.JSONObject();
				HashSet<String> suggesterList = new HashSet<String>();

				org.json.JSONObject hits1 = new org.json.JSONObject(urlData).getJSONObject("hits");
				org.json.JSONArray hitsArr = hits1.getJSONArray("hits");

				for (int i = 0; i < hitsArr.length(); i++) {
					org.json.JSONObject arrobj = (org.json.JSONObject) hitsArr.get(i);
					org.json.JSONObject _source = arrobj.getJSONObject("_source");

					if (_source.has("skills")) {
						org.json.JSONArray skillList = (org.json.JSONArray) _source.get("skills");
						for (int j = 0; j < skillList.length(); j++) {
							org.json.JSONObject getskillobject = (org.json.JSONObject) skillList.get(j);
							if (getskillobject.has("keySkill"))
								suggesterList.add(getskillobject.getString("keySkill"));
						}
					}

					if (_source.has("experiencedIndustry"))
						suggesterList.add(_source.getString("experiencedIndustry"));

					if (_source.has("employment")) {
						org.json.JSONObject employment = _source.getJSONObject("employment");

						if (employment.has("current")) {
							org.json.JSONObject current = employment.getJSONObject("current");
							if (current.has("organization"))
								suggesterList.add(current.getString("organization"));
						}

						if (employment.has("previous")) {
							org.json.JSONArray previous = employment.getJSONArray("previous");
							for (int j = 0; j < previous.length(); j++) {
								org.json.JSONObject jsonprevious = (org.json.JSONObject) previous.get(j);
								if (jsonprevious.has("organization"))
									suggesterList.add(jsonprevious.getString("organization"));
							}
						}
					}
				}

				url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?"
						+ "size=10000&_source=jobName";

				System.out.println(url);
				urlData = restTemplate.getForObject(url, String.class);

				hits1 = new org.json.JSONObject(urlData).getJSONObject("hits");
				hitsArr = hits1.getJSONArray("hits");

				for (int i = 0; i < hitsArr.length(); i++) {
					org.json.JSONObject arrobj = (org.json.JSONObject) hitsArr.get(i);
					org.json.JSONObject _source = arrobj.getJSONObject("_source");

					if (_source.has("jobName"))
						suggesterList.add(_source.getString("jobName"));

				}
				list.put("suggesterList", suggesterList);
				response.put("response", list);

				return response.toString();

			}
		} else {
			return validity;
		}

		return "{}";
	}

	/*
	 * 
	 * Audit Logs APIs
	 * 
	 */

	@RequestMapping(value = "/ElasticAPI/getauditdata", method = { RequestMethod.POST })
	public @ResponseBody String auditSearch(@RequestBody String field, @RequestParam("id") String id,
			@RequestParam("audit") String audit, @RequestParam("perpage") Integer perpage,
			@RequestParam("next") Integer next, @RequestParam("sort") String sort, @RequestHeader HttpHeaders headers)
			throws MalformedURLException, URISyntaxException, ParseException, JSONException,
			UnsupportedEncodingException {

		// if (!headers.containsKey("authorization")) {
		// System.out.println("No Authentication");
		// return "{\"error\":\"Please Provide The Authentication\"}";
		// }
		// String authString = headers.getFirst("authorization");
		// if (!restService.isUserAuthenticated(authString)) {
		// System.out.println("Wrong Authentication.....");
		// return "{\"error\":\"User not authenticated\"}";
		// }
		String authString = headers.getFirst("token");
		String validity = CognitoAuthentication.getValidAuthentication(authString);
		if (validity.equals("valid")) {

			int start = perpage * (next - 1);
			String url = "";
			String search = "";

			if (audit.equalsIgnoreCase("attach"))
				url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attachaudit/_search?q=(attachID:\""
						+ id + "\")";
			else if (audit.equalsIgnoreCase("candidate"))
				url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidateaudit/_search?q=(objectID:\""
						+ id + "\")";

			/* search query */
			JSONParser parser = new JSONParser();

			org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) parser.parse(field);

			for (int i = 0; i < jsonArray.size(); i++) {

				org.json.simple.JSONObject json = (org.json.simple.JSONObject) jsonArray.get(i);

				String key = (String) json.get("key");
				json.remove("key");

				String jsonField = json.toString();

				jsonField = jsonField.replace("{", "").replace("}", "");

				if (key.equals("Begins With")) {

					jsonField = jsonField.replace("\":\"", ":").replace("\",\"", "*)AND(");
					if (jsonField.contains("AND"))
						jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";
					else
						jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + "*)";

				} else if (key.equals("Ends With")) {

					jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", ")AND(");
					if (jsonField.contains("AND"))
						jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "))";
					else
						jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + ")";

				} else if (key.equals("Contains")) {

					jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");
					if (jsonField.contains("AND"))
						jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";
					else
						jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + "*)";

				} else if (key.equals("Doesn't contain")) {

					jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");

					if (jsonField.contains("AND"))
						jsonField = "(NOT((" + jsonField.substring(1, jsonField.length() - 1) + "*)))";
					else
						jsonField = "(NOT(" + jsonField.substring(1, jsonField.length() - 1) + "*))";

				} else if (key.equals("Equal")) {

					jsonField = jsonField.replace("\":\"", ":\"").replace("\",\"", "\")AND(");
					if (jsonField.contains("AND"))
						jsonField = "((" + jsonField.substring(1, jsonField.length()) + "))";
					else
						jsonField = "(" + jsonField.substring(1, jsonField.length()) + ")";
				}

				search += "OR" + jsonField;
			}

			search = search.replaceFirst("OR", "");

			if (search.length() > 0)
				url += "AND(" + search + ")";

			if (!sort.equals("") && sort.endsWith("a"))
				sort = "&sort=" + sort.substring(0, sort.length() - 1) + ".keyword:" + "asc";
			else if (!sort.equals("") && sort.endsWith("d"))
				sort = "&sort=" + sort.substring(0, sort.length() - 1) + ".keyword:" + "desc";

			url += "&size=" + perpage + "&from=" + start + sort;

			if (audit.equalsIgnoreCase("attach"))
				url += "&pretty=true&_source=id,attachID,userName,field,oldValue,newValue,lastUpdated";
			else if (audit.equalsIgnoreCase("candidate"))
				url += "&pretty=true&_source=id,objectID,userName,field,oldValue,newValue,lastUpdated";

			String json = getAttachAudit(url);

			return json;
		} else{
			return validity;
		}

	}

	@SuppressWarnings("unchecked")
	public String getAttachAudit(String query) throws JSONException, URISyntaxException, MalformedURLException {

		System.out.println("query..." + query);

		String jsonAttachData = restTemplate.getForObject(query, String.class);

		org.json.JSONObject mainjson = new org.json.JSONObject();

		org.json.JSONArray jsonArray = new org.json.JSONArray();

		org.json.JSONObject jsonAttach = new org.json.JSONObject(jsonAttachData);
		org.json.JSONObject jobhits = jsonAttach.getJSONObject("hits");

		org.json.JSONArray jobhitsArr = jobhits.getJSONArray("hits");

		for (int i = 0; i < jobhitsArr.length(); i++) {

			JSONObject subJson = new JSONObject();

			org.json.JSONObject arrobj = (org.json.JSONObject) jobhitsArr.get(i);
			org.json.JSONObject arrobj1 = arrobj.getJSONObject("_source");

			if (arrobj1.has("id"))
				subJson.put("id", arrobj1.get("id"));
			else
				subJson.put("id", org.json.JSONObject.NULL);

			if (query.contains("attachID"))
				if (arrobj1.has("attachID"))
					subJson.put("attachID", arrobj1.get("attachID"));
				else
					subJson.put("attachID", org.json.JSONObject.NULL);

			if (query.contains("objectID"))
				if (arrobj1.has("objectID"))
					subJson.put("objectID", arrobj1.get("objectID"));
				else
					subJson.put("objectID", org.json.JSONObject.NULL);

			if (arrobj1.has("userName"))
				subJson.put("userName", arrobj1.get("userName"));
			else
				subJson.put("userName", org.json.JSONObject.NULL);

			if (arrobj1.has("field"))
				subJson.put("field", arrobj1.get("field"));
			else
				subJson.put("field", org.json.JSONObject.NULL);

			if (arrobj1.has("oldValue"))
				subJson.put("oldValue", arrobj1.get("oldValue"));
			else
				subJson.put("oldValue", org.json.JSONObject.NULL);

			if (arrobj1.has("newValue"))
				subJson.put("newValue", arrobj1.get("newValue"));
			else
				subJson.put("newValue", org.json.JSONObject.NULL);

			if (arrobj1.has("lastUpdated"))
				subJson.put("lastUpdated", arrobj1.get("lastUpdated"));
			else
				subJson.put("lastUpdated", org.json.JSONObject.NULL);

			jsonArray.put(subJson);

		}

		mainjson.put("total", jobhits.get("total"));
		mainjson.put("response", jsonArray);

		return mainjson.toString();
	}

	/*
	 * 
	 * Attach APIs
	 * 
	 */

	@RequestMapping(value = "/ElasticAPI/getattachcandidatedata", method = { RequestMethod.POST })
	public @ResponseBody String externalAttachCandidateSearch(@RequestBody String field,
			@RequestParam("searchparam") String searchparam, @RequestParam("federated") String federated,
			@RequestParam("perpage") Integer perpage, @RequestParam("next") Integer next,
			@RequestParam("sort") String sort, @RequestHeader HttpHeaders headers ) throws MalformedURLException, URISyntaxException, ParseException,
			JSONException, UnsupportedEncodingException {
		
		String authString = headers.getFirst("token");
		String validity = CognitoAuthentication.getValidAuthentication(authString);
		if(validity.equals("valid")){
		
		
		
		ArrayList<AttachCount> list = new ArrayList<AttachCount>();
		list = attachSearch(searchparam, field, sort, federated);
		org.json.JSONObject obj = new org.json.JSONObject();
		org.json.JSONObject obj1 = new org.json.JSONObject();

		obj.put("attach", list);
		obj1.put("response", obj);

		System.out.println(obj1);
		String json = getFormattedJson(obj1.toString(), perpage, next);

		return json;
		}
		else{
		return validity;
	}

	}

	public ArrayList<CandidateCount> candidateSearch(String objectId, String sort, String candidateQuery,
			String federated) throws ParseException {

		ArrayList<CandidateCount> list = new ArrayList<CandidateCount>();
		String urlCandidate = "";

		if (federated.equalsIgnoreCase("linkedin"))
			urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/linkedincandidate/_search?q=((id:"
					+ objectId + "))";
		else
			urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=((id:"
					+ objectId + "))";

		if (candidateQuery.length() > 0)
			urlCandidate += "AND(" + candidateQuery + ")";

		if (sortParam.equals("candidate"))
			urlCandidate += sort;

		if (federated.equalsIgnoreCase("linkedin"))
			urlCandidate += "&size=1000&from=0&pretty=true&_source=id,name,first_name,middle_name,last_name,birthdate";
		else
			urlCandidate += "&size=1000&from=0&pretty=true&_source=id,name,first_name,middle_name,last_name,email,alternateEmail,birthdate,mobileNumber";

		System.out.println("urlCandidate>> " + urlCandidate);

		list = getCandidateList(urlCandidate);
		return list;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ArrayList<AttachCount> attachSearch(String searchparam, String field, String sort, String federated)
			throws ParseException {

		String urlAttach = "";

		String attachFields = "id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,"
				+ "lastModifiedBy,lastModified,createdDate,anchor,cvSentDate,statusChangeDate,statusOutcome,changeReason,"
				+ "federated,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,isClientSheet,"
				+ "ghStatus,ghStatusId,statusId,status,dropComment,comment,withOutId";
		String candidateFields = "id,name,first_name,middle_name,last_name,email,alternateEmail,birthdate,mobileNumber";

		ArrayList<AttachCount> list = new ArrayList<AttachCount>();
		ArrayList mainlist = new ArrayList();
		ArrayList<CandidateCount> canlist = new ArrayList<CandidateCount>();
		String attachQuery = "";
		String candidateQuery = "";
		JSONObject json = new JSONObject();

		if (searchparam.length() > 0) {
			if (searchparam.contains("createdDate")) {

				String range = searchparam.substring(searchparam.indexOf("createdDate"), searchparam.length());

				if (range.contains(";"))
					range = range.substring(0, range.indexOf(":"));
				searchparam.replace(range, "");

				searchparam = searchparam.replace(";" + range, "");
				searchparam = searchparam.replace(":", ":\"").replace(";", "\")AND(");

				range = range.replace("createdDate:", "createdDate:[\"").replace("TO", "\" TO \"");
				range += "\"]";
				System.out.println(range);
				searchparam += "\")AND(" + range;

				searchparam = "?q=(" + searchparam + ")";

			} else {
				searchparam = searchparam.replace(":", ":\"").replace(";", "\")AND(");
				searchparam = "?q=(" + searchparam + "\")";
			}
		}

		urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search"
				+ searchparam;

		if (federated.equalsIgnoreCase("linkedin"))
			urlAttach += "AND(federated:\"linkedIn\")";
		else if (federated.equalsIgnoreCase("externalportal"))
			urlAttach += "AND(ghStatus:\"Applied\")";
		else if (federated.equalsIgnoreCase("internal"))
			urlAttach += "AND(NOT(ghStatus:\"Applied\"))";

		/* search query */
		JSONParser parser = new JSONParser();

		JSONArray jsonArray = (JSONArray) parser.parse(field);

		for (int i = 0; i < jsonArray.size(); i++) {

			json = (JSONObject) jsonArray.get(i);

			String key = (String) json.get("key");
			json.remove("key");

			String jsonField = json.toString();

			jsonField = jsonField.replace("{", "").replace("}", "");

			if (key.equals("Begins With")) {

				jsonField = jsonField.replace("\":\"", ":").replace("\",\"", "*)AND(");
				if (jsonField.contains("AND"))
					jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";
				else
					jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + "*)";

			} else if (key.equals("Ends With")) {

				jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", ")AND(");
				if (jsonField.contains("AND"))
					jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "))";
				else
					jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + ")";

			} else if (key.equals("Contains")) {

				jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");
				if (jsonField.contains("AND"))
					jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";
				else
					jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + "*)";

			} else if (key.equals("Doesn't contain")) {

				jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");

				if (jsonField.contains("AND"))
					jsonField = "(NOT((" + jsonField.substring(1, jsonField.length() - 1) + "*)))";
				else
					jsonField = "(NOT(" + jsonField.substring(1, jsonField.length() - 1) + "*))";

			} else if (key.equals("Equal")) {

				jsonField = jsonField.replace("\":\"", ":\"").replace("\",\"", "\")AND(");
				if (jsonField.contains("AND"))
					jsonField = "((" + jsonField.substring(1, jsonField.length()) + "))";
				else
					jsonField = "(" + jsonField.substring(1, jsonField.length()) + ")";

			} else if (key.equals("DateRange")) {

				System.out.println(jsonField);
				jsonField = jsonField.replace("\":\"", ":\"").replace("TO", "\" TO \"");
				if (jsonField.contains("AND"))
					jsonField = "((" + jsonField.substring(1, jsonField.length()) + "))";
				else
					jsonField = "(" + jsonField.substring(1, jsonField.length()) + ")";

			}

			String check = jsonField.substring(0, jsonField.indexOf(":")).replace("(", "");

			if (check.startsWith("NOT"))
				check = check.substring(3);

			if (attachFields.contains(check)) {
				attachQuery += "OR" + jsonField;

			} else if (candidateFields.contains(check)) {
				candidateQuery += "OR" + jsonField;

			}
		}

		attachQuery = attachQuery.replaceFirst("OR", "");
		candidateQuery = candidateQuery.replaceFirst("OR", "");

		System.out.println(attachQuery);
		System.out.println(candidateQuery);

		if (attachQuery.length() > 0)
			urlAttach += "AND(" + attachQuery + ")";

		urlAttach += "&size=1000&from=0";

		if (!sort.equals("")) {
			if (attachFields.contains(sort.substring(0, sort.length() - 1))) {
				sortParam = "attach";
				if (!sort.equals("") && sort.endsWith("a"))
					sort = "&sort=" + sort.substring(0, sort.length() - 1) + ".keyword:" + "asc";
				else if (!sort.equals("") && sort.endsWith("d"))
					sort = "&sort=" + sort.substring(0, sort.length() - 1) + ".keyword:" + "desc";
				urlAttach += sort;

			} else if (candidateFields.contains(sort.substring(0, sort.length() - 1))) {
				sortParam = "candidate";
				if (!sort.equals("") && sort.endsWith("a"))
					sort = "&sort=" + sort.substring(0, sort.length() - 1) + ".keyword:" + "asc";
				else if (!sort.equals("") && sort.endsWith("d"))
					sort = "&sort=" + sort.substring(0, sort.length() - 1) + ".keyword:" + "desc";
			}
		}

		urlAttach += "&pretty=true&_source=" + attachFields;

		System.out.println("urlAttach>> " + urlAttach);

		list = getAttachList(urlAttach);

		mainlist.add(list);
		String ids = getCandidateObjectIds();
		ids = ids.replaceFirst(",", "");
		ids = ids.replace(",", ")OR(id:");

		if (ids.length() > 0)
			canlist = candidateSearch(ids, sort, candidateQuery, federated);

		mainlist.add(canlist);
		AttachCount attachCount = new AttachCount();
		attachCount.setCandidate(mainlist);

		return mainlist;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<CandidateCount> getCandidateList(String query) {

		ArrayList<CandidateCount> list = new ArrayList<CandidateCount>();
		try {

			JSONParser jsonParsercan = new JSONParser();

			String candidate = restTemplate.getForObject(query, String.class);
			org.json.simple.JSONObject jsoncan;

			jsoncan = (org.json.simple.JSONObject) ((org.json.simple.JSONObject) jsonParsercan.parse(candidate))
					.get("hits");

			org.json.simple.JSONArray arraycan = (org.json.simple.JSONArray) jsoncan.get("hits");
			@SuppressWarnings("rawtypes")
			Iterator itratorcan = arraycan.iterator();

			while (itratorcan.hasNext()) {
				CandidateCount cc = new CandidateCount();

				org.json.simple.JSONObject jsonObjectcan = (org.json.simple.JSONObject) itratorcan.next();
				jsonObjectcan = (org.json.simple.JSONObject) jsonObjectcan.get("_source");

				if (jsonObjectcan.get("id") != null)
					cc.setId((String) jsonObjectcan.get("id"));

				if (jsonObjectcan.get("name") != null)
					cc.setName((String) jsonObjectcan.get("name"));

				if (jsonObjectcan.get("first_name") != null)
					cc.setFirst_name((String) jsonObjectcan.get("first_name"));

				if (jsonObjectcan.get("middle_name") != null)
					cc.setMiddle_name((String) jsonObjectcan.get("middle_name"));

				if (jsonObjectcan.get("last_name") != null)
					cc.setLast_name((String) jsonObjectcan.get("last_name"));

				if (jsonObjectcan.get("email") != null)
					cc.setEmail((String) jsonObjectcan.get("email"));

				if (jsonObjectcan.get("alternateEmail") != null)
					cc.setAlternateEmail((List<String>) jsonObjectcan.get("alternateEmail"));

				if (jsonObjectcan.get("birthdate") != null)
					cc.setBirthdate((String) jsonObjectcan.get("birthdate"));

				if (jsonObjectcan.get("mobileNumber") != null)
					cc.setMobileNumber((String) jsonObjectcan.get("mobileNumber"));

				list.add(cc);
			}

		} catch (ParseException e1) {
			e1.printStackTrace();
		}

		return list;
	}

	public ArrayList<AttachCount> getAttachList(String query) {

		ArrayList<AttachCount> list = new ArrayList<AttachCount>();
		try {

			JSONParser jsonParserAttach = new JSONParser();
			String attach = restTemplate.getForObject(query, String.class);
			org.json.simple.JSONObject jsonAttach = (org.json.simple.JSONObject) ((org.json.simple.JSONObject) jsonParserAttach
					.parse(attach)).get("hits");

			org.json.simple.JSONArray arrayAtach = (org.json.simple.JSONArray) jsonAttach.get("hits");
			@SuppressWarnings("rawtypes")
			Iterator itratorcan = arrayAtach.iterator();

			String ids = "";

			while (itratorcan.hasNext()) {
				AttachCount ac = new AttachCount();

				org.json.simple.JSONObject jsonObjectAttach = (org.json.simple.JSONObject) itratorcan.next();
				jsonObjectAttach = (org.json.simple.JSONObject) jsonObjectAttach.get("_source");

				ids += "," + jsonObjectAttach.get("objectId");

				if (jsonObjectAttach.get("id") != null)
					ac.setId((String) jsonObjectAttach.get("id"));

				if (jsonObjectAttach.get("objectId") != null)
					ac.setObjectId((String) jsonObjectAttach.get("objectId"));

				if (jsonObjectAttach.get("jobId") != null)
					ac.setJobId((String) jsonObjectAttach.get("jobId"));

				if (jsonObjectAttach.get("jobName") != null)
					ac.setJobName((String) jsonObjectAttach.get("jobName"));

				if (jsonObjectAttach.get("clientId") != null)
					ac.setClientId((String) jsonObjectAttach.get("clientId"));

				if (jsonObjectAttach.get("clientName") != null)
					ac.setClientName((String) jsonObjectAttach.get("clientName"));

				if (jsonObjectAttach.get("contactId") != null)
					ac.setContactId((String) jsonObjectAttach.get("contactId"));

				if (jsonObjectAttach.get("contactName") != null)
					ac.setContactName((String) jsonObjectAttach.get("contactName"));

				if (jsonObjectAttach.get("attachedBy") != null)
					ac.setAttachedBy((String) jsonObjectAttach.get("attachedBy"));

				if (jsonObjectAttach.get("lastModifiedBy") != null)
					ac.setLastModifiedBy((String) jsonObjectAttach.get("lastModifiedBy"));

				if (jsonObjectAttach.get("lastModified") != null)
					ac.setLastModified((String) jsonObjectAttach.get("lastModified"));

				if (jsonObjectAttach.get("createdDate") != null)
					ac.setCreatedDate((String) jsonObjectAttach.get("createdDate"));

				if (jsonObjectAttach.get("anchor") != null)
					ac.setAnchor((String) jsonObjectAttach.get("anchor"));

				if (jsonObjectAttach.get("cvSentDate") != null)
					ac.setCvSentDate((String) jsonObjectAttach.get("cvSentDate"));

				if (jsonObjectAttach.get("statusChangeDate") != null)
					ac.setStatusChangeDate((String) jsonObjectAttach.get("statusChangeDate"));

				if (jsonObjectAttach.get("statusOutcome") != null)
					ac.setStatusOutcome((String) jsonObjectAttach.get("statusOutcome"));

				if (jsonObjectAttach.get("changeReason") != null)
					ac.setChangeReason((String) jsonObjectAttach.get("changeReason"));

				if (jsonObjectAttach.get("federated") != null)
					ac.setFederated((String) jsonObjectAttach.get("federated"));

				if (jsonObjectAttach.get("clientPortalStatus") != null)
					ac.setClientPortalStatus((String) jsonObjectAttach.get("clientPortalStatus"));

				if (jsonObjectAttach.get("clientSheetStatus") != null)
					ac.setClientSheetStatus((String) jsonObjectAttach.get("clientSheetStatus"));

				if (jsonObjectAttach.get("paTestScore") != null)
					ac.setPaTestScore((String) jsonObjectAttach.get("paTestScore"));

				if (jsonObjectAttach.get("testScore") != null)
					ac.setTestScore((String) jsonObjectAttach.get("testScore"));

				if (jsonObjectAttach.get("avgScore") != null)
					ac.setAvgScore((String) jsonObjectAttach.get("avgScore"));

				if (jsonObjectAttach.get("pageUpId") != null)
					ac.setPageUpId((Long) jsonObjectAttach.get("pageUpId"));

				if (jsonObjectAttach.get("isClientSheet") != null)
					ac.setIsClientSheet((Long) jsonObjectAttach.get("isClientSheet"));

				if (jsonObjectAttach.get("ghStatus") != null)
					ac.setGhStatus((String) jsonObjectAttach.get("ghStatus"));

				if (jsonObjectAttach.get("ghStatusId") != null)
					ac.setGhStatusId((Long) jsonObjectAttach.get("ghStatusId"));

				if (jsonObjectAttach.get("statusId") != null)
					ac.setStatusId((Long) jsonObjectAttach.get("statusId"));

				if (jsonObjectAttach.get("status") != null)
					ac.setStatus((String) jsonObjectAttach.get("status"));

				if (jsonObjectAttach.get("dropComment") != null)
					ac.setDropComment((String) jsonObjectAttach.get("dropComment"));

				if (jsonObjectAttach.get("comment") != null)
					ac.setComment((String) jsonObjectAttach.get("comment"));

				if (jsonObjectAttach.get("withOutId") != null)
					ac.setWithOutId((Long) jsonObjectAttach.get("withOutId"));

				list.add(ac);

			}

			setCandidateObjectIds(ids);
		} catch (ParseException e1) {
			e1.printStackTrace();
		}

		return list;
	}

	@SuppressWarnings("unchecked")
	public String getFormattedJson(String json, Integer perpage, Integer next) {

		int start = perpage * (next - 1);
		JSONObject response = new JSONObject();
		JSONObject subResponse = new JSONObject();
		try {

			JSONArray attach = new JSONArray();

			JSONParser parser = new JSONParser();

			JSONObject jsonObj = (JSONObject) parser.parse(json);
			JSONArray jsonArray = (JSONArray) (((JSONObject) jsonObj.get("response")).get("attach"));

			if (jsonArray.size() >= 2) {
				JSONArray attachArray = (JSONArray) jsonArray.get(0);
				JSONArray candidateArray = (JSONArray) jsonArray.get(1);

				if (sortParam.equals("attach")) {

					for (int i = 0; i < attachArray.size(); i++) {
						JSONArray candidate = new JSONArray();
						JSONObject subCandidateJson = new JSONObject();
						JSONObject subAttachJson = new JSONObject();

						subAttachJson = (JSONObject) attachArray.get(i);

						subCandidateJson = getMappedData("" + subAttachJson.get("objectId"), candidateArray);

						if (subCandidateJson != null) {
							if (!subCandidateJson.containsKey("alternateEmail"))
								subCandidateJson.put("alternateEmail", org.json.JSONObject.NULL);

							candidate.add(subCandidateJson);

							subAttachJson.put("candidate", candidate);
							attach.add(subAttachJson);
						}
					}

				} else if (sortParam.equals("candidate")) {

					for (int i = 0; i < candidateArray.size(); i++) {
						JSONArray candidate = new JSONArray();
						JSONObject subCandidateJson = new JSONObject();
						JSONObject subAttachJson = new JSONObject();

						subCandidateJson = (JSONObject) candidateArray.get(i);

						if (!subCandidateJson.containsKey("alternateEmail"))
							subCandidateJson.put("alternateEmail", org.json.JSONObject.NULL);
						candidate.add((candidateArray.get(i)));

						subAttachJson = getMappedData("" + subCandidateJson.get("id"), attachArray);
						subAttachJson.put("candidate", candidate);
						attach.add(subAttachJson);
					}
				}
				Integer toIndex;
				if (start + perpage < attach.size())
					toIndex = start + perpage;
				else
					toIndex = attach.size();

				ArrayList<AttachCount> list = new ArrayList<AttachCount>();
				list.addAll(attach);
				attach.clear();
				if (start <= toIndex)
					attach.addAll(list.subList(start, toIndex));

				subResponse.put("numFound", attach.size());
				subResponse.put("attach", attach);
			}

			response.put("response", subResponse);

		} catch (ParseException e) {
			e.printStackTrace();
		}

		return response.toString();
	}

	public JSONObject getMappedData(String id, JSONArray array) {
		for (int i = 0; i < array.size(); i++) {
			if (sortParam.equals("attach") && ((String) ((JSONObject) array.get(i)).get("id")).equals(id))
				return (JSONObject) array.get(i);
			else if (sortParam.equals("candidate") && ((String) ((JSONObject) array.get(i)).get("objectId")).equals(id))
				return (JSONObject) array.get(i);
		}
		return null;
	}

	public String getCandidateObjectIds() {
		return candidateObjectIds;
	}

	public void setCandidateObjectIds(String candidateObjectIds) {
		this.candidateObjectIds = candidateObjectIds;
	}

	/*
	 * 
	 * Job Data
	 * 
	 */

	@RequestMapping(value = "/ElasticAPI/getjob", method = { RequestMethod.GET })
	public @ResponseBody String esJob2(@RequestParam("searchparam") String searchparam,
			@RequestHeader HttpHeaders headers, @RequestParam("perpage") Integer perpage,
			@RequestParam("next") Integer next) throws URISyntaxException, MalformedURLException, JSONException {

//		if (!headers.containsKey("authorization")) {
//			System.out.println("No Authentication");
//			return "{\"error\":\"Please Provide The Authentication\"}";
//		}
//		String authString = headers.getFirst("authorization");
//		if (!restService.isUserAuthenticated(authString)) {
//			System.out.println("Wrong Authentication.....");
//			return "{\"error\":\"User not authenticated\"}";
//		}
		
		String authString = headers.getFirst("token");
		String validity = CognitoAuthentication.getValidAuthentication(authString);
		if(validity.equals("valid")){
		

		int start = perpage * (next - 1);

		if (!searchparam.trim().equals("")) {

			if (searchparam.contains("any")) {

				searchparam = "q=*" + searchparam.replace("any:", "").replace(",", ", ") + "*";
				searchparam = searchparam.replaceAll("( )+", " ");
			} else {
				if (searchparam.contains("postedDateRange")) {

					String range = searchparam.substring(searchparam.indexOf("postedDateRange"), searchparam.length());

					if (range.contains(";"))
						range = range.substring(0, range.indexOf(";"));

					if (searchparam.contains(";"))
						searchparam = searchparam.replace(";" + range, "");
					else
						searchparam = searchparam.replace(range, "");

					searchparam = searchparam.replace(":", ":\"").replace(";", "\")AND(");

					range = range.replace("postedDateRange:", "postedDate:[\"").replace("TO", "\" TO \"");
					range += "\"]";

					System.out.println(range);

					if (searchparam.trim().equals(""))
						searchparam = range;
					else
						searchparam += "\")AND(" + range;

				} else if (searchparam.contains("postedDate")) {

					String postedDate = searchparam.substring(searchparam.indexOf("postedDate"));

					if (postedDate.contains(";"))
						postedDate = postedDate.substring(0, postedDate.indexOf(";"));

					searchparam = searchparam.replace(";" + postedDate, "");
					searchparam = searchparam.replace(":", ":\"").replace(";", "\")AND(");
					postedDate = postedDate.replace("postedDate:", "postedDate:\"");
					searchparam += "\")AND(" + postedDate;
				} else
					searchparam = searchparam.replace(":", ":\"").replace(";", "\")AND(");

				if (searchparam.endsWith("]"))
					searchparam = "q=(" + searchparam + ")";
				else
					searchparam = "q=(" + searchparam + "\")";
			}
		}

		System.out.println(searchparam);
		// String urljob =
		// "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?"
		// + searchparam +
		// "&size=10&from=0&pretty=true&sort=modifiedDate.keyword:desc&_source=id,clientId,contactId,name,jobCode,noOfOpenings,"
		// +
		// "experience,ctc,location,industryType,jobType,industry,funtionalArea,role,skills,education,"
		// +
		// "description,postedDate,modifiedDate,postedBy,modifiedBy,deleted,expiredDate";

		String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?"
				+ searchparam + "&size=" + perpage + "&from=" + start
				+ "&pretty=true&sort=modifiedDate.keyword:desc&_source=id,clientId,contactId,name,jobCode,noOfOpenings,"
				+ "experience,ctc,location,industryType,jobType,industry,funtionalArea,role,skills,education,"
				+ "description,postedDate,modifiedDate,postedBy,modifiedBy,deleted,expiredDate";

		System.out.println(urljob);

		String result = getJobData(urljob);

		return result;
		}
		else{
		return validity;
		}
	}

	@RequestMapping(value = "/ElasticAPI/getnotattachedjob", method = { RequestMethod.GET })
	public @ResponseBody String getNotAttachedJob(@RequestParam("objectId") String objectId,
			@RequestParam("searchparam") String searchparam, @RequestHeader HttpHeaders headers,
			@RequestParam("perpage") Integer perpage, @RequestParam("next") Integer next)
			throws URISyntaxException, MalformedURLException, JSONException {

//		if (!headers.containsKey("authorization")) {
//			System.out.println("No Authentication");
//			return "{\"error\":\"Please Provide The Authentication\"}";
//		}
//		String authString = headers.getFirst("authorization");
//		if (!restService.isUserAuthenticated(authString)) {
//			System.out.println("Wrong Authentication.....");
//			return "{\"error\":\"User not authenticated\"}";
//		}
		
		String authString = headers.getFirst("token");
		String validity = CognitoAuthentication.getValidAuthentication(authString);
		if(validity.equals("valid")){
		
		int start = perpage * (next - 1);

		String jobIds = " ";
		String urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=objectId:"
				+ objectId + "&_source=objectId,jobId&size=1000";

		// System.out.println("urlAttach...." + urlAttach);
		String jsonAttachData = restTemplate.getForObject(urlAttach, String.class);
		org.json.JSONObject hits1 = new org.json.JSONObject(jsonAttachData).getJSONObject("hits");
		org.json.JSONArray hitsArr = hits1.getJSONArray("hits");
		for (int i = 0; i < hitsArr.length(); i++) {
			org.json.JSONObject arrobj = (org.json.JSONObject) hitsArr.get(i);
			org.json.JSONObject _source = arrobj.getJSONObject("_source");
			jobIds = jobIds + "+" + _source.getString("jobId");
		}
		jobIds = jobIds.replaceFirst("[+]", "").trim();

		if (!searchparam.trim().equals("")) {

			if (searchparam.contains("any")) {

				searchparam = "*" + searchparam.replace("any:", "").replace(",", ", ") + "*";
				searchparam = searchparam.replaceAll("( )+", " ");

				if (jobIds.equals(""))
					searchparam = "q=" + searchparam + "";
				else
					searchparam = "q=NOT(id:" + jobIds + ")AND(" + searchparam + ")";

			} else {
				searchparam = searchparam.replace(":", ":\"").replace(";", "\")AND(");

				if (jobIds.equals(""))
					searchparam = "q=(" + searchparam + "\")";
				else
					searchparam = "q=NOT(id:" + jobIds + ")AND(" + searchparam + "\")";
			}
		}

		// System.out.println(searchparam);

		// String urljob =
		// "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?"
		// + searchparam +
		// "&size=10&from=0&pretty=true&sort=modifiedDate.keyword:desc&_source=id,clientId,contactId,name,jobCode,noOfOpenings,"
		// +
		// "experience,ctc,location,industryType,jobType,industry,funtionalArea,role,skills,education,"
		// +
		// "description,postedDate,modifiedDate,postedBy,modifiedBy,deleted,expiredDate";
		String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?"
				+ searchparam + "&size=" + perpage + "&from=" + start
				+ "&pretty=true&sort=modifiedDate.keyword:desc&_source=id,clientId,contactId,name,jobCode,noOfOpenings,"
				+ "experience,ctc,location,industryType,jobType,industry,funtionalArea,role,skills,education,"
				+ "description,postedDate,modifiedDate,postedBy,modifiedBy,deleted,expiredDate";

		System.out.println(urljob);

		String result = getJobData(urljob);

		return result;
		}
		else{
		return validity;
	  }
	}

	public String getJobData(String query) throws JSONException {
		org.json.JSONObject mainjson = new org.json.JSONObject();
		ArrayList<JobModel> list = new ArrayList<JobModel>();
		try {

			JSONParser jsonParserAttach = new JSONParser();

			URL url = new URL(query);

			URI uri = new URI(url.getProtocol(), url.getUserInfo(), url.getHost(), url.getPort(), url.getPath(),
					url.getQuery(), query);

			String attach = restTemplate.getForObject(uri, String.class);
			org.json.simple.JSONObject jsonAttach = (org.json.simple.JSONObject) ((org.json.simple.JSONObject) jsonParserAttach
					.parse(attach)).get("hits");

			org.json.simple.JSONArray arrayAtach = (org.json.simple.JSONArray) jsonAttach.get("hits");
			@SuppressWarnings("rawtypes")
			Iterator itratorcan = arrayAtach.iterator();

			while (itratorcan.hasNext()) {
				JobModel jm = new JobModel();

				org.json.simple.JSONObject jsonObjectAttach = (org.json.simple.JSONObject) itratorcan.next();
				jsonObjectAttach = (org.json.simple.JSONObject) jsonObjectAttach.get("_source");

				if (jsonObjectAttach.get("id") != null)
					jm.setId((String) jsonObjectAttach.get("id"));

				if (jsonObjectAttach.get("clientId") != null)
					jm.setClientId((String) jsonObjectAttach.get("clientId"));

				if (jsonObjectAttach.get("contactId") != null)
					jm.setContactId((String) jsonObjectAttach.get("contactId"));

				if (jsonObjectAttach.get("name") != null)
					jm.setName((String) jsonObjectAttach.get("name"));

				if (jsonObjectAttach.get("jobCode") != null)
					jm.setJobCode((String) jsonObjectAttach.get("jobCode"));

				if (jsonObjectAttach.get("noOfOpenings") != null)
					jm.setNoOfOpenings((String) jsonObjectAttach.get("noOfOpenings"));

				if (jsonObjectAttach.get("experience") != null)
					jm.setExperience((String) jsonObjectAttach.get("experience"));

				if (jsonObjectAttach.get("ctc") != null)
					jm.setCtc((String) jsonObjectAttach.get("ctc"));

				if (jsonObjectAttach.get("location") != null)
					jm.setLocation((String) jsonObjectAttach.get("location"));

				if (jsonObjectAttach.get("industryType") != null)
					jm.setIndustryType((String) jsonObjectAttach.get("industryType"));

				if (jsonObjectAttach.get("jobType") != null)
					jm.setJobType((String) jsonObjectAttach.get("jobType"));

				if (jsonObjectAttach.get("industry") != null)
					jm.setIndustry((String) jsonObjectAttach.get("industry"));

				if (jsonObjectAttach.get("funtionalArea") != null)
					jm.setFuntionalArea((String) jsonObjectAttach.get("funtionalArea"));

				if (jsonObjectAttach.get("role") != null)
					jm.setRole((String) jsonObjectAttach.get("role"));

				if (jsonObjectAttach.get("skills") != null)
					jm.setSkills((String) jsonObjectAttach.get("skills"));

				if (jsonObjectAttach.get("education") != null)
					jm.setEducation((String) jsonObjectAttach.get("education"));

				if (jsonObjectAttach.get("description") != null)
					jm.setDescription((String) jsonObjectAttach.get("description"));

				if (jsonObjectAttach.get("postedDate") != null)
					jm.setPostedDate((String) jsonObjectAttach.get("postedDate"));

				if (jsonObjectAttach.get("modifiedDate") != null)
					jm.setModifiedDate((String) jsonObjectAttach.get("modifiedDate"));

				if (jsonObjectAttach.get("postedBy") != null)
					jm.setPostedBy((String) jsonObjectAttach.get("postedBy"));

				if (jsonObjectAttach.get("modifiedBy") != null)
					jm.setModifiedBy((String) jsonObjectAttach.get("modifiedBy"));

				if (jsonObjectAttach.get("deleted") != null)
					jm.setDeleted((Long) jsonObjectAttach.get("deleted"));

				if (jsonObjectAttach.get("expiredDate") != null)
					jm.setExpiredDate((String) jsonObjectAttach.get("expiredDate"));

				if (jsonObjectAttach.get("status") != null)
					jm.setStatus((String) jsonObjectAttach.get("status"));

				list.add(jm);

			}
			mainjson.put("total", jsonAttach.get("total"));
			mainjson.put("response", list);

		} catch (ParseException | MalformedURLException | URISyntaxException e1) {
			e1.printStackTrace();
		}

		return mainjson.toString();
	}

	/*
	 * 
	 * Candidate Data   
	 * 
	 */
	
	@RequestMapping(value = "/ElasticAPI/getcandidatedata")
    public @ResponseBody String getdata(@RequestParam("searchparam") String searchparam,
                  @RequestParam("includeFields") String includeFields, @RequestParam("excludeFields") String excludeFields,
                  @RequestParam(value="perpage", required=false) Integer perpage,
                  @RequestParam(value="next", required=false) Integer next,@RequestHeader HttpHeaders headers)
                  throws Exception {
		
		String authString = headers.getFirst("token");
		String validity = CognitoAuthentication.getValidAuthentication(authString);
		if(validity.equals("valid")){
		
           String url = "";

           if (!searchparam.trim().equals("")) {
                  searchparam = searchparam.replace(":", ":\"").replace(";", "\")AND(");
                  searchparam = "q=(" + searchparam + "\")";
           }
           url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?"
                        + searchparam;
           
           
           if(perpage != null && next!= null){
                  int start = perpage * (next - 1);
                  url += "&size=" + perpage + "&from=" + start;
           }else if(perpage != null)
                  url += "&size=" + perpage;
           
           // if (!includeFields.equals(""))
           // url += "&_source_includes=" + includeFields;
           // if (!excludeFields.equals(""))
           // url += "&_source_excludes=" + excludeFields;

           System.out.println("url..." + url);
           String json = "";

           if (!includeFields.equals(""))
                  json = getFieldCandidateData(url, includeFields);
           else
                  json = getAllCandidateData(url, excludeFields);

           return json;
    }else {
		return validity;
	}
}

	
	

	@RequestMapping(value = "/ElasticAPI/getcandidatedata1", method = { RequestMethod.POST })
    public @ResponseBody String getdata(@RequestBody String field,
                  @RequestParam(value="perpage", required=false) Integer perpage,
                  @RequestParam(value="next", required=false) Integer next,@RequestHeader HttpHeaders headers)
                  throws Exception {
		
		String authString = headers.getFirst("token");
		String validity = CognitoAuthentication.getValidAuthentication(authString);
		if(validity.equals("valid")){
		
            String url = "";
            String searchQuery = "";
            String includeFields = "";
            String excludeFields = "";
            
            url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?";

            JSONParser parser = new JSONParser();
            org.json.simple.JSONObject jsonObj = (org.json.simple.JSONObject) parser.parse(field);

            if (jsonObj.containsKey("search")) {
                   org.json.simple.JSONObject searchJson = (org.json.simple.JSONObject) jsonObj.get("search");

                   searchQuery = searchJson.toString();
                   searchQuery = searchQuery.replace("{\"", "").replace("}", "");
                   searchQuery = searchQuery.replace("\":\"", ":\"").replace("\",\"", "\")AND(");
                   searchQuery = "q=(" + searchQuery + ")";

                   System.out.println(searchQuery);

                   url += searchQuery;
            }

            if (perpage != null && next != null) {
                   int start = perpage * (next - 1);
                   url += "&size=" + perpage + "&from=" + start;
            } else if (perpage != null)
                   url += "&size=" + perpage;

            System.out.println("url..." + url);
            String json = "";

            if (jsonObj.containsKey("includeFields")) {
                   includeFields = "" + jsonObj.get("includeFields");
                   includeFields = includeFields.replace("[", "").replace("]", "").replace("\"", "");
                   System.out.println("includeFields.." + includeFields);
            }
            if (jsonObj.containsKey("excludeFields")) {
                   excludeFields = "" + jsonObj.get("excludeFields");
                   excludeFields = excludeFields.replace("[", "").replace("]", "").replace("\"", "");
                   System.out.println("excludeFields..." + excludeFields);
            }

            if (!includeFields.equals(""))
                   json = getFieldCandidateData(url, includeFields);
            else
                   json = getAllCandidateData(url, excludeFields);

            return json;

     


    }else {
		return validity;
	}
}
	
    public String getFieldCandidateData(String query, String includeFields) {

           query += "&_source_includes=" + includeFields;

           System.out.println(query);
           String[] fieldArray = includeFields.split(",");

           org.json.JSONObject maincandijson = new org.json.JSONObject();
           org.json.JSONArray candijsonArr = new org.json.JSONArray();

           try {

                  URL urlcandiateProfile = new URL(query);

                  URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
                               urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
                               urlcandiateProfile.getQuery(), query);

                  String jsonCandidateData = "";

                  jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

                  org.json.JSONObject jsonAttach = new org.json.JSONObject(jsonCandidateData);

                  org.json.JSONObject hits = jsonAttach.getJSONObject("hits");

                  org.json.JSONArray hitsArr = hits.getJSONArray("hits");

                  for (int k = 0; k < hitsArr.length(); k++) {

                        String arrayFields = "family,connectSocialNetwork,referral,skills,project,achievement,certificates";
                        String objectFields = "address,education,employment,salary,experience,html";
                        org.json.JSONObject arrobj = (org.json.JSONObject) hitsArr.get(k);
                        org.json.JSONObject arrObj1 = arrobj.getJSONObject("_source");

                        for (String s : fieldArray) {

                               if (s.contains("."))
                                      System.out.println(s.substring(0, s.indexOf(".")));
                               if (!arrObj1.has(s) && !s.contains("."))
                                      arrObj1.put(s, org.json.JSONObject.NULL);

                               else if (arrObj1.has(s) && !s.contains(".") && objectFields.contains(s)) {
                                      org.json.JSONObject object = arrObj1.getJSONObject(s);
                                      arrObj1.remove(s);
                                      arrObj1.put(s, getCompleteJSONObject(object, s));
                               }

                               else if (s.contains(".") && arrObj1.has(s.substring(0, s.indexOf(".")))
                                             && objectFields.contains(s.substring(0, s.indexOf(".")))) {

                                      org.json.JSONObject object = arrObj1.getJSONObject(s.substring(0, s.indexOf(".")));
                                      arrObj1.remove(s.substring(0, s.indexOf(".")));
                                      arrObj1.put(s.substring(0, s.indexOf(".")), getCompleteJSONObject(object, s));

                               }

                               else if (arrObj1.has(s) && !s.contains(".") && arrayFields.contains(s)) {
                                      org.json.JSONArray array = arrObj1.getJSONArray(s);
                                      arrObj1.remove(s);
                                      arrObj1.put(s, getCompleteJSONArray(array, s));
                               }

                               else if (s.contains(".") && !arrObj1.has(s.substring(0, s.indexOf("."))))
                                      arrObj1.put(s, org.json.JSONObject.NULL);

                               else if (s.contains(".") && arrObj1.has(s.substring(0, s.indexOf(".")))) {
                                      String sCopy = s.replace(".", ",");
                                      String[] sArr = sCopy.split(",");

                                      if (arrayFields.contains(sArr[0])) {
                                             org.json.JSONArray array = arrObj1.getJSONArray(sArr[0]);
                                             arrObj1.remove(sArr[0]);
                                             arrObj1.put(sArr[0], getCompleteJSONArray(array, sArr[0]));
                                      }
                               }
                        }

                        candijsonArr.put(arrObj1);
                  }

                  maincandijson.put("total", hits.get("total"));
                  maincandijson.put("response", candijsonArr);

           } catch (Exception e) {
                  e.printStackTrace();
           }

           return maincandijson.toString();
    }


	public String getAllCandidateData(String query, String excludeFields) {
		org.json.JSONObject maincandijson = new org.json.JSONObject();
		org.json.JSONArray candijsonArr = new org.json.JSONArray();

		try {

			URL urlcandiateProfile = new URL(query);

			URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
					urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
					urlcandiateProfile.getQuery(), query);

			String jsonCandidateData = "";

			jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

			org.json.JSONObject jsonAttach = new org.json.JSONObject(jsonCandidateData);
			org.json.JSONObject hits = jsonAttach.getJSONObject("hits");

			org.json.JSONArray hitsArr = hits.getJSONArray("hits");

			for (int k = 0; k < hitsArr.length(); k++) {

				org.json.JSONObject candijson = new org.json.JSONObject();
				org.json.JSONObject arrobj = (org.json.JSONObject) hitsArr.get(k);
				org.json.JSONObject arrObj1 = arrobj.getJSONObject("_source");

				if (arrObj1.has("id"))
					candijson.put("id", arrObj1.getString("id"));
				else
					candijson.put("id", org.json.JSONObject.NULL);

				if (arrObj1.has("name"))
					candijson.put("name", arrObj1.getString("name"));
				else
					candijson.put("name", org.json.JSONObject.NULL);

				if (arrObj1.has("first_name"))
					candijson.put("first_name", arrObj1.getString("first_name"));
				else
					candijson.put("first_name", org.json.JSONObject.NULL);

				if (arrObj1.has("middle_name"))
					candijson.put("middle_name", arrObj1.getString("middle_name"));
				else
					candijson.put("middle_name", org.json.JSONObject.NULL);

				if (arrObj1.has("last_name"))
					candijson.put("last_name", arrObj1.getString("last_name"));
				else
					candijson.put("last_name", org.json.JSONObject.NULL);

				if (arrObj1.has("username"))
					candijson.put("username", arrObj1.getString("username"));
				else
					candijson.put("username", org.json.JSONObject.NULL);

				if (arrObj1.has("email"))
					candijson.put("email", arrObj1.getString("email"));
				else
					candijson.put("email", org.json.JSONObject.NULL);

				if (arrObj1.has("alternateEmail"))
					candijson.put("alternateEmail", arrObj1.get("alternateEmail"));
				else
					candijson.put("alternateEmail", org.json.JSONObject.NULL);

				if (arrObj1.has("birthdate"))
					candijson.put("birthdate", arrObj1.getString("birthdate"));
				else
					candijson.put("birthdate", org.json.JSONObject.NULL);

				if (arrObj1.has("age"))
					candijson.put("age", arrObj1.getInt("age"));
				else
					candijson.put("age", org.json.JSONObject.NULL);

				if (arrObj1.has("gender"))
					candijson.put("gender", arrObj1.getString("gender"));
				else
					candijson.put("gender", org.json.JSONObject.NULL);

				if (arrObj1.has("picture"))
					candijson.put("picture", arrObj1.get("picture"));
				else
					candijson.put("picture", org.json.JSONObject.NULL);

				if (arrObj1.has("profile"))
					candijson.put("profile", arrObj1.getString("profile"));
				else
					candijson.put("profile", org.json.JSONObject.NULL);

				if (arrObj1.has("website"))
					candijson.put("website", arrObj1.getString("website"));
				else
					candijson.put("website", org.json.JSONObject.NULL);

				if (arrObj1.has("mobileNumber"))
					candijson.put("mobileNumber", arrObj1.getString("mobileNumber"));
				else
					candijson.put("mobileNumber", org.json.JSONObject.NULL);

				if (arrObj1.has("alternateMobileNumber"))
					candijson.put("alternateMobileNumber", arrObj1.get("alternateMobileNumber"));
				else
					candijson.put("alternateMobileNumber", org.json.JSONObject.NULL);

				if (arrObj1.has("telePhone"))
					candijson.put("telePhone", arrObj1.getString("telePhone"));
				else
					candijson.put("telePhone", org.json.JSONObject.NULL);

				if (arrObj1.has("officePhone"))
					candijson.put("officePhone", arrObj1.getString("officePhone"));
				else
					candijson.put("officePhone", org.json.JSONObject.NULL);

				if (arrObj1.has("officePhoneExtention"))
					candijson.put("officePhoneExtention", arrObj1.getString("officePhoneExtention"));
				else
					candijson.put("officePhoneExtention", org.json.JSONObject.NULL);

				if (arrObj1.has("isMobileNumberVerified"))
					candijson.put("isMobileNumberVerified", (Boolean) arrObj1.get("isMobileNumberVerified"));
				else
					candijson.put("isMobileNumberVerified", org.json.JSONObject.NULL);

				if (arrObj1.has("locale"))
					candijson.put("locale", arrObj1.getString("locale"));
				else
					candijson.put("locale", org.json.JSONObject.NULL);

				if (arrObj1.has("religion"))
					candijson.put("religion", arrObj1.get("religion"));
				else
					candijson.put("religion", org.json.JSONObject.NULL);

				if (arrObj1.has("family")) {

					org.json.JSONArray family = new org.json.JSONArray();

					org.json.JSONArray getfamily = (org.json.JSONArray) arrObj1.get("family");

					for (int i = 0; i < getfamily.length(); i++) {
						org.json.JSONObject subfamily = new org.json.JSONObject();
						org.json.JSONObject familyobject = (org.json.JSONObject) getfamily.get(i);

						if (familyobject.has("name"))
							subfamily.put("name", familyobject.getString("name"));
						else
							subfamily.put("name", org.json.JSONObject.NULL);

						if (familyobject.has("occupation"))
							subfamily.put("occupation", familyobject.getString("occupation"));
						else
							subfamily.put("occupation", org.json.JSONObject.NULL);

						if (familyobject.has("location"))
							subfamily.put("location", familyobject.getString("location"));
						else
							subfamily.put("location", org.json.JSONObject.NULL);

						if (familyobject.has("relationship"))
							subfamily.put("relationship", familyobject.getString("relationship"));
						else
							subfamily.put("relationship", org.json.JSONObject.NULL);

						family.put(subfamily);

					}

					candijson.put("family", family);
				} else
					candijson.put("family", org.json.JSONObject.NULL);

				if (arrObj1.has("maritalStatus"))
					candijson.put("maritalStatus", arrObj1.getString("maritalStatus"));
				else
					candijson.put("maritalStatus", org.json.JSONObject.NULL);

				if (arrObj1.has("salutation"))
					candijson.put("salutation", arrObj1.getString("salutation"));
				else
					candijson.put("salutation", org.json.JSONObject.NULL);

				if (arrObj1.has("federated"))
					candijson.put("federated", arrObj1.getString("federated"));
				else
					candijson.put("federated", org.json.JSONObject.NULL);

				// Address
				if (arrObj1.has("address")) {
					org.json.JSONObject add = new org.json.JSONObject();
					org.json.JSONObject addressJson1 = null;
					org.json.JSONObject addressJson = (org.json.JSONObject) arrObj1.get("address");

					if (addressJson.has("permanentAddress")) {

						org.json.JSONObject addressJ = new org.json.JSONObject();

						addressJson1 = (org.json.JSONObject) addressJson.get("permanentAddress");

						if (addressJson1.has("country"))
							addressJ.put("country", addressJson1.getString("country"));
						else
							addressJ.put("country", org.json.JSONObject.NULL);

						if (addressJson1.has("state"))
							addressJ.put("state", addressJson1.getString("state"));
						else
							addressJ.put("state", org.json.JSONObject.NULL);

						if (addressJson1.has("city"))
							addressJ.put("city", addressJson1.getString("city"));
						else
							addressJ.put("city", org.json.JSONObject.NULL);

						if (addressJson1.has("street"))
							addressJ.put("street", addressJson1.getString("street"));
						else
							addressJ.put("street", org.json.JSONObject.NULL);

						if (addressJson1.has("pincode"))
							addressJ.put("pincode", addressJson1.getString("pincode"));
						else
							addressJ.put("pincode", org.json.JSONObject.NULL);

						if (addressJson1.has("location"))
							addressJ.put("location", addressJson1.getString("location"));
						else
							addressJ.put("location", org.json.JSONObject.NULL);

						add.put("permanentAddress", addressJ);
					} else
						add.put("permanentAddress", org.json.JSONObject.NULL);

					if (addressJson.has("currentAddress")) {
						org.json.JSONObject addressJ = new org.json.JSONObject();

						addressJson1 = (org.json.JSONObject) addressJson.get("currentAddress");

						if (addressJson1.has("country"))
							addressJ.put("country", addressJson1.getString("country"));
						else
							addressJ.put("country", org.json.JSONObject.NULL);

						if (addressJson1.has("state"))
							addressJ.put("state", addressJson1.getString("state"));
						else
							addressJ.put("state", org.json.JSONObject.NULL);

						if (addressJson1.has("city"))
							addressJ.put("city", addressJson1.getString("city"));
						else
							addressJ.put("city", org.json.JSONObject.NULL);

						if (addressJson1.has("street"))
							addressJ.put("street", addressJson1.getString("street"));
						else
							addressJ.put("street", org.json.JSONObject.NULL);

						if (addressJson1.has("pincode"))
							addressJ.put("pincode", addressJson1.getString("pincode"));
						else
							addressJ.put("pincode", org.json.JSONObject.NULL);

						if (addressJson1.has("location"))
							addressJ.put("location", addressJson1.getString("location"));
						else
							addressJ.put("location", org.json.JSONObject.NULL);

						add.put("currentAddress", addressJ);
					} else
						add.put("currentAddress", org.json.JSONObject.NULL);

					candijson.put("address", add);
				} else
					candijson.put("address", org.json.JSONObject.NULL);

				// Connect Social Network
				if (arrObj1.has("connectSocialNetwork")) {

					org.json.JSONArray cns = new org.json.JSONArray();

					org.json.JSONArray getcns = (org.json.JSONArray) arrObj1.get("connectSocialNetwork");

					for (int i = 0; i < getcns.length(); i++) {
						org.json.JSONObject subcns = new org.json.JSONObject();
						org.json.JSONObject cnsobject = (org.json.JSONObject) getcns.get(i);

						if (cnsobject.has("name"))
							subcns.put("name", cnsobject.getString("name"));
						else
							subcns.put("name", org.json.JSONObject.NULL);

						if (cnsobject.has("url"))
							subcns.put("url", cnsobject.getString("url"));
						else
							subcns.put("url", org.json.JSONObject.NULL);

						cns.put(subcns);

					}

					candijson.put("connectSocialNetwork", cns);
				} else
					candijson.put("connectSocialNetwork", org.json.JSONObject.NULL);

				// Notification
				if (arrObj1.has("notification")) {

					org.json.JSONObject notification = new org.json.JSONObject();
					org.json.JSONObject getnotification = (org.json.JSONObject) arrObj1.get("notification");

					if (getnotification.has("resumeDownload"))
						notification.put("resumeDownload", (Boolean) getnotification.get("resumeDownload"));
					else
						notification.put("resumeDownload", org.json.JSONObject.NULL);

					if (getnotification.has("profileViewed"))
						notification.put("profileViewed", (Boolean) getnotification.get("profileViewed"));
					else
						notification.put("profileViewed", org.json.JSONObject.NULL);

					if (getnotification.has("newJobPost"))
						notification.put("newJobPost", (Boolean) getnotification.get("newJobPost"));
					else
						notification.put("newJobPost", org.json.JSONObject.NULL);

					if (getnotification.has("recruiterConnect"))
						notification.put("recruiterConnect", (Boolean) getnotification.get("recruiterConnect"));
					else
						notification.put("recruiterConnect", org.json.JSONObject.NULL);

					candijson.put("notification", notification);
				} else
					candijson.put("notification", org.json.JSONObject.NULL);

				if (arrObj1.has("visibility"))
					candijson.put("visibility", arrObj1.get("visibility"));
				else
					candijson.put("visibility", org.json.JSONObject.NULL);

				if (arrObj1.has("jobType"))
					candijson.put("jobType", arrObj1.getString("jobType"));
				else
					candijson.put("jobType", org.json.JSONObject.NULL);

				if (arrObj1.has("employmentType"))
					candijson.put("employmentType", arrObj1.getString("employmentType"));
				else
					candijson.put("employmentType", org.json.JSONObject.NULL);

				if (arrObj1.has("immediateJoiningAvailabilityOrNegotiable"))
					candijson.put("immediateJoiningAvailabilityOrNegotiable",
							arrObj1.get("immediateJoiningAvailabilityOrNegotiable"));
				else
					candijson.put("immediateJoiningAvailabilityOrNegotiable", org.json.JSONObject.NULL);

				if (arrObj1.has("minimumDaysRequired"))
					candijson.put("minimumDaysRequired", arrObj1.getString("minimumDaysRequired"));
				else
					candijson.put("minimumDaysRequired", org.json.JSONObject.NULL);

				if (arrObj1.has("createdDate"))
					candijson.put("createdDate", arrObj1.getString("createdDate"));
				else
					candijson.put("createdDate", org.json.JSONObject.NULL);

				if (arrObj1.has("lastModified"))
					candijson.put("lastModified", arrObj1.getString("lastModified"));
				else
					candijson.put("lastModified", org.json.JSONObject.NULL);

				if (arrObj1.has("createdBy"))
					candijson.put("createdBy", arrObj1.getString("createdBy"));
				else
					candijson.put("createdBy", org.json.JSONObject.NULL);

				if (arrObj1.has("lastModifiedBy"))
					candijson.put("lastModifiedBy", arrObj1.getString("lastModifiedBy"));
				else
					candijson.put("lastModifiedBy", org.json.JSONObject.NULL);

				if (arrObj1.has("aadharCardNo"))
					candijson.put("aadharCardNo", arrObj1.getString("aadharCardNo"));
				else
					candijson.put("aadharCardNo", org.json.JSONObject.NULL);

				if (arrObj1.has("passportNo"))
					candijson.put("passportNo", arrObj1.getString("passportNo"));
				else
					candijson.put("passportNo", org.json.JSONObject.NULL);

				if (arrObj1.has("passportValidity"))
					candijson.put("passportValidity", arrObj1.getString("passportValidity"));
				else
					candijson.put("passportValidity", org.json.JSONObject.NULL);

				if (arrObj1.has("panNo"))
					candijson.put("panNo", arrObj1.getString("panNo"));
				else
					candijson.put("panNo", org.json.JSONObject.NULL);

				if (arrObj1.has("areaOfSpecialization"))
					candijson.put("areaOfSpecialization", arrObj1.getString("areaOfSpecialization"));
				else
					candijson.put("areaOfSpecialization", org.json.JSONObject.NULL);

				if (arrObj1.has("otherInterest"))
					candijson.put("otherInterest", arrObj1.getString("otherInterest"));
				else
					candijson.put("otherInterest", org.json.JSONObject.NULL);

				if (arrObj1.has("category"))
					candijson.put("category", arrObj1.getString("category"));
				else
					candijson.put("category", org.json.JSONObject.NULL);

				if (arrObj1.has("confidential"))
					candijson.put("confidential", (Boolean) arrObj1.get("confidential"));
				else
					candijson.put("confidential", org.json.JSONObject.NULL);

				if (arrObj1.has("employmentStatus"))
					candijson.put("employmentStatus", arrObj1.getString("employmentStatus"));
				else
					candijson.put("employmentStatus", org.json.JSONObject.NULL);

				if (arrObj1.has("nationality"))
					candijson.put("nationality", arrObj1.getString("nationality"));
				else
					candijson.put("nationality", org.json.JSONObject.NULL);

				if (arrObj1.has("exNationality"))
					candijson.put("exNationality", arrObj1.get("exNationality"));
				else
					candijson.put("exNationality", org.json.JSONObject.NULL);

				if (arrObj1.has("experiencedIndustry"))
					candijson.put("experiencedIndustry", arrObj1.getString("experiencedIndustry"));
				else
					candijson.put("experiencedIndustry", org.json.JSONObject.NULL);

				if (arrObj1.has("preferredIndustry"))
					candijson.put("preferredIndustry", arrObj1.getString("preferredIndustry"));
				else
					candijson.put("preferredIndustry", org.json.JSONObject.NULL);

				if (arrObj1.has("experiencedFunctionalArea"))
					candijson.put("experiencedFunctionalArea", arrObj1.getString("experiencedFunctionalArea"));
				else
					candijson.put("experiencedFunctionalArea", org.json.JSONObject.NULL);

				if (arrObj1.has("preferredFunctionalArea"))
					candijson.put("preferredFunctionalArea", arrObj1.getString("preferredFunctionalArea"));
				else
					candijson.put("preferredFunctionalArea", org.json.JSONObject.NULL);

				if (arrObj1.has("language"))
					candijson.put("language", arrObj1.getString("language"));
				else
					candijson.put("language", org.json.JSONObject.NULL);

				if (arrObj1.has("notes"))
					candijson.put("notes", arrObj1.getString("notes"));
				else
					candijson.put("notes", org.json.JSONObject.NULL);

				if (arrObj1.has("noticePeriod"))
					candijson.put("noticePeriod", arrObj1.getString("noticePeriod"));
				else
					candijson.put("noticePeriod", org.json.JSONObject.NULL);

				if (arrObj1.has("preferredLocation"))
					candijson.put("preferredLocation", arrObj1.getString("preferredLocation"));
				else
					candijson.put("preferredLocation", org.json.JSONObject.NULL);

				if (arrObj1.has("preferredDistance"))
					candijson.put("preferredDistance", arrObj1.getString("preferredDistance"));
				else
					candijson.put("preferredDistance", org.json.JSONObject.NULL);

				if (arrObj1.has("physicallyChallenged"))
					candijson.put("physicallyChallenged", arrObj1.getString("physicallyChallenged"));
				else
					candijson.put("physicallyChallenged", org.json.JSONObject.NULL);

				if (arrObj1.has("reasonForLeaving"))
					candijson.put("reasonForLeaving", arrObj1.getString("reasonForLeaving"));
				else
					candijson.put("reasonForLeaving", org.json.JSONObject.NULL);

				if (arrObj1.has("reasonForRelocate"))
					candijson.put("reasonForRelocate", arrObj1.getString("reasonForRelocate"));
				else
					candijson.put("reasonForRelocate", org.json.JSONObject.NULL);

				// Referral
				if (arrObj1.has("referral")) {

					org.json.JSONArray referal = new org.json.JSONArray();

					org.json.JSONArray getreferal = (org.json.JSONArray) arrObj1.get("referral");

					for (int i = 0; i < getreferal.length(); i++) {
						org.json.JSONObject subreferral = new org.json.JSONObject();
						org.json.JSONObject referralobject = (org.json.JSONObject) getreferal.get(i);

						if (referralobject.has("name"))
							subreferral.put("name", referralobject.getString("name"));
						else
							subreferral.put("name", org.json.JSONObject.NULL);

						if (referralobject.has("officeEmail"))
							subreferral.put("officeEmail", referralobject.getString("officeEmail"));
						else
							subreferral.put("officeEmail", org.json.JSONObject.NULL);

						if (referralobject.has("officePhone"))
							subreferral.put("officePhone", referralobject.getString("officePhone"));
						else
							subreferral.put("officePhone", org.json.JSONObject.NULL);

						if (referralobject.has("company"))
							subreferral.put("company", referralobject.getString("company"));
						else
							subreferral.put("company", org.json.JSONObject.NULL);

						if (referralobject.has("title"))
							subreferral.put("title", referralobject.getString("title"));
						else
							subreferral.put("title", org.json.JSONObject.NULL);

						if (referralobject.has("description"))
							subreferral.put("description", referralobject.getString("description"));
						else
							subreferral.put("description", org.json.JSONObject.NULL);

						referal.put(subreferral);

					}

					candijson.put("referral", referal);
				} else
					candijson.put("referral", org.json.JSONObject.NULL);

				if (arrObj1.has("willingToRelocate"))
					candijson.put("willingToRelocate", arrObj1.getString("willingToRelocate"));
				else
					candijson.put("willingToRelocate", org.json.JSONObject.NULL);

				if (arrObj1.has("willingToChangeJob"))
					candijson.put("willingToChangeJob", arrObj1.getString("willingToChangeJob"));
				else
					candijson.put("willingToChangeJob", org.json.JSONObject.NULL);

				if (arrObj1.has("resumeHeadLine"))
					candijson.put("resumeHeadLine", arrObj1.getString("resumeHeadLine"));
				else
					candijson.put("resumeHeadLine", org.json.JSONObject.NULL);

				if (arrObj1.has("experienced"))
					candijson.put("experienced", (Boolean) arrObj1.get("experienced"));
				else
					candijson.put("experienced", org.json.JSONObject.NULL);

				if (arrObj1.has("fresher"))
					candijson.put("fresher", (Boolean) arrObj1.get("fresher"));
				else
					candijson.put("fresher", org.json.JSONObject.NULL);

				if (arrObj1.has("shiftWork"))
					candijson.put("shiftWork", arrObj1.getString("shiftWork"));
				else
					candijson.put("shiftWork", org.json.JSONObject.NULL);

				if (arrObj1.has("skillSummary"))
					candijson.put("skillSummary", arrObj1.getString("skillSummary"));
				else
					candijson.put("skillSummary", org.json.JSONObject.NULL);

				if (arrObj1.has("summary"))
					candijson.put("summary", arrObj1.getString("summary"));
				else
					candijson.put("summary", org.json.JSONObject.NULL);

				// skills
				if (arrObj1.has("skills")) {
					org.json.JSONArray SkillsObj = new org.json.JSONArray();

					org.json.JSONObject getskillobject = new org.json.JSONObject();

					org.json.JSONArray skillList = (org.json.JSONArray) arrObj1.get("skills");

					for (int i = 0; i < skillList.length(); i++) {

						getskillobject = (org.json.JSONObject) skillList.get(i);
						org.json.JSONObject Skills = new org.json.JSONObject();

						if (getskillobject.has("keySkill"))
							Skills.put("keySkill", getskillobject.getString("keySkill"));
						else
							Skills.put("keySkill", org.json.JSONObject.NULL);

						if (getskillobject.has("experience"))
							Skills.put("experience", getskillobject.getString("experience"));
						else
							Skills.put("experience", org.json.JSONObject.NULL);

						if (getskillobject.has("fromMonth"))
							Skills.put("fromMonth", getskillobject.getString("fromMonth"));
						else
							Skills.put("fromMonth", org.json.JSONObject.NULL);

						if (getskillobject.has("fromYear"))
							Skills.put("fromYear", getskillobject.getString("fromYear"));
						else
							Skills.put("fromYear", org.json.JSONObject.NULL);

						if (getskillobject.has("toMonth"))
							Skills.put("toMonth", getskillobject.getString("toMonth"));
						else
							Skills.put("toMonth", org.json.JSONObject.NULL);

						if (getskillobject.has("toYear"))
							Skills.put("toYear", getskillobject.getString("toYear"));
						else
							Skills.put("toYear", org.json.JSONObject.NULL);

						SkillsObj.put(Skills);
					}

					candijson.put("skills", SkillsObj);
				}

				else
					candijson.put("skills", org.json.JSONObject.NULL);

				// education
				if (arrObj1.has("education")) {
					org.json.JSONObject education = new org.json.JSONObject();

					org.json.JSONObject educationjson = (org.json.JSONObject) arrObj1.get("education");

					if (educationjson.has("ug")) {

						org.json.JSONObject subEdu = new org.json.JSONObject();

						org.json.JSONObject educationjson1 = (org.json.JSONObject) educationjson.get("ug");

						if (educationjson1.has("degree"))
							subEdu.put("degree", educationjson1.getString("degree"));
						else
							subEdu.put("degree", org.json.JSONObject.NULL);

						if (educationjson1.has("degreeType"))
							subEdu.put("degreeType", educationjson1.getString("degreeType"));
						else
							subEdu.put("degreeType", org.json.JSONObject.NULL);

						if (educationjson1.has("course"))
							subEdu.put("course", educationjson1.getString("course"));
						else
							subEdu.put("course", org.json.JSONObject.NULL);

						if (educationjson1.has("institute"))
							subEdu.put("institute", educationjson1.getString("institute"));
						else
							subEdu.put("institute", org.json.JSONObject.NULL);

						if (educationjson1.has("universityOrBoard"))
							subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
						else
							subEdu.put("universityOrBoard", org.json.JSONObject.NULL);

						if (educationjson1.has("city"))
							subEdu.put("city", educationjson1.getString("city"));
						else
							subEdu.put("city", org.json.JSONObject.NULL);

						if (educationjson1.has("fromMonth"))
							subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
						else
							subEdu.put("fromMonth", org.json.JSONObject.NULL);

						if (educationjson1.has("fromYear"))
							subEdu.put("fromYear", educationjson1.getString("fromYear"));
						else
							subEdu.put("fromYear", org.json.JSONObject.NULL);

						if (educationjson1.has("toMonth"))
							subEdu.put("toMonth", educationjson1.getString("toMonth"));
						else
							subEdu.put("toMonth", org.json.JSONObject.NULL);

						if (educationjson1.has("toYear"))
							subEdu.put("toYear", educationjson1.getString("toYear"));
						else
							subEdu.put("toYear", org.json.JSONObject.NULL);

						if (educationjson1.has("percentage"))
							subEdu.put("percentage", educationjson1.getString("percentage"));
						else
							subEdu.put("percentage", org.json.JSONObject.NULL);

						education.put("ug", subEdu);
					} else
						education.put("ug", org.json.JSONObject.NULL);

					if (educationjson.has("pg")) {

						org.json.JSONObject subEdu = new org.json.JSONObject();

						org.json.JSONObject educationjson1 = (org.json.JSONObject) educationjson.get("pg");

						if (educationjson1.has("degree"))
							subEdu.put("degree", educationjson1.getString("degree"));
						else
							subEdu.put("degree", org.json.JSONObject.NULL);

						if (educationjson1.has("degreeType"))
							subEdu.put("degreeType", educationjson1.getString("degreeType"));
						else
							subEdu.put("degreeType", org.json.JSONObject.NULL);

						if (educationjson1.has("course"))
							subEdu.put("course", educationjson1.getString("course"));
						else
							subEdu.put("course", org.json.JSONObject.NULL);

						if (educationjson1.has("institute"))
							subEdu.put("institute", educationjson1.getString("institute"));
						else
							subEdu.put("institute", org.json.JSONObject.NULL);

						if (educationjson1.has("universityOrBoard"))
							subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
						else
							subEdu.put("universityOrBoard", org.json.JSONObject.NULL);

						if (educationjson1.has("city"))
							subEdu.put("city", educationjson1.getString("city"));
						else
							subEdu.put("city", org.json.JSONObject.NULL);

						if (educationjson1.has("fromMonth"))
							subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
						else
							subEdu.put("fromMonth", org.json.JSONObject.NULL);

						if (educationjson1.has("fromYear"))
							subEdu.put("fromYear", educationjson1.getString("fromYear"));
						else
							subEdu.put("fromYear", org.json.JSONObject.NULL);

						if (educationjson1.has("toMonth"))
							subEdu.put("toMonth", educationjson1.getString("toMonth"));
						else
							subEdu.put("toMonth", org.json.JSONObject.NULL);

						if (educationjson1.has("toYear"))
							subEdu.put("toYear", educationjson1.getString("toYear"));
						else
							subEdu.put("toYear", org.json.JSONObject.NULL);

						if (educationjson1.has("percentage"))
							subEdu.put("percentage", educationjson1.getString("percentage"));
						else
							subEdu.put("percentage", org.json.JSONObject.NULL);

						education.put("pg", subEdu);

					} else
						education.put("pg", org.json.JSONObject.NULL); // end pg

					if (educationjson.has("doctorate")) {

						org.json.JSONObject subEdu = new org.json.JSONObject();

						org.json.JSONObject educationjson1 = (org.json.JSONObject) educationjson.get("doctorate");

						if (educationjson1.has("degree"))
							subEdu.put("degree", educationjson1.getString("degree"));
						else
							subEdu.put("degree", org.json.JSONObject.NULL);

						if (educationjson1.has("degreeType"))
							subEdu.put("degreeType", educationjson1.getString("degreeType"));
						else
							subEdu.put("degreeType", org.json.JSONObject.NULL);

						if (educationjson1.has("course"))
							subEdu.put("course", educationjson1.getString("course"));
						else
							subEdu.put("course", org.json.JSONObject.NULL);

						if (educationjson1.has("institute"))
							subEdu.put("institute", educationjson1.getString("institute"));
						else
							subEdu.put("institute", org.json.JSONObject.NULL);

						if (educationjson1.has("universityOrBoard"))
							subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
						else
							subEdu.put("universityOrBoard", org.json.JSONObject.NULL);

						if (educationjson1.has("city"))
							subEdu.put("city", educationjson1.getString("city"));
						else
							subEdu.put("city", org.json.JSONObject.NULL);

						if (educationjson1.has("fromMonth"))
							subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
						else
							subEdu.put("fromMonth", org.json.JSONObject.NULL);

						if (educationjson1.has("fromYear"))
							subEdu.put("fromYear", educationjson1.getString("fromYear"));
						else
							subEdu.put("fromYear", org.json.JSONObject.NULL);

						if (educationjson1.has("toMonth"))
							subEdu.put("toMonth", educationjson1.getString("toMonth"));
						else
							subEdu.put("toMonth", org.json.JSONObject.NULL);

						if (educationjson1.has("toYear"))
							subEdu.put("toYear", educationjson1.getString("toYear"));
						else
							subEdu.put("toYear", org.json.JSONObject.NULL);

						if (educationjson1.has("percentage"))
							subEdu.put("percentage", educationjson1.getString("percentage"));
						else
							subEdu.put("percentage", org.json.JSONObject.NULL);

						education.put("doctorate", subEdu);

					} else
						education.put("doctorate", org.json.JSONObject.NULL);

					if (educationjson.has("diploma")) {

						org.json.JSONObject subEdu = new org.json.JSONObject();

						org.json.JSONObject educationjson1 = (org.json.JSONObject) educationjson.get("diploma");

						if (educationjson1.has("degree"))
							subEdu.put("degree", educationjson1.getString("degree"));
						else
							subEdu.put("degree", org.json.JSONObject.NULL);

						if (educationjson1.has("degreeType"))
							subEdu.put("degreeType", educationjson1.getString("degreeType"));
						else
							subEdu.put("degreeType", org.json.JSONObject.NULL);

						if (educationjson1.has("course"))
							subEdu.put("course", educationjson1.getString("course"));
						else
							subEdu.put("course", org.json.JSONObject.NULL);

						if (educationjson1.has("institute"))
							subEdu.put("institute", educationjson1.getString("institute"));
						else
							subEdu.put("institute", org.json.JSONObject.NULL);

						if (educationjson1.has("universityOrBoard"))
							subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
						else
							subEdu.put("universityOrBoard", org.json.JSONObject.NULL);

						if (educationjson1.has("city"))
							subEdu.put("city", educationjson1.getString("city"));
						else
							subEdu.put("city", org.json.JSONObject.NULL);

						if (educationjson1.has("fromMonth"))
							subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
						else
							subEdu.put("fromMonth", org.json.JSONObject.NULL);

						if (educationjson1.has("fromYear"))
							subEdu.put("fromYear", educationjson1.getString("fromYear"));
						else
							subEdu.put("fromYear", org.json.JSONObject.NULL);

						if (educationjson1.has("toMonth"))
							subEdu.put("toMonth", educationjson1.getString("toMonth"));
						else
							subEdu.put("toMonth", org.json.JSONObject.NULL);

						if (educationjson1.has("toYear"))
							subEdu.put("toYear", educationjson1.getString("toYear"));
						else
							subEdu.put("toYear", org.json.JSONObject.NULL);

						if (educationjson1.has("percentage"))
							subEdu.put("percentage", educationjson1.getString("percentage"));
						else
							subEdu.put("percentage", org.json.JSONObject.NULL);

						education.put("diploma", subEdu);

					} else
						education.put("diploma", org.json.JSONObject.NULL);

					if (educationjson.has("twelveth")) {

						org.json.JSONObject subEdu = new org.json.JSONObject();

						org.json.JSONObject educationjson1 = (org.json.JSONObject) educationjson.get("twelveth");

						if (educationjson1.has("degree"))
							subEdu.put("degree", educationjson1.getString("degree"));
						else
							subEdu.put("degree", org.json.JSONObject.NULL);

						if (educationjson1.has("degreeType"))
							subEdu.put("degreeType", educationjson1.getString("degreeType"));
						else
							subEdu.put("degreeType", org.json.JSONObject.NULL);

						if (educationjson1.has("course"))
							subEdu.put("course", educationjson1.getString("course"));
						else
							subEdu.put("course", org.json.JSONObject.NULL);

						if (educationjson1.has("institute"))
							subEdu.put("institute", educationjson1.getString("institute"));
						else
							subEdu.put("institute", org.json.JSONObject.NULL);

						if (educationjson1.has("universityOrBoard"))
							subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
						else
							subEdu.put("universityOrBoard", org.json.JSONObject.NULL);

						if (educationjson1.has("city"))
							subEdu.put("city", educationjson1.getString("city"));
						else
							subEdu.put("city", org.json.JSONObject.NULL);

						if (educationjson1.has("fromMonth"))
							subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
						else
							subEdu.put("fromMonth", org.json.JSONObject.NULL);

						if (educationjson1.has("fromYear"))
							subEdu.put("fromYear", educationjson1.getString("fromYear"));
						else
							subEdu.put("fromYear", org.json.JSONObject.NULL);

						if (educationjson1.has("toMonth"))
							subEdu.put("toMonth", educationjson1.getString("toMonth"));
						else
							subEdu.put("toMonth", org.json.JSONObject.NULL);

						if (educationjson1.has("toYear"))
							subEdu.put("toYear", educationjson1.getString("toYear"));
						else
							subEdu.put("toYear", org.json.JSONObject.NULL);

						if (educationjson1.has("percentage"))
							subEdu.put("percentage", educationjson1.getString("percentage"));
						else
							subEdu.put("percentage", org.json.JSONObject.NULL);

						education.put("twelveth", subEdu);

					} else
						education.put("twelveth", org.json.JSONObject.NULL);

					if (educationjson.has("tenth")) {

						org.json.JSONObject subEdu = new org.json.JSONObject();

						org.json.JSONObject educationjson1 = (org.json.JSONObject) educationjson.get("tenth");

						if (educationjson1.has("degree"))
							subEdu.put("degree", educationjson1.getString("degree"));
						else
							subEdu.put("degree", org.json.JSONObject.NULL);

						if (educationjson1.has("degreeType"))
							subEdu.put("degreeType", educationjson1.getString("degreeType"));
						else
							subEdu.put("degreeType", org.json.JSONObject.NULL);

						if (educationjson1.has("course"))
							subEdu.put("course", educationjson1.getString("course"));
						else
							subEdu.put("course", org.json.JSONObject.NULL);

						if (educationjson1.has("institute"))
							subEdu.put("institute", educationjson1.getString("institute"));
						else
							subEdu.put("institute", org.json.JSONObject.NULL);

						if (educationjson1.has("universityOrBoard"))
							subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
						else
							subEdu.put("universityOrBoard", org.json.JSONObject.NULL);

						if (educationjson1.has("city"))
							subEdu.put("city", educationjson1.getString("city"));
						else
							subEdu.put("city", org.json.JSONObject.NULL);

						if (educationjson1.has("fromMonth"))
							subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
						else
							subEdu.put("fromMonth", org.json.JSONObject.NULL);

						if (educationjson1.has("fromYear"))
							subEdu.put("fromYear", educationjson1.getString("fromYear"));
						else
							subEdu.put("fromYear", org.json.JSONObject.NULL);

						if (educationjson1.has("toMonth"))
							subEdu.put("toMonth", educationjson1.getString("toMonth"));
						else
							subEdu.put("toMonth", org.json.JSONObject.NULL);

						if (educationjson1.has("toYear"))
							subEdu.put("toYear", educationjson1.getString("toYear"));
						else
							subEdu.put("toYear", org.json.JSONObject.NULL);

						if (educationjson1.has("percentage"))
							subEdu.put("percentage", educationjson1.getString("percentage"));
						else
							subEdu.put("percentage", org.json.JSONObject.NULL);

						education.put("tenth", subEdu);

					} else
						education.put("tenth", org.json.JSONObject.NULL);

					candijson.put("education", education);
				} else
					candijson.put("education", org.json.JSONObject.NULL);

				// employment
				if (arrObj1.has("employment")) {

					org.json.JSONObject employement = new org.json.JSONObject();

					org.json.JSONObject getemployment = arrObj1.getJSONObject("employment");

					if (getemployment.has("current")) {

						org.json.JSONObject current = new org.json.JSONObject();
						org.json.JSONObject getcurrent = getemployment.getJSONObject("current");

						if (getcurrent.has("organization"))
							current.put("organization", getcurrent.getString("organization"));
						else
							current.put("organization", org.json.JSONObject.NULL);

						if (getcurrent.has("designation"))
							current.put("designation", getcurrent.getString("designation"));
						else
							current.put("designation", org.json.JSONObject.NULL);

						if (getcurrent.has("description"))
							current.put("description", getcurrent.getString("description"));
						else
							current.put("description", org.json.JSONObject.NULL);

						if (getcurrent.has("fromMonth"))
							current.put("fromMonth", getcurrent.getString("fromMonth"));
						else
							current.put("fromMonth", org.json.JSONObject.NULL);

						if (getcurrent.has("fromYear"))
							current.put("fromYear", getcurrent.getString("fromYear"));
						else
							current.put("fromYear", org.json.JSONObject.NULL);

						if (getcurrent.has("toMonth"))
							current.put("toMonth", getcurrent.getString("toMonth"));
						else
							current.put("toMonth", org.json.JSONObject.NULL);

						if (getcurrent.has("toYear"))
							current.put("toYear", getcurrent.getString("toYear"));
						else
							current.put("toYear", org.json.JSONObject.NULL);

						if (getcurrent.has("workLocation"))
							current.put("workLocation", getcurrent.getString("workLocation"));
						else
							current.put("workLocation", org.json.JSONObject.NULL);

						if (getcurrent.has("role"))
							current.put("role", getcurrent.getString("role"));
						else
							current.put("role", org.json.JSONObject.NULL);

						if (getcurrent.has("level"))
							current.put("level", getcurrent.getString("level"));
						else
							current.put("level", org.json.JSONObject.NULL);

						if (getcurrent.has("teamSize"))
							current.put("teamSize", getcurrent.getString("teamSize"));
						else
							current.put("teamSize", org.json.JSONObject.NULL);

						employement.put("current", current);
					} else
						employement.put("current", org.json.JSONObject.NULL);

					if (getemployment.has("previous")) {

						org.json.JSONArray previous = new org.json.JSONArray();

						org.json.JSONArray getprevious = getemployment.getJSONArray("previous");
						int i = 0;

						for (i = 0; i < getprevious.length(); i++) {

							org.json.JSONObject jsonprevious = (org.json.JSONObject) getprevious.get(i);

							if (jsonprevious.has("organization"))
								jsonprevious.put("organization", jsonprevious.getString("organization"));
							else
								jsonprevious.put("organization", org.json.JSONObject.NULL);

							if (jsonprevious.has("designation"))
								jsonprevious.put("designation", jsonprevious.getString("designation"));
							else
								jsonprevious.put("designation", org.json.JSONObject.NULL);

							if (jsonprevious.has("level"))
								jsonprevious.put("level", jsonprevious.getString("level"));
							else
								jsonprevious.put("level", org.json.JSONObject.NULL);

							if (jsonprevious.has("city"))
								jsonprevious.put("city", jsonprevious.getString("city"));
							else
								jsonprevious.put("city", org.json.JSONObject.NULL);

							if (jsonprevious.has("fromMonth"))
								jsonprevious.put("fromMonth", jsonprevious.getString("fromMonth"));
							else
								jsonprevious.put("fromMonth", org.json.JSONObject.NULL);

							if (jsonprevious.has("fromYear"))
								jsonprevious.put("fromYear", jsonprevious.getString("fromYear"));
							else
								jsonprevious.put("fromYear", org.json.JSONObject.NULL);

							if (jsonprevious.has("toMonth"))
								jsonprevious.put("toMonth", jsonprevious.getString("toMonth"));
							else
								jsonprevious.put("toMonth", org.json.JSONObject.NULL);

							if (jsonprevious.has("toYear"))
								jsonprevious.put("toYear", jsonprevious.getString("toYear"));
							else
								jsonprevious.put("toYear", org.json.JSONObject.NULL);

							if (jsonprevious.has("description"))
								jsonprevious.put("description", jsonprevious.getString("description"));
							else
								jsonprevious.put("description", org.json.JSONObject.NULL);

							previous.put(jsonprevious);
						}
						employement.put("previous", previous);
					} else
						employement.put("previous", org.json.JSONObject.NULL);

					candijson.put("employment", employement);

				} else
					candijson.put("employment", org.json.JSONObject.NULL);

				// salary
				if (arrObj1.has("salary")) {

					org.json.JSONObject getsalary = (org.json.JSONObject) arrObj1.get("salary");
					org.json.JSONObject salary = new org.json.JSONObject();

					if (getsalary.has("currentCTCType"))
						salary.put("currentCTCType", getsalary.getString("currentCTCType"));
					else
						salary.put("currentCTCType", org.json.JSONObject.NULL);

					if (getsalary.has("currentCTC"))
						salary.put("currentCTC", getsalary.getString("currentCTC"));
					else
						salary.put("currentCTC", org.json.JSONObject.NULL);

					if (getsalary.has("negotiableCTC"))
						salary.put("negotiableCTC", getsalary.getString("negotiableCTC"));
					else
						salary.put("negotiableCTC", org.json.JSONObject.NULL);

					if (getsalary.has("expectedCTCType"))
						salary.put("expectedCTCType", getsalary.getString("expectedCTCType"));
					else
						salary.put("expectedCTCType", org.json.JSONObject.NULL);

					if (getsalary.has("expectedCTC"))
						salary.put("expectedCTC", getsalary.getString("expectedCTC"));
					else
						salary.put("expectedCTC", org.json.JSONObject.NULL);

					if (getsalary.has("takeHome"))
						salary.put("takeHome", getsalary.getString("takeHome"));
					else
						salary.put("takeHome", org.json.JSONObject.NULL);

					if (getsalary.has("fixed"))
						salary.put("fixed", getsalary.getString("fixed"));
					else
						salary.put("fixed", org.json.JSONObject.NULL);

					candijson.put("salary", salary);

				} else
					candijson.put("salary", org.json.JSONObject.NULL);

				if (arrObj1.has("ctc"))
					candijson.put("ctc", (Double) arrObj1.get("ctc"));
				else
					candijson.put("ctc", org.json.JSONObject.NULL);

				if (arrObj1.has("exp"))
					candijson.put("exp", (Double) arrObj1.get("exp"));
				else
					candijson.put("exp", org.json.JSONObject.NULL);

				// experience
				if (arrObj1.has("experience")) {

					org.json.JSONObject experience = new org.json.JSONObject();

					org.json.JSONObject getexperience = (org.json.JSONObject) arrObj1.get("experience");

					if (getexperience.has("months"))
						experience.put("months", (Integer) getexperience.get("months"));
					else
						experience.put("months", org.json.JSONObject.NULL);

					if (getexperience.has("totalExperience"))
						experience.put("totalExperience", getexperience.getString("totalExperience"));
					else
						experience.put("totalExperience", org.json.JSONObject.NULL);

					if (getexperience.has("years"))
						experience.put("years", (Integer) getexperience.get("years"));
					else
						experience.put("years", org.json.JSONObject.NULL);

					candijson.put("experience", experience);

				} else
					candijson.put("experience", org.json.JSONObject.NULL);

				// project
				if (arrObj1.has("project")) {

					org.json.JSONArray project = new org.json.JSONArray();
					org.json.JSONArray getproject = (org.json.JSONArray) arrObj1.get("project");

					org.json.JSONObject projectobject = new org.json.JSONObject();

					for (int i = 0; i < getproject.length(); i++) {

						org.json.JSONObject projectObj = new org.json.JSONObject();

						projectobject = (org.json.JSONObject) getproject.get(i);

						if (projectobject.has("title"))
							projectObj.put("title", projectobject.getString("title"));
						else
							projectObj.put("title", org.json.JSONObject.NULL);

						if (projectobject.has("role"))
							projectObj.put("role", projectobject.getString("role"));
						else
							projectObj.put("role", org.json.JSONObject.NULL);

						if (projectobject.has("fromMonth"))
							projectObj.put("fromMonth", projectobject.getString("fromMonth"));
						else
							projectObj.put("fromMonth", org.json.JSONObject.NULL);

						if (projectobject.has("fromYear"))
							projectObj.put("fromYear", projectobject.getString("fromYear"));
						else
							projectObj.put("fromYear", org.json.JSONObject.NULL);

						if (projectobject.has("toMonth"))
							projectObj.put("toMonth", projectobject.getString("toMonth"));
						else
							projectObj.put("toMonth", org.json.JSONObject.NULL);

						if (projectobject.has("toYear"))
							projectObj.put("toYear", projectobject.getString("toYear"));
						else
							projectObj.put("toYear", org.json.JSONObject.NULL);

						if (projectobject.has("url"))
							projectObj.put("url", projectobject.getString("url"));
						else
							projectObj.put("url", org.json.JSONObject.NULL);

						if (projectobject.has("description"))
							projectObj.put("description", projectobject.getString("description"));
						else
							projectObj.put("description", org.json.JSONObject.NULL);

						project.put(projectObj);

					}

					candijson.put("project", project);
				} else
					candijson.put("project", org.json.JSONObject.NULL);

				// Achievement
				if (arrObj1.has("achievement")) {

					org.json.JSONArray achievement = new org.json.JSONArray();
					org.json.JSONArray getachievement = arrObj1.getJSONArray("achievement");

					for (int i = 0; i < getachievement.length(); i++) {

						org.json.JSONObject Achievementobject = (org.json.JSONObject) getachievement.get(i);

						if (Achievementobject.has("title"))
							Achievementobject.put("title", Achievementobject.getString("title"));
						else
							Achievementobject.put("title", org.json.JSONObject.NULL);

						if (Achievementobject.has("roleAndResponsibility"))
							Achievementobject.put("roleAndResponsibility",
									Achievementobject.getString("roleAndResponsibility"));
						else
							Achievementobject.put("roleAndResponsibility", org.json.JSONObject.NULL);

						if (Achievementobject.has("description"))
							Achievementobject.put("description", Achievementobject.getString("description"));
						else
							Achievementobject.put("description", org.json.JSONObject.NULL);

						if (Achievementobject.has("achievementFile"))
							Achievementobject.put("achievementFile", Achievementobject.getString("achievementFile"));
						else
							Achievementobject.put("achievementFile", org.json.JSONObject.NULL);

						achievement.put(Achievementobject);
					}

					candijson.put("achievement", achievement);

				} else
					candijson.put("achievement", org.json.JSONObject.NULL);

				// Certificates
				if (arrObj1.has("certificates")) {

					org.json.JSONArray getcertificates = (org.json.JSONArray) arrObj1.get("certificates");
					org.json.JSONArray certificates = new org.json.JSONArray();

					for (int i = 0; i < getcertificates.length(); i++) {

						org.json.JSONObject certificatesobject = (org.json.JSONObject) getcertificates.get(i);

						if (certificatesobject.has("title"))
							certificatesobject.put("title", certificatesobject.getString("title"));
						else
							certificatesobject.put("title", org.json.JSONObject.NULL);

						if (certificatesobject.has("fromMonth"))
							certificatesobject.put("fromMonth", certificatesobject.getString("fromMonth"));
						else
							certificatesobject.put("fromMonth", org.json.JSONObject.NULL);

						if (certificatesobject.has("fromYear"))
							certificatesobject.put("fromYear", certificatesobject.getString("fromYear"));
						else
							certificatesobject.put("fromYear", org.json.JSONObject.NULL);

						if (certificatesobject.has("toMonth"))
							certificatesobject.put("toMonth", certificatesobject.getString("toMonth"));
						else
							certificatesobject.put("toMonth", org.json.JSONObject.NULL);

						if (certificatesobject.has("toYear"))
							certificatesobject.put("toYear", certificatesobject.getString("toYear"));
						else
							certificatesobject.put("toYear", org.json.JSONObject.NULL);

						if (certificatesobject.has("description"))
							certificatesobject.put("description", certificatesobject.getString("description"));
						else
							certificatesobject.put("description", org.json.JSONObject.NULL);

						if (certificatesobject.has("certificateFile"))
							certificatesobject.put("certificateFile", certificatesobject.getString("certificateFile"));
						else
							certificatesobject.put("certificateFile", org.json.JSONObject.NULL);

						certificates.put(certificatesobject);

					}

					candijson.put("certificates", certificates);
				} else
					candijson.put("certificates", org.json.JSONObject.NULL);

				// HTML
				if (arrObj1.has("html")) {
					org.json.JSONObject gethtml = (org.json.JSONObject) arrObj1.get("html");
					org.json.JSONObject html = new org.json.JSONObject();

					if (gethtml.has("naukri")) {

						org.json.JSONObject subHTML = (org.json.JSONObject) gethtml.get("naukri");
						org.json.JSONObject naukri = new org.json.JSONObject();

						if (subHTML.has("empId"))
							naukri.put("empId", subHTML.getString("empId"));
						else
							naukri.put("empId", org.json.JSONObject.NULL);

						if (subHTML.has("lastModified"))
							naukri.put("lastModified", subHTML.getString("lastModified"));
						else
							naukri.put("lastModified", org.json.JSONObject.NULL);

						if (subHTML.has("html"))
							naukri.put("html", subHTML.getString("html"));
						else
							naukri.put("html", org.json.JSONObject.NULL);

						html.put("naukri", naukri);

					} else
						html.put("naukri", org.json.JSONObject.NULL);

					if (gethtml.has("linkedIn")) {
						org.json.JSONObject subHTML = (org.json.JSONObject) gethtml.get("linkedIn");

						org.json.JSONObject linkedIn = new org.json.JSONObject();

						if (subHTML.has("empId"))
							linkedIn.put("empId", subHTML.getString("empId"));
						else
							linkedIn.put("empId", org.json.JSONObject.NULL);

						if (subHTML.has("lastModified"))
							linkedIn.put("lastModified", subHTML.getString("lastModified"));
						else
							linkedIn.put("lastModified", org.json.JSONObject.NULL);

						if (subHTML.has("html"))
							linkedIn.put("html", subHTML.getString("html"));
						else
							linkedIn.put("html", org.json.JSONObject.NULL);

						html.put("linkedIn", linkedIn);

					} else
						html.put("linkedIn", org.json.JSONObject.NULL);

					if (gethtml.has("monster")) {
						org.json.JSONObject subHTML = (org.json.JSONObject) gethtml.get("monster");

						org.json.JSONObject monster = new org.json.JSONObject();

						if (subHTML.has("empId"))
							monster.put("empId", subHTML.getString("empId"));
						else
							monster.put("empId", org.json.JSONObject.NULL);

						if (subHTML.has("lastModified"))
							monster.put("lastModified", subHTML.getString("lastModified"));
						else
							monster.put("lastModified", org.json.JSONObject.NULL);

						if (subHTML.has("html"))
							monster.put("html", subHTML.getString("html"));
						else
							monster.put("html", org.json.JSONObject.NULL);

						html.put("monster", monster);

					} else
						html.put("monster", org.json.JSONObject.NULL);

					if (gethtml.has("naukriGulf")) {
						org.json.JSONObject subHTML = (org.json.JSONObject) gethtml.get("naukriGulf");

						org.json.JSONObject naukriGulf = new org.json.JSONObject();

						if (subHTML.has("empId"))
							naukriGulf.put("empId", subHTML.getString("empId"));
						else
							naukriGulf.put("empId", org.json.JSONObject.NULL);

						if (subHTML.has("lastModified"))
							naukriGulf.put("lastModified", subHTML.getString("lastModified"));
						else
							naukriGulf.put("lastModified", org.json.JSONObject.NULL);

						if (subHTML.has("html"))
							naukriGulf.put("html", subHTML.getString("html"));
						else
							naukriGulf.put("html", org.json.JSONObject.NULL);

						html.put("naukriGulf", naukriGulf);

					} else
						html.put("naukriGulf", org.json.JSONObject.NULL);

					if (gethtml.has("careerBuilder")) {
						org.json.JSONObject subHTML = (org.json.JSONObject) gethtml.get("careerBuilder");

						org.json.JSONObject careerBuilder = new org.json.JSONObject();

						if (subHTML.has("empId"))
							careerBuilder.put("empId", subHTML.getString("empId"));
						else
							careerBuilder.put("empId", org.json.JSONObject.NULL);

						if (subHTML.has("lastModified"))
							careerBuilder.put("lastModified", subHTML.getString("lastModified"));
						else
							careerBuilder.put("lastModified", org.json.JSONObject.NULL);

						if (subHTML.has("html"))
							careerBuilder.put("html", subHTML.getString("html"));
						else
							careerBuilder.put("html", org.json.JSONObject.NULL);

						html.put("careerBuilder", careerBuilder);

					} else
						html.put("careerBuilder", org.json.JSONObject.NULL);

					if (gethtml.has("monsterUS")) {
						org.json.JSONObject subHTML = (org.json.JSONObject) gethtml.get("monsterUS");

						org.json.JSONObject monsterUS = new org.json.JSONObject();

						if (subHTML.has("empId"))
							monsterUS.put("empId", subHTML.getString("empId"));
						else
							monsterUS.put("empId", org.json.JSONObject.NULL);

						if (subHTML.has("lastModified"))
							monsterUS.put("lastModified", subHTML.getString("lastModified"));
						else
							monsterUS.put("lastModified", org.json.JSONObject.NULL);

						if (subHTML.has("html"))
							monsterUS.put("html", subHTML.getString("html"));
						else
							monsterUS.put("html", org.json.JSONObject.NULL);

						html.put("monsterUS", monsterUS);

					} else
						html.put("monsterUS", org.json.JSONObject.NULL);

					if (gethtml.has("dice")) {
						org.json.JSONObject subHTML = (org.json.JSONObject) gethtml.get("dice");

						org.json.JSONObject dice = new org.json.JSONObject();

						if (subHTML.has("empId"))
							dice.put("empId", subHTML.getString("empId"));
						else
							dice.put("empId", org.json.JSONObject.NULL);

						if (subHTML.has("lastModified"))
							dice.put("lastModified", subHTML.getString("lastModified"));
						else
							dice.put("lastModified", org.json.JSONObject.NULL);

						if (subHTML.has("html"))
							dice.put("html", subHTML.getString("html"));
						else
							dice.put("html", org.json.JSONObject.NULL);

						html.put("dice", dice);

					} else
						html.put("dice", org.json.JSONObject.NULL);

					if (gethtml.has("jobDiva")) {
						org.json.JSONObject subHTML = (org.json.JSONObject) gethtml.get("jobDiva");

						org.json.JSONObject jobDiva = new org.json.JSONObject();

						if (subHTML.has("empId"))
							jobDiva.put("empId", subHTML.getString("empId"));
						else
							jobDiva.put("empId", org.json.JSONObject.NULL);

						if (subHTML.has("lastModified"))
							jobDiva.put("lastModified", subHTML.getString("lastModified"));
						else
							jobDiva.put("lastModified", org.json.JSONObject.NULL);

						if (subHTML.has("html"))
							jobDiva.put("html", subHTML.getString("html"));
						else
							jobDiva.put("html", org.json.JSONObject.NULL);

						html.put("jobDiva", jobDiva);

					} else
						html.put("jobDiva", org.json.JSONObject.NULL);

					if (gethtml.has("indeed")) {
						org.json.JSONObject subHTML = (org.json.JSONObject) gethtml.get("indeed");

						org.json.JSONObject indeed = new org.json.JSONObject();

						if (subHTML.has("empId"))
							indeed.put("empId", subHTML.getString("empId"));
						else
							indeed.put("empId", org.json.JSONObject.NULL);

						if (subHTML.has("lastModified"))
							indeed.put("lastModified", subHTML.getString("lastModified"));
						else
							indeed.put("lastModified", org.json.JSONObject.NULL);

						if (subHTML.has("html"))
							indeed.put("html", subHTML.getString("html"));
						else
							indeed.put("html", org.json.JSONObject.NULL);

						html.put("indeed", indeed);

					} else
						html.put("indeed", org.json.JSONObject.NULL);

					if (gethtml.has("jobServe")) {
						org.json.JSONObject subHTML = (org.json.JSONObject) gethtml.get("jobServe");

						org.json.JSONObject jobServe = new org.json.JSONObject();

						if (subHTML.has("empId"))
							jobServe.put("empId", subHTML.getString("empId"));
						else
							jobServe.put("empId", org.json.JSONObject.NULL);

						if (subHTML.has("lastModified"))
							jobServe.put("lastModified", subHTML.getString("lastModified"));
						else
							jobServe.put("lastModified", org.json.JSONObject.NULL);

						if (subHTML.has("html"))
							jobServe.put("html", subHTML.getString("html"));
						else
							jobServe.put("html", org.json.JSONObject.NULL);

						html.put("jobServe", jobServe);

					} else
						html.put("jobServe", org.json.JSONObject.NULL);

					if (gethtml.has("other")) {
						org.json.JSONObject subHTML = (org.json.JSONObject) gethtml.get("other");

						org.json.JSONObject other = new org.json.JSONObject();

						if (subHTML.has("empId"))
							other.put("empId", subHTML.getString("empId"));
						else
							other.put("empId", org.json.JSONObject.NULL);

						if (subHTML.has("lastModified"))
							other.put("lastModified", subHTML.getString("lastModified"));
						else
							other.put("lastModified", org.json.JSONObject.NULL);

						if (subHTML.has("html"))
							other.put("html", subHTML.getString("html"));
						else
							other.put("html", org.json.JSONObject.NULL);

						html.put("other", other);

					} else
						html.put("other", org.json.JSONObject.NULL);

					candijson.put("html", html);
				} else
					candijson.put("html", org.json.JSONObject.NULL);

				if (arrObj1.has("resumeName"))
					candijson.put("resumeName", arrObj1.get("resumeName"));
				else
					candijson.put("resumeName", org.json.JSONObject.NULL);

				if (arrObj1.has("resume"))
					candijson.put("resume", arrObj1.get("resume"));
				else
					candijson.put("resume", org.json.JSONObject.NULL);

				candijson = excludeFields(candijson, excludeFields);

				candijsonArr.put(candijson);
			}

			maincandijson.put("total", hits.get("total"));
			maincandijson.put("response", candijsonArr);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return maincandijson.toString();
	}

	public org.json.JSONObject excludeFields(org.json.JSONObject json, String excludeFields) throws JSONException {

        if (!excludeFields.equals("")) {
            String[] exF = excludeFields.split(",");
            for (String s : exF) {
                  if (json.has(s) && !s.contains("."))
                         json.remove(s);
                  else if (s.contains(".")) {
                         s = s.replace(".", ",");
                         String exar[] = s.split(",");
                         if (json.has(exar[0])) {
                                org.json.JSONObject firstobj = (org.json.JSONObject) json.get(exar[0]);
                                json.remove(exar[0]);

                                if (exar.length > 2) {
                                       org.json.JSONObject secondObj = (org.json.JSONObject) firstobj.get(exar[1]);
                                       secondObj.remove(exar[2]);
                                       firstobj.put(exar[1], secondObj);
                                       json.put(exar[0], firstobj);
                                } else {
                                       firstobj.remove(exar[1]);
                                       json.put(exar[0], firstobj);
                                }
                         }

                  }
            }
     }
     return json;

	}

	public org.json.JSONObject getCompleteJSONObject(org.json.JSONObject json, String key) throws JSONException {

		String subkey = "";
		if (key.contains(".")) {
			subkey = key.substring(key.indexOf(".") + 1);
			key = key.replace("." + subkey, "");
		}

		// Address
		if (key.equals("address")) {

			if (json.has("permanentAddress") && (subkey.equals("") || subkey.equals("permanentAddress"))) {

				org.json.JSONObject addressJ = (org.json.JSONObject) json.get("permanentAddress");

				if (!addressJ.has("country"))
					addressJ.put("country", org.json.JSONObject.NULL);

				if (!addressJ.has("state"))
					addressJ.put("state", org.json.JSONObject.NULL);

				if (!addressJ.has("city"))
					addressJ.put("city", org.json.JSONObject.NULL);

				if (!addressJ.has("street"))
					addressJ.put("street", org.json.JSONObject.NULL);

				if (!addressJ.has("pincode"))
					addressJ.put("pincode", org.json.JSONObject.NULL);

				if (!addressJ.has("location"))
					addressJ.put("location", org.json.JSONObject.NULL);

				json.put("permanentAddress", addressJ);

			} else if (subkey.equals(""))
				json.put("permanentAddress", org.json.JSONObject.NULL);

			if (json.has("currentAddress") && (subkey.equals("") || subkey.equals("currentAddress"))) {
				org.json.JSONObject addressJ = (org.json.JSONObject) json.get("currentAddress");

				if (!addressJ.has("country"))
					addressJ.put("country", org.json.JSONObject.NULL);

				if (!addressJ.has("state"))
					addressJ.put("state", org.json.JSONObject.NULL);

				if (!addressJ.has("city"))
					addressJ.put("city", org.json.JSONObject.NULL);

				if (!addressJ.has("street"))
					addressJ.put("street", org.json.JSONObject.NULL);

				if (!addressJ.has("pincode"))
					addressJ.put("pincode", org.json.JSONObject.NULL);

				if (!addressJ.has("location"))
					addressJ.put("location", org.json.JSONObject.NULL);

				json.put("currentAddress", addressJ);
			} else if (subkey.equals(""))
				json.put("currentAddress", org.json.JSONObject.NULL);

		}

		// education
		if (key.equals("education")) {

			if (json.has("ug") && (subkey.equals("") || subkey.equals("ug"))) {

				org.json.JSONObject educationjson1 = (org.json.JSONObject) json.get("ug");

				if (!educationjson1.has("degree"))
					educationjson1.put("degree", org.json.JSONObject.NULL);

				if (!educationjson1.has("degreeType"))
					educationjson1.put("degreeType", org.json.JSONObject.NULL);

				if (!educationjson1.has("course"))
					educationjson1.put("course", org.json.JSONObject.NULL);

				if (!educationjson1.has("institute"))
					educationjson1.put("institute", org.json.JSONObject.NULL);

				if (!educationjson1.has("universityOrBoard"))
					educationjson1.put("universityOrBoard", org.json.JSONObject.NULL);

				if (!educationjson1.has("city"))
					educationjson1.put("city", org.json.JSONObject.NULL);

				if (!educationjson1.has("fromMonth"))
					educationjson1.put("fromMonth", org.json.JSONObject.NULL);

				if (!educationjson1.has("fromYear"))
					educationjson1.put("fromYear", org.json.JSONObject.NULL);

				if (!educationjson1.has("toMonth"))
					educationjson1.put("toMonth", org.json.JSONObject.NULL);

				if (!educationjson1.has("toYear"))
					educationjson1.put("toYear", org.json.JSONObject.NULL);

				if (!educationjson1.has("percentage"))
					educationjson1.put("percentage", org.json.JSONObject.NULL);

				json.put("ug", educationjson1);
			} else if (subkey.equals(""))
				json.put("ug", org.json.JSONObject.NULL);

			if (json.has("pg") && (subkey.equals("") || subkey.equals("pg"))) {

				org.json.JSONObject educationjson1 = (org.json.JSONObject) json.get("pg");

				if (!educationjson1.has("degree"))
					educationjson1.put("degree", org.json.JSONObject.NULL);

				if (!educationjson1.has("degreeType"))
					educationjson1.put("degreeType", org.json.JSONObject.NULL);

				if (!educationjson1.has("course"))
					educationjson1.put("course", org.json.JSONObject.NULL);

				if (!educationjson1.has("institute"))
					educationjson1.put("institute", org.json.JSONObject.NULL);

				if (!educationjson1.has("universityOrBoard"))
					educationjson1.put("universityOrBoard", org.json.JSONObject.NULL);

				if (!educationjson1.has("city"))
					educationjson1.put("city", org.json.JSONObject.NULL);

				if (!educationjson1.has("fromMonth"))
					educationjson1.put("fromMonth", org.json.JSONObject.NULL);

				if (!educationjson1.has("fromYear"))
					educationjson1.put("fromYear", org.json.JSONObject.NULL);

				if (!educationjson1.has("toMonth"))
					educationjson1.put("toMonth", org.json.JSONObject.NULL);

				if (!educationjson1.has("toYear"))
					educationjson1.put("toYear", org.json.JSONObject.NULL);

				if (!educationjson1.has("percentage"))
					educationjson1.put("percentage", org.json.JSONObject.NULL);

				json.put("pg", educationjson1);

			} else if (subkey.equals(""))
				json.put("pg", org.json.JSONObject.NULL); // end pg

			if (json.has("doctorate") && (subkey.equals("") || subkey.equals("doctorate"))) {

				org.json.JSONObject educationjson1 = (org.json.JSONObject) json.get("doctorate");

				if (!educationjson1.has("degree"))
					educationjson1.put("degree", org.json.JSONObject.NULL);

				if (!educationjson1.has("degreeType"))
					educationjson1.put("degreeType", org.json.JSONObject.NULL);

				if (!educationjson1.has("course"))
					educationjson1.put("course", org.json.JSONObject.NULL);

				if (!educationjson1.has("institute"))
					educationjson1.put("institute", org.json.JSONObject.NULL);

				if (!educationjson1.has("universityOrBoard"))
					educationjson1.put("universityOrBoard", org.json.JSONObject.NULL);

				if (!educationjson1.has("city"))
					educationjson1.put("city", org.json.JSONObject.NULL);

				if (!educationjson1.has("fromMonth"))
					educationjson1.put("fromMonth", org.json.JSONObject.NULL);

				if (!educationjson1.has("fromYear"))
					educationjson1.put("fromYear", org.json.JSONObject.NULL);

				if (!educationjson1.has("toMonth"))
					educationjson1.put("toMonth", org.json.JSONObject.NULL);

				if (!educationjson1.has("toYear"))
					educationjson1.put("toYear", org.json.JSONObject.NULL);

				if (!educationjson1.has("percentage"))
					educationjson1.put("percentage", org.json.JSONObject.NULL);

				json.put("doctorate", educationjson1);

			} else if (subkey.equals(""))
				json.put("doctorate", org.json.JSONObject.NULL);

			if (json.has("diploma") && (subkey.equals("") || subkey.equals("diploma"))) {

				org.json.JSONObject educationjson1 = (org.json.JSONObject) json.get("diploma");

				if (!educationjson1.has("degree"))
					educationjson1.put("degree", org.json.JSONObject.NULL);

				if (!educationjson1.has("degreeType"))
					educationjson1.put("degreeType", org.json.JSONObject.NULL);

				if (!educationjson1.has("course"))
					educationjson1.put("course", org.json.JSONObject.NULL);

				if (!educationjson1.has("institute"))
					educationjson1.put("institute", org.json.JSONObject.NULL);

				if (!educationjson1.has("universityOrBoard"))
					educationjson1.put("universityOrBoard", org.json.JSONObject.NULL);

				if (!educationjson1.has("city"))
					educationjson1.put("city", org.json.JSONObject.NULL);

				if (!educationjson1.has("fromMonth"))
					educationjson1.put("fromMonth", org.json.JSONObject.NULL);

				if (!educationjson1.has("fromYear"))
					educationjson1.put("fromYear", org.json.JSONObject.NULL);

				if (!educationjson1.has("toMonth"))
					educationjson1.put("toMonth", org.json.JSONObject.NULL);

				if (!educationjson1.has("toYear"))
					educationjson1.put("toYear", org.json.JSONObject.NULL);

				if (!educationjson1.has("percentage"))
					educationjson1.put("percentage", org.json.JSONObject.NULL);

				json.put("diploma", educationjson1);

			} else if (subkey.equals(""))
				json.put("diploma", org.json.JSONObject.NULL);

			if (json.has("twelveth") && (subkey.equals("") || subkey.equals("twelveth"))) {

				org.json.JSONObject educationjson1 = (org.json.JSONObject) json.get("twelveth");

				if (!educationjson1.has("degree"))
					educationjson1.put("degree", org.json.JSONObject.NULL);

				if (!educationjson1.has("degreeType"))
					educationjson1.put("degreeType", org.json.JSONObject.NULL);

				if (!educationjson1.has("course"))
					educationjson1.put("course", org.json.JSONObject.NULL);

				if (!educationjson1.has("institute"))
					educationjson1.put("institute", org.json.JSONObject.NULL);

				if (!educationjson1.has("universityOrBoard"))
					educationjson1.put("universityOrBoard", org.json.JSONObject.NULL);

				if (!educationjson1.has("city"))
					educationjson1.put("city", org.json.JSONObject.NULL);

				if (!educationjson1.has("fromMonth"))
					educationjson1.put("fromMonth", org.json.JSONObject.NULL);

				if (!educationjson1.has("fromYear"))
					educationjson1.put("fromYear", org.json.JSONObject.NULL);

				if (!educationjson1.has("toMonth"))
					educationjson1.put("toMonth", org.json.JSONObject.NULL);

				if (!educationjson1.has("toYear"))
					educationjson1.put("toYear", org.json.JSONObject.NULL);

				if (!educationjson1.has("percentage"))
					educationjson1.put("percentage", org.json.JSONObject.NULL);

				json.put("twelveth", educationjson1);

			} else if (subkey.equals(""))
				json.put("twelveth", org.json.JSONObject.NULL);

			if (json.has("tenth") && (subkey.equals("") || subkey.equals("tenth"))) {

				org.json.JSONObject educationjson1 = (org.json.JSONObject) json.get("tenth");

				if (!educationjson1.has("degree"))
					educationjson1.put("degree", org.json.JSONObject.NULL);

				if (!educationjson1.has("degreeType"))
					educationjson1.put("degreeType", org.json.JSONObject.NULL);

				if (!educationjson1.has("course"))
					educationjson1.put("course", org.json.JSONObject.NULL);

				if (!educationjson1.has("institute"))
					educationjson1.put("institute", org.json.JSONObject.NULL);

				if (!educationjson1.has("universityOrBoard"))
					educationjson1.put("universityOrBoard", org.json.JSONObject.NULL);

				if (!educationjson1.has("city"))
					educationjson1.put("city", org.json.JSONObject.NULL);

				if (!educationjson1.has("fromMonth"))
					educationjson1.put("fromMonth", org.json.JSONObject.NULL);

				if (!educationjson1.has("fromYear"))
					educationjson1.put("fromYear", org.json.JSONObject.NULL);

				if (!educationjson1.has("toMonth"))
					educationjson1.put("toMonth", org.json.JSONObject.NULL);

				if (!educationjson1.has("toYear"))
					educationjson1.put("toYear", org.json.JSONObject.NULL);

				if (!educationjson1.has("percentage"))
					educationjson1.put("percentage", org.json.JSONObject.NULL);

				json.put("tenth", educationjson1);

			} else if (subkey.equals(""))
				json.put("tenth", org.json.JSONObject.NULL);

		}

		// employment
		if (key.equals("employment")) {

			if (json.has("current") && (subkey.equals("") || subkey.equals("current"))) {

				org.json.JSONObject getcurrent = json.getJSONObject("current");

				if (!getcurrent.has("organization"))
					getcurrent.put("organization", org.json.JSONObject.NULL);

				if (!getcurrent.has("designation"))
					getcurrent.put("designation", org.json.JSONObject.NULL);

				if (!getcurrent.has("description"))
					getcurrent.put("description", org.json.JSONObject.NULL);

				if (!getcurrent.has("fromMonth"))
					getcurrent.put("fromMonth", org.json.JSONObject.NULL);

				if (!getcurrent.has("fromYear"))
					getcurrent.put("fromYear", org.json.JSONObject.NULL);

				if (!getcurrent.has("toMonth"))
					getcurrent.put("toMonth", org.json.JSONObject.NULL);

				if (!getcurrent.has("toYear"))
					getcurrent.put("toYear", org.json.JSONObject.NULL);

				if (!getcurrent.has("workLocation"))
					getcurrent.put("workLocation", org.json.JSONObject.NULL);

				if (!getcurrent.has("role"))
					getcurrent.put("role", org.json.JSONObject.NULL);

				if (!getcurrent.has("level"))
					getcurrent.put("level", org.json.JSONObject.NULL);

				if (!getcurrent.has("teamSize"))
					getcurrent.put("teamSize", org.json.JSONObject.NULL);

				json.put("current", getcurrent);
			} else if (subkey.equals(""))
				json.put("current", org.json.JSONObject.NULL);

			if (json.has("previous") && (subkey.equals("") || subkey.equals("previous"))) {

				org.json.JSONArray previous = new org.json.JSONArray();

				org.json.JSONArray getprevious = json.getJSONArray("previous");
				int i = 0;

				for (i = 0; i < getprevious.length(); i++) {

					org.json.JSONObject jsonprevious = (org.json.JSONObject) getprevious.get(i);

					if (!jsonprevious.has("organization"))
						jsonprevious.put("organization", org.json.JSONObject.NULL);

					if (!jsonprevious.has("designation"))
						jsonprevious.put("designation", org.json.JSONObject.NULL);

					if (!jsonprevious.has("level"))
						jsonprevious.put("level", org.json.JSONObject.NULL);

					if (!jsonprevious.has("city"))
						jsonprevious.put("city", org.json.JSONObject.NULL);

					if (!jsonprevious.has("fromMonth"))
						jsonprevious.put("fromMonth", org.json.JSONObject.NULL);

					if (!jsonprevious.has("fromYear"))
						jsonprevious.put("fromYear", org.json.JSONObject.NULL);

					if (!jsonprevious.has("toMonth"))
						jsonprevious.put("toMonth", org.json.JSONObject.NULL);

					if (!jsonprevious.has("toYear"))
						jsonprevious.put("toYear", org.json.JSONObject.NULL);

					if (!jsonprevious.has("description"))
						jsonprevious.put("description", org.json.JSONObject.NULL);

					previous.put(jsonprevious);
				}
				json.put("previous", previous);
			} else if (subkey.equals(""))
				json.put("previous", org.json.JSONObject.NULL);

		}

		// salary
		if (key.equals("salary")) {

			if (!json.has("currentCTCType"))
				json.put("currentCTCType", org.json.JSONObject.NULL);

			if (!json.has("currentCTC"))
				json.put("currentCTC", org.json.JSONObject.NULL);

			if (!json.has("negotiableCTC"))
				json.put("negotiableCTC", org.json.JSONObject.NULL);

			if (!json.has("expectedCTCType"))
				json.put("expectedCTCType", org.json.JSONObject.NULL);

			if (!json.has("expectedCTC"))
				json.put("expectedCTC", org.json.JSONObject.NULL);

			if (!json.has("takeHome"))
				json.put("takeHome", org.json.JSONObject.NULL);

			if (!json.has("fixed"))
				json.put("fixed", org.json.JSONObject.NULL);

		}

		// experience
		if (key.equals("experience")) {

			if (!json.has("months"))
				json.put("months", org.json.JSONObject.NULL);

			if (!json.has("totalExperience"))
				json.put("totalExperience", org.json.JSONObject.NULL);

			if (!json.has("years"))
				json.put("years", org.json.JSONObject.NULL);

		}

		// HTML
		if (key.equals("html")) {

			if (json.has("naukri")) {

				org.json.JSONObject subHTML = (org.json.JSONObject) json.get("naukri");

				if (!subHTML.has("empId"))
					subHTML.put("empId", org.json.JSONObject.NULL);

				if (!subHTML.has("lastModified"))
					subHTML.put("lastModified", org.json.JSONObject.NULL);

				if (!subHTML.has("html"))
					subHTML.put("html", org.json.JSONObject.NULL);

				json.put("naukri", subHTML);

			} else if (subkey.equals(""))
				json.put("naukri", org.json.JSONObject.NULL);

			if (json.has("linkedIn")) {
				org.json.JSONObject subHTML = (org.json.JSONObject) json.get("linkedIn");

				if (!subHTML.has("empId"))
					subHTML.put("empId", org.json.JSONObject.NULL);

				if (!subHTML.has("lastModified"))
					subHTML.put("lastModified", org.json.JSONObject.NULL);

				if (!subHTML.has("html"))
					subHTML.put("html", org.json.JSONObject.NULL);

				json.put("linkedIn", subHTML);

			} else if (subkey.equals(""))
				json.put("linkedIn", org.json.JSONObject.NULL);

			if (json.has("monster")) {
				org.json.JSONObject subHTML = (org.json.JSONObject) json.get("monster");

				if (!subHTML.has("empId"))
					subHTML.put("empId", org.json.JSONObject.NULL);

				if (!subHTML.has("lastModified"))
					subHTML.put("lastModified", org.json.JSONObject.NULL);

				if (!subHTML.has("html"))
					subHTML.put("html", org.json.JSONObject.NULL);

				json.put("monster", subHTML);

			} else if (subkey.equals(""))
				json.put("monster", org.json.JSONObject.NULL);

			if (json.has("naukriGulf")) {
				org.json.JSONObject subHTML = (org.json.JSONObject) json.get("naukriGulf");

				if (!subHTML.has("empId"))
					subHTML.put("empId", org.json.JSONObject.NULL);

				if (!subHTML.has("lastModified"))
					subHTML.put("lastModified", org.json.JSONObject.NULL);

				if (!subHTML.has("html"))
					subHTML.put("html", org.json.JSONObject.NULL);

				json.put("naukriGulf", subHTML);

			} else if (subkey.equals(""))
				json.put("naukriGulf", org.json.JSONObject.NULL);

			if (json.has("careerBuilder")) {
				org.json.JSONObject subHTML = (org.json.JSONObject) json.get("careerBuilder");

				if (!subHTML.has("empId"))
					subHTML.put("empId", org.json.JSONObject.NULL);

				if (!subHTML.has("lastModified"))
					subHTML.put("lastModified", org.json.JSONObject.NULL);

				if (!subHTML.has("html"))
					subHTML.put("html", org.json.JSONObject.NULL);

				json.put("careerBuilder", subHTML);

			} else if (subkey.equals(""))
				json.put("careerBuilder", org.json.JSONObject.NULL);

			if (json.has("monsterUS")) {
				org.json.JSONObject subHTML = (org.json.JSONObject) json.get("monsterUS");

				if (!subHTML.has("empId"))
					subHTML.put("empId", org.json.JSONObject.NULL);

				if (!subHTML.has("lastModified"))
					subHTML.put("lastModified", org.json.JSONObject.NULL);

				if (!subHTML.has("html"))
					subHTML.put("html", org.json.JSONObject.NULL);

				json.put("monsterUS", subHTML);

			} else if (subkey.equals(""))
				json.put("monsterUS", org.json.JSONObject.NULL);

			if (json.has("dice")) {
				org.json.JSONObject subHTML = (org.json.JSONObject) json.get("dice");

				if (!subHTML.has("empId"))
					subHTML.put("empId", org.json.JSONObject.NULL);

				if (!subHTML.has("lastModified"))
					subHTML.put("lastModified", org.json.JSONObject.NULL);

				if (!subHTML.has("html"))
					subHTML.put("html", org.json.JSONObject.NULL);

				json.put("dice", subHTML);

			} else if (subkey.equals(""))
				json.put("dice", org.json.JSONObject.NULL);

			if (json.has("jobDiva")) {
				org.json.JSONObject subHTML = (org.json.JSONObject) json.get("jobDiva");

				if (!subHTML.has("empId"))
					subHTML.put("empId", org.json.JSONObject.NULL);

				if (!subHTML.has("lastModified"))
					subHTML.put("lastModified", org.json.JSONObject.NULL);

				if (!subHTML.has("html"))
					subHTML.put("html", org.json.JSONObject.NULL);

				json.put("jobDiva", subHTML);

			} else if (subkey.equals(""))
				json.put("jobDiva", org.json.JSONObject.NULL);

			if (json.has("indeed")) {
				org.json.JSONObject subHTML = (org.json.JSONObject) json.get("indeed");

				if (!subHTML.has("empId"))
					subHTML.put("empId", org.json.JSONObject.NULL);

				if (!subHTML.has("lastModified"))
					subHTML.put("lastModified", org.json.JSONObject.NULL);

				if (!subHTML.has("html"))
					subHTML.put("html", org.json.JSONObject.NULL);

				json.put("indeed", subHTML);

			} else if (subkey.equals(""))
				json.put("indeed", org.json.JSONObject.NULL);

			if (json.has("jobServe")) {
				org.json.JSONObject subHTML = (org.json.JSONObject) json.get("jobServe");

				if (!subHTML.has("empId"))
					subHTML.put("empId", org.json.JSONObject.NULL);

				if (!subHTML.has("lastModified"))
					subHTML.put("lastModified", org.json.JSONObject.NULL);

				if (!subHTML.has("html"))
					subHTML.put("html", org.json.JSONObject.NULL);

				json.put("jobServe", subHTML);

			} else if (subkey.equals(""))
				json.put("jobServe", org.json.JSONObject.NULL);

			if (json.has("other")) {
				org.json.JSONObject subHTML = (org.json.JSONObject) json.get("other");

				if (!subHTML.has("empId"))
					subHTML.put("empId", org.json.JSONObject.NULL);

				if (!subHTML.has("lastModified"))
					subHTML.put("lastModified", org.json.JSONObject.NULL);

				if (!subHTML.has("html"))
					subHTML.put("html", org.json.JSONObject.NULL);

				json.put("other", subHTML);

			} else if (subkey.equals(""))
				json.put("other", org.json.JSONObject.NULL);
		}
		return json;
	}

	public org.json.JSONArray getCompleteJSONArray(org.json.JSONArray json, String key) throws JSONException {
		org.json.JSONArray result = new org.json.JSONArray();

		// family
		if (key.equals("family")) {
			for (int i = 0; i < json.length(); i++) {
				org.json.JSONObject familyobject = (org.json.JSONObject) json.get(i);

				if (!familyobject.has("name"))
					familyobject.put("name", org.json.JSONObject.NULL);

				if (!familyobject.has("occupation"))
					familyobject.put("occupation", org.json.JSONObject.NULL);

				if (!familyobject.has("location"))
					familyobject.put("location", org.json.JSONObject.NULL);

				if (!familyobject.has("relationship"))
					familyobject.put("relationship", org.json.JSONObject.NULL);

				result.put(familyobject);
			}
		}

		// Connect Social Network
		if (key.equals("connectSocialNetwork")) {
			for (int i = 0; i < json.length(); i++) {
				org.json.JSONObject cnsobject = (org.json.JSONObject) json.get(i);
				if (!cnsobject.has("name"))
					cnsobject.put("name", org.json.JSONObject.NULL);

				if (!cnsobject.has("url"))
					cnsobject.put("url", org.json.JSONObject.NULL);

				result.put(cnsobject);
			}
		}

		// referral
		if (key.equals("referral")) {
			for (int i = 0; i < json.length(); i++) {
				org.json.JSONObject referralobject = (org.json.JSONObject) json.get(i);

				if (!referralobject.has("name"))
					referralobject.put("name", org.json.JSONObject.NULL);

				if (!referralobject.has("officeEmail"))
					referralobject.put("officeEmail", org.json.JSONObject.NULL);

				if (!referralobject.has("officePhone"))
					referralobject.put("officePhone", org.json.JSONObject.NULL);

				if (!referralobject.has("company"))
					referralobject.put("company", org.json.JSONObject.NULL);

				if (!referralobject.has("title"))
					referralobject.put("title", org.json.JSONObject.NULL);

				if (!referralobject.has("description"))
					referralobject.put("description", org.json.JSONObject.NULL);

				result.put(referralobject);

			}
		}

		// skills
		if (key.equals("skills")) {
			for (int i = 0; i < json.length(); i++) {
				org.json.JSONObject getskillobject = (org.json.JSONObject) json.get(i);
				if (!getskillobject.has("keySkill"))
					getskillobject.put("keySkill", org.json.JSONObject.NULL);

				if (!getskillobject.has("experience"))
					getskillobject.put("experience", org.json.JSONObject.NULL);

				if (!getskillobject.has("fromMonth"))
					getskillobject.put("fromMonth", org.json.JSONObject.NULL);

				if (!getskillobject.has("fromYear"))
					getskillobject.put("fromYear", org.json.JSONObject.NULL);

				if (!getskillobject.has("toMonth"))
					getskillobject.put("toMonth", org.json.JSONObject.NULL);

				if (!getskillobject.has("toYear"))
					getskillobject.put("toYear", org.json.JSONObject.NULL);

				result.put(getskillobject);
			}
		}

		// project
		if (key.equals("project")) {
			for (int i = 0; i < json.length(); i++) {
				org.json.JSONObject projectobject = (org.json.JSONObject) json.get(i);

				if (!projectobject.has("title"))
					projectobject.put("title", org.json.JSONObject.NULL);

				if (!projectobject.has("role"))
					projectobject.put("role", org.json.JSONObject.NULL);

				if (!projectobject.has("fromMonth"))
					projectobject.put("fromMonth", org.json.JSONObject.NULL);

				if (!projectobject.has("fromYear"))
					projectobject.put("fromYear", org.json.JSONObject.NULL);

				if (!projectobject.has("toMonth"))
					projectobject.put("toMonth", org.json.JSONObject.NULL);

				if (!projectobject.has("toYear"))
					projectobject.put("toYear", org.json.JSONObject.NULL);

				if (!projectobject.has("url"))
					projectobject.put("url", org.json.JSONObject.NULL);

				if (!projectobject.has("description"))
					projectobject.put("description", org.json.JSONObject.NULL);

				result.put(projectobject);
			}
		}

		// Achievement
		if (key.equals("achievement")) {
			for (int i = 0; i < json.length(); i++) {
				org.json.JSONObject Achievementobject = (org.json.JSONObject) json.get(i);

				if (!Achievementobject.has("title"))
					Achievementobject.put("title", org.json.JSONObject.NULL);

				if (!Achievementobject.has("roleAndResponsibility"))
					Achievementobject.put("roleAndResponsibility", org.json.JSONObject.NULL);

				if (!Achievementobject.has("description"))
					Achievementobject.put("description", org.json.JSONObject.NULL);

				if (!Achievementobject.has("achievementFile"))
					Achievementobject.put("achievementFile", org.json.JSONObject.NULL);

				result.put(Achievementobject);
			}
		}

		// Certificates
		if (key.equals("certificates")) {
			for (int i = 0; i < json.length(); i++) {
				org.json.JSONObject certificatesobject = (org.json.JSONObject) json.get(i);

				if (!certificatesobject.has("title"))
					certificatesobject.put("title", org.json.JSONObject.NULL);

				if (!certificatesobject.has("fromMonth"))
					certificatesobject.put("fromMonth", org.json.JSONObject.NULL);

				if (!certificatesobject.has("fromYear"))
					certificatesobject.put("fromYear", org.json.JSONObject.NULL);

				if (!certificatesobject.has("toMonth"))
					certificatesobject.put("toMonth", org.json.JSONObject.NULL);

				if (!certificatesobject.has("toYear"))
					certificatesobject.put("toYear", org.json.JSONObject.NULL);

				if (!certificatesobject.has("description"))
					certificatesobject.put("description", org.json.JSONObject.NULL);

				if (!certificatesobject.has("certificateFile"))
					certificatesobject.put("certificateFile", org.json.JSONObject.NULL);

				result.put(certificatesobject);
			}
		}

		return result;
	}

	/*
	 * 
	 * Attach Data
	 * 
	 */
	@RequestMapping(value = "/ElasticAPI/getattachdata", method = { RequestMethod.GET })
	public @ResponseBody String getAttachData(@RequestParam("searchparam") String searchparam,
			@RequestHeader HttpHeaders headers) throws JSONException {

//		if (!headers.containsKey("authorization")) {
//			System.out.println("No Authentication");
//			return "{\"error\":\"Please Provide The Authentication\"}";
//		}
//		String authString = headers.getFirst("authorization");
//		if (!restService.isUserAuthenticated(authString)) {
//			System.out.println("Wrong Authentication.....");
//			return "{\"error\":\"User not authenticated\"}";
//		}
		String authString = headers.getFirst("token");
		String validity = CognitoAuthentication.getValidAuthentication(authString);
		if(validity.equals("valid")){

		
		String urlAttach = "";

		System.out.println(searchparam);
		if (!searchparam.trim().equals("")) {
			searchparam = searchparam.replace(":", ":\"").replace(";", "\")AND(");
			searchparam = "q=(" + searchparam + "\")";
		}

		urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?"
				+ searchparam + "&sort=lastModified.keyword:desc";

		System.out.println("url :: " + urlAttach);
		ArrayList<AttachCount> list = new ArrayList<AttachCount>();

		list = getAttachList(urlAttach);

		org.json.JSONObject obj = new org.json.JSONObject();
		org.json.JSONObject obj1 = new org.json.JSONObject();

		obj.put("numFound", list.size());
		obj.put("attach", list);
		obj1.put("response", obj);

		return obj.toString();
		}
		else{
		return validity;
	}
}

}
