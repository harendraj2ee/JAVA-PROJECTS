package com.es.SpringBootApp;

import java.net.MalformedURLException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwt.interfaces.RSAKeyProvider;
import com.es.model.CollectionUrl;

//import com.es.restServiceImpl.RestServiceImpl;

//import com.elastic.model.ESPojo;
//import com.elastic.restServiceImpl.RestService;
@Controller
public class CognitorController {
	// @Autowired
	// private RestTemplate restTemplate;
	// @Autowired
	// private RestService restService;
	RestTemplate restTemplate = new RestTemplate();
	// RestServiceImpl restService = new RestServiceImpl();

	// @Autowired
	// private CollectionUrl collectionurl;

	@RequestMapping(value = "/ElasticAPI/candidatenameauth", method = { RequestMethod.GET })
	public @ResponseBody String candidateNamegetId(@RequestParam("name") String name,
			@RequestHeader HttpHeaders headers) throws MalformedURLException, JSONException {

		String authString = headers.getFirst("token");
	
		String validity = CognitoAuthentication.getValidAuthentication(authString);
		
		if(validity.equals("valid")){
			String urlAttach = "";

		
			if (name.contains("@")) {
				name = name.replace("@", "%40");
			}
			urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=email:"
					+ name + "";// ,resumeName,resume lastModified
			System.out.println("url :: " + urlAttach);

			String attachdata = restTemplate.getForObject(urlAttach, String.class);

			JSONObject mainjson = new JSONObject();

			JSONArray jsonArray = new JSONArray();

			JSONObject jsonAttach = new JSONObject(attachdata);
			JSONObject hits = jsonAttach.getJSONObject("hits");

			JSONArray hitsArr = hits.getJSONArray("hits");

			for (int i = 0; i < hitsArr.length(); i++) {

				JSONObject map = new JSONObject();

				JSONObject arrobj = (JSONObject) hitsArr.get(i);
				JSONObject arrobj1 = arrobj.getJSONObject("_source");

				if (arrobj1.has("id"))
					map.put("id", arrobj1.get("id"));
				else
					map.put("id", JSONObject.NULL);

				if (arrobj1.has("name"))
					map.put("name", arrobj1.get("name"));
				else
					map.put("name", JSONObject.NULL);

				if (arrobj1.has("email"))
					map.put("email", arrobj1.get("email"));
				else
					map.put("email", JSONObject.NULL);

				jsonArray.put(map);

			}

			mainjson.put("total", hits.get("total"));
			mainjson.put("response", jsonArray);

			return mainjson.toString();
		}else{
			return validity;
		}
	}

	@RequestMapping(value = "/ElasticAPI/getValidatedToken", method = { RequestMethod.GET })
	public @ResponseBody String getValidatedToken(@RequestHeader HttpHeaders headers) {

		String authString = headers.getFirst("authorization");

		if (!headers.containsKey("authorization")) {
			System.out.println("No Authentication");
			return "{\"error\":\"Please Provide valid Authentication\"}";
		}

		String token = "{\"token\":\""+CognitoAuthentication.userAuthentication(authString)+"\"}";

		return token;
	}

	
	@RequestMapping(value ="/ElasticAPI/jwtTest", method ={ RequestMethod.GET})
	public @ResponseBody String jwtTest(@RequestHeader HttpHeaders headers) throws JSONException{
		
		String aws_cognito_region = "ap-south-1"; 
		String aws_user_pools_id = "ap-south-1_n3qtyyPr7"; 
		
		RSAKeyProvider keyProvider = new AwsCognitoRSAKeyProvider(aws_cognito_region, aws_user_pools_id);
		Algorithm algorithm = Algorithm.RSA256(keyProvider);
		JWTVerifier jwtVerifier = JWT.require(algorithm)
		    //.withAudience("2qm9sgg2kh21masuas88vjc9se") // Validate your apps audience if needed
		    .build();

		String authString = headers.getFirst("token");
		//String token = CognitoAuthentication.validatedToken(authString);
		//String token = "eyJraWQiOiJjdE.eyJzdWIiOiI5NTMxN2E.VX819z1A1rJij2"; // Replace this with your JWT token
		
		try{
		jwtVerifier.verify(authString);
		}catch(TokenExpiredException e){
			return "{\"error\":\"Token Expired\"}";
		}catch(JWTDecodeException e){
			return "{\"error\":\"Not authenticated User\"}";
		}
		return "valid";
		
	}
	
	

		
		
}

		
