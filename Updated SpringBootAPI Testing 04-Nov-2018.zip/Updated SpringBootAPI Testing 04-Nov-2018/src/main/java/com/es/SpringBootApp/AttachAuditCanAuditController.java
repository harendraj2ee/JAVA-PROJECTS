package com.es.SpringBootApp;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.es.restServiceImpl.RestServiceImpl;

@Controller
public class AttachAuditCanAuditController {
       /*@Autowired
       static RestTemplate restTemplate = new RestTemplate();*/
	RestTemplate restTemplate=new RestTemplate();
	RestServiceImpl restService = new RestServiceImpl();

       @RequestMapping(value = "/ElasticAPI/attachaudit", method = { RequestMethod.GET })
       public @ResponseBody String attachAudit(@RequestParam("attachid") String attachID,
                     @RequestParam("perpage") Integer perpage, @RequestParam("next") Integer next,
                     @RequestParam("sort") String sort, @RequestHeader HttpHeaders headers) throws JSONException, URISyntaxException, MalformedURLException {

    		 if (!headers.containsKey("authorization")) {
 				System.out.println("No Authentication");
 				return "{\"error\":\"Please Provide The Authentication\"}";
 			}
 			String authString = headers.getFirst("authorization");
 			if (!restService.isUserAuthenticated(authString)) {
 				System.out.println("Wrong Authentication.....");
 				return "{\"error\":\"User not authenticated\"}";
 			}   
    	   
    	   String urlAttach = "";

              int start = perpage * (next - 1);

              urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attachaudit/_search?q=(attachID:\""
                           + attachID + "\")&size=" + perpage + "&from=" + start;

              if (!sort.equals("")) {
                     if (sort.equals("usernamea")) {
                           sort = "userName.keyword:" + "asc";
                     } else if (sort.equals("usernamed")) {
                           sort = "userName.keyword:" + "desc";
                     }
                     if (sort.equals("fielda")) {
                           sort = "field.keyword:" + "asc";
                     } else if (sort.equals("fieldd")) {
                           sort = "field.keyword:" + "desc";
                     }

                     if (sort.equals("oldvaluea")) {
                           sort = "oldValue.keyword:" + "asc";
                     } else if (sort.equals("oldvalued")) {
                           sort = "oldValue.keyword:" + "desc";
                     }

                     if (sort.equals("newvaluea")) {
                           sort = "newValue.keyword:" + "asc";
                     } else if (sort.equals("newvalued")) {
                           sort = "newValue.keyword:" + "desc";
                     }
                     if (sort.equals("lastupdateda")) {
                           sort = "lastUpdated.keyword:" + "asc";
                     } else if (sort.equals("lastupdatedd")) {
                           sort = "lastUpdated.keyword:" + "desc";
                     }
                     urlAttach = urlAttach + "&sort=" + sort;

              }

              String json = getAttachAudit(urlAttach);

              return json;
       }

     //AttachAudit Search
     
       @RequestMapping(value = "/ElasticAPI/attachauditsearch", method = { RequestMethod.POST })
       public @ResponseBody String externalAttachCandidateSearch(@RequestBody String field,
                     @RequestParam("attachid") String attachID, @RequestParam("perpage") Integer perpage,
                     @RequestParam("next") Integer next, @RequestParam("sort") String sort,
                     @RequestHeader HttpHeaders headers) throws MalformedURLException,
                     URISyntaxException, ParseException, JSONException, UnsupportedEncodingException {

              
    	   if (!headers.containsKey("authorization")) {
				System.out.println("No Authentication");
				return "{\"error\":\"Please Provide The Authentication\"}";
			}
			String authString = headers.getFirst("authorization");
			if (!restService.isUserAuthenticated(authString)) {
				System.out.println("Wrong Authentication.....");
				return "{\"error\":\"User not authenticated\"}";
			}   
    	   
    	   int start = perpage * (next - 1);
              String urlAttach = "";
              String search = "";

              urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attachaudit/_search?q=(attachID:\""
                           + attachID + "\")";

              /* search query */
              JSONParser parser = new JSONParser();

              org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) parser.parse(field);

              for (int i = 0; i < jsonArray.size(); i++) {

                     org.json.simple.JSONObject json = (org.json.simple.JSONObject) jsonArray.get(i);

                     String key = (String) json.get("key");
                     json.remove("key");

                     String jsonField = json.toString();

                     jsonField = jsonField.replace("{", "").replace("}", "");

                     if (key.equals("Begins With")) {

                           jsonField = jsonField.replace("\":\"", ":").replace("\",\"", "*)AND(");
                           if (jsonField.contains("AND"))
                                  jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";
                           else
                                  jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + "*)";

                     } else if (key.equals("Ends With")) {

                           jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", ")AND(");
                           if (jsonField.contains("AND"))
                                  jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "))";
                           else
                                  jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + ")";

                     } else if (key.equals("Contains")) {

                           jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");
                           if (jsonField.contains("AND"))
                                  jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";
                           else
                                  jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + "*)";

                     } else if (key.equals("Doesn't contain")) {

                           jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");

                           if (jsonField.contains("AND"))
                                  jsonField = "(NOT((" + jsonField.substring(1, jsonField.length() - 1) + "*)))";
                           else
                                  jsonField = "(NOT(" + jsonField.substring(1, jsonField.length() - 1) + "*))";

                     } else if (key.equals("Equal")) {

                           jsonField = jsonField.replace("\":\"", ":\"").replace("\",\"", "\")AND(");
                           if (jsonField.contains("AND"))
                                  jsonField = "((" + jsonField.substring(1, jsonField.length()) + "))";
                           else
                                  jsonField = "(" + jsonField.substring(1, jsonField.length()) + ")";
                     }

                     String check = jsonField.substring(0, jsonField.indexOf(":")).replace("(", "");

                     String attachFields = "id,attachID,userName,field,oldValue,newValue,lastUpdated";

                     if (attachFields.contains(check)) {
                           search = search + "OR" + jsonField;

                     }
              }

              search = search.replaceFirst("OR", "");

              if (search.length() > 0)
                     urlAttach = urlAttach + "AND(" + search + ")";

              urlAttach = urlAttach + "&size=" + perpage + "&from=" + start;

              if (!sort.equals("")) {
                     if (sort.equals("usernamea")) {
                           sort = "userName.keyword:" + "asc";
                     } else if (sort.equals("usernamed")) {
                           sort = "userName.keyword:" + "desc";
                     }
                     if (sort.equals("fielda")) {
                           sort = "field.keyword:" + "asc";
                     } else if (sort.equals("fieldd")) {
                           sort = "field.keyword:" + "desc";
                     }

                     if (sort.equals("oldvaluea")) {
                           sort = "oldValue.keyword:" + "asc";
                     } else if (sort.equals("oldvalued")) {
                           sort = "oldValue.keyword:" + "desc";
                     }

                     if (sort.equals("newvaluea")) {
                           sort = "newValue.keyword:" + "asc";
                     } else if (sort.equals("newvalued")) {
                           sort = "newValue.keyword:" + "desc";
                     }
                     if (sort.equals("lastupdateda")) {
                           sort = "lastUpdated.keyword:" + "asc";
                     } else if (sort.equals("lastupdatedd")) {
                           sort = "lastUpdated.keyword:" + "desc";
                     }
                     urlAttach = urlAttach + "&sort=" + sort;

              }

              
              String json = getAttachAudit(urlAttach);
              
              return json;
       }

       public String getAttachAudit(String query) throws JSONException, URISyntaxException, MalformedURLException {

              query = query + "&pretty=true&_source=id,attachID,userName,field,oldValue,newValue,lastUpdated";
              
              System.out.println("query..." + query);

              String jsonAttachData = restTemplate.getForObject(query, String.class);

              JSONObject mainjson = new JSONObject();

              JSONArray jsonArray = new JSONArray();

              JSONObject jsonAttach = new JSONObject(jsonAttachData);
              JSONObject jobhits = jsonAttach.getJSONObject("hits");

              JSONArray jobhitsArr = jobhits.getJSONArray("hits");

              for (int i = 0; i < jobhitsArr.length(); i++) {

                     JSONObject subJson = new JSONObject();

                     JSONObject arrobj = (JSONObject) jobhitsArr.get(i);
                     JSONObject arrobj1 = arrobj.getJSONObject("_source");

                     if (arrobj1.has("id"))
                           subJson.put("id", arrobj1.get("id"));
                     else
                           subJson.put("id", JSONObject.NULL);

                     if (arrobj1.has("attachID"))
                           subJson.put("attachID", arrobj1.get("attachID"));
                     else
                           subJson.put("attachID", JSONObject.NULL);

                     if (arrobj1.has("userName"))
                           subJson.put("userName", arrobj1.get("userName"));
                     else
                           subJson.put("userName", JSONObject.NULL);

                     if (arrobj1.has("field"))
                           subJson.put("field", arrobj1.get("field"));
                     else
                           subJson.put("field", JSONObject.NULL);

                     if (arrobj1.has("oldValue"))
                           subJson.put("oldValue", arrobj1.get("oldValue"));
                     else
                           subJson.put("oldValue", JSONObject.NULL);

                     if (arrobj1.has("newValue"))
                           subJson.put("newValue", arrobj1.get("newValue"));
                     else
                           subJson.put("newValue", JSONObject.NULL);

                     if (arrobj1.has("lastUpdated"))
                           subJson.put("lastUpdated", arrobj1.get("lastUpdated"));
                     else
                           subJson.put("lastUpdated", JSONObject.NULL);

                     jsonArray.put(subJson);

              }

              mainjson.put("total", jobhits.get("total"));
              mainjson.put("response", jsonArray);

              return mainjson.toString();
       }
       
      
       
       ///CandidateAudit List
       
       @RequestMapping(value = "/ElasticAPI/candidateaudit", method = { RequestMethod.GET })
       public @ResponseBody String candidateAudit(@RequestParam("objectid") String objectID,
                                       @RequestParam("perpage") Integer perpage, @RequestParam("next") Integer next,
                                       @RequestParam("sort") String sort,@RequestHeader HttpHeaders headers) throws JSONException, URISyntaxException, MalformedURLException {

    	   if (!headers.containsKey("authorization")) {
				System.out.println("No Authentication");
				return "{\"error\":\"Please Provide The Authentication\"}";
			}
			String authString = headers.getFirst("authorization");
			if (!restService.isUserAuthenticated(authString)) {
				System.out.println("Wrong Authentication.....");
				return "{\"error\":\"User not authenticated\"}";
			}   
    	   
                       String urlAttach = "";

                       int start = perpage * (next - 1);

                       urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidateaudit/_search?q=(objectID:\""
                                                       + objectID + "\")&size=" + perpage + "&from=" + start;

                       if (!sort.equals("")) {
                                       if (sort.equals("usernamea")) {
                                                       sort = "userName.keyword:" + "asc";
                                       } else if (sort.equals("usernamed")) {
                                                       sort = "userName.keyword:" + "desc";
                                       }
                                       if (sort.equals("fielda")) {
                                                       sort = "field.keyword:" + "asc";
                                       } else if (sort.equals("fieldd")) {
                                                       sort = "field.keyword:" + "desc";
                                       }

                                       if (sort.equals("oldvaluea")) {
                                                       sort = "oldValue.keyword:" + "asc";
                                       } else if (sort.equals("oldvalued")) {
                                                       sort = "oldValue.keyword:" + "desc";
                                       }

                                       if (sort.equals("newvaluea")) {
                                                       sort = "newValue.keyword:" + "asc";
                                       } else if (sort.equals("newvalued")) {
                                                       sort = "newValue.keyword:" + "desc";
                                       }
                                       if (sort.equals("lastupdateda")) {
                                                       sort = "lastUpdated.keyword:" + "asc";
                                       } else if (sort.equals("lastupdatedd")) {
                                                       sort = "lastUpdated.keyword:" + "desc";
                                       }
                                       urlAttach = urlAttach + "&sort=" + sort;

                       }

                       String json = getCandidateAudit(urlAttach);

                       return json;
       }

      //CandidateAudit Search
       @RequestMapping(value = "/ElasticAPI/candidateauditsearch", method = { RequestMethod.POST })
       public @ResponseBody String externalCandidateAuditSearch(@RequestBody String field,
                                       @RequestParam("objectid") String objectID, @RequestParam("perpage") Integer perpage,
                                       @RequestParam("next") Integer next, @RequestParam("sort") String sort,
                                       @RequestHeader HttpHeaders headers) throws MalformedURLException,
                                       URISyntaxException, ParseException, JSONException, UnsupportedEncodingException {

    	   if (!headers.containsKey("authorization")) {
				System.out.println("No Authentication");
				return "{\"error\":\"Please Provide The Authentication\"}";
			}
			String authString = headers.getFirst("authorization");
			if (!restService.isUserAuthenticated(authString)) {
				System.out.println("Wrong Authentication.....");
				return "{\"error\":\"User not authenticated\"}";
			}   
    	   
    	   
    	   				int start = perpage * (next - 1);
                       String urlAttach = "";
                       String search = "";

                       urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidateaudit/_search?q=(objectID:\""
                                                       + objectID + "\")";

                       /* search query */
                       JSONParser parser = new JSONParser();

                       org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) parser.parse(field);

                       for (int i = 0; i < jsonArray.size(); i++) {

                                       org.json.simple.JSONObject json = (org.json.simple.JSONObject) jsonArray.get(i);

                                       String key = (String) json.get("key");
                                       json.remove("key");

                                       String jsonField = json.toString();

                                       jsonField = jsonField.replace("{", "").replace("}", "");

                                       if (key.equals("Begins With")) {

                                                       jsonField = jsonField.replace("\":\"", ":").replace("\",\"", "*)AND(");
                                                       if (jsonField.contains("AND"))
                                                                       jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";
                                                       else
                                                                       jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + "*)";

                                       } else if (key.equals("Ends With")) {

                                                       jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", ")AND(");
                                                       if (jsonField.contains("AND"))
                                                                       jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "))";
                                                       else
                                                                       jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + ")";

                                       } else if (key.equals("Contains")) {

                                                       jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");
                                                       if (jsonField.contains("AND"))
                                                                       jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";
                                                       else
                                                                       jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + "*)";

                                       } else if (key.equals("Doesn't contain")) {

                                                       jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");

                                                       if (jsonField.contains("AND"))
                                                                       jsonField = "(NOT((" + jsonField.substring(1, jsonField.length() - 1) + "*)))";
                                                       else
                                                                       jsonField = "(NOT(" + jsonField.substring(1, jsonField.length() - 1) + "*))";

                                       } else if (key.equals("Equal")) {

                                                       jsonField = jsonField.replace("\":\"", ":\"").replace("\",\"", "\")AND(");
                                                       if (jsonField.contains("AND"))
                                                                       jsonField = "((" + jsonField.substring(1, jsonField.length()) + "))";
                                                       else
                                                                       jsonField = "(" + jsonField.substring(1, jsonField.length()) + ")";
                                       }

                                       String check = jsonField.substring(0, jsonField.indexOf(":")).replace("(", "");

                                       String attachFields = "id,objectID,userName,field,oldValue,newValue,lastUpdated";

                                       if (attachFields.contains(check)) {
                                                       search = search + "OR" + jsonField;

                                       }
                       }

                       search = search.replaceFirst("OR", "");

                       if (search.length() > 0)
                                       urlAttach = urlAttach + "AND(" + search + ")";

                       urlAttach = urlAttach + "&size=" + perpage + "&from=" + start;

                       if (!sort.equals("")) {
                                       if (sort.equals("usernamea")) {
                                                       sort = "userName.keyword:" + "asc";
                                       } else if (sort.equals("usernamed")) {
                                                       sort = "userName.keyword:" + "desc";
                                       }
                                       if (sort.equals("fielda")) {
                                                       sort = "field.keyword:" + "asc";
                                       } else if (sort.equals("fieldd")) {
                                                       sort = "field.keyword:" + "desc";
                                       }

                                       if (sort.equals("oldvaluea")) {
                                                       sort = "oldValue.keyword:" + "asc";
                                       } else if (sort.equals("oldvalued")) {
                                                       sort = "oldValue.keyword:" + "desc";
                                       }

                                       if (sort.equals("newvaluea")) {
                                                       sort = "newValue.keyword:" + "asc";
                                       } else if (sort.equals("newvalued")) {
                                                       sort = "newValue.keyword:" + "desc";
                                       }
                                       if (sort.equals("lastupdateda")) {
                                                       sort = "lastUpdated.keyword:" + "asc";
                                       } else if (sort.equals("lastupdatedd")) {
                                                       sort = "lastUpdated.keyword:" + "desc";
                                       }
                                       urlAttach = urlAttach + "&sort=" + sort;

                       }

                       String json = getCandidateAudit(urlAttach);

                       return json;
       }

       public String getCandidateAudit(String query) throws JSONException, URISyntaxException, MalformedURLException {

                       query = query + "&pretty=true&_source=id,objectID,userName,field,oldValue,newValue,lastUpdated";

                       System.out.println("query..." + query);

                       String jsonAttachData = restTemplate.getForObject(query, String.class);

                       JSONObject mainjson = new JSONObject();

                       JSONArray jsonArray = new JSONArray();

                       JSONObject jsonAttach = new JSONObject(jsonAttachData);
                       JSONObject jobhits = jsonAttach.getJSONObject("hits");

                       JSONArray jobhitsArr = jobhits.getJSONArray("hits");

                       for (int i = 0; i < jobhitsArr.length(); i++) {

                                       JSONObject subJson = new JSONObject();

                                       JSONObject arrobj = (JSONObject) jobhitsArr.get(i);
                                       JSONObject arrobj1 = arrobj.getJSONObject("_source");

                                       if (arrobj1.has("id"))
                                                       subJson.put("id", arrobj1.get("id"));
                                       else
                                                       subJson.put("id", JSONObject.NULL);

                                       if (arrobj1.has("objectID"))
                                                       subJson.put("objectID", arrobj1.get("objectID"));
                                       else
                                                       subJson.put("objectID", JSONObject.NULL);

                                       if (arrobj1.has("userName"))
                                                       subJson.put("userName", arrobj1.get("userName"));
                                       else
                                                       subJson.put("userName", JSONObject.NULL);

                                       if (arrobj1.has("field"))
                                                       subJson.put("field", arrobj1.get("field"));
                                       else
                                                       subJson.put("field", JSONObject.NULL);

                                       if (arrobj1.has("oldValue"))
                                                       subJson.put("oldValue", arrobj1.get("oldValue"));
                                       else
                                                       subJson.put("oldValue", JSONObject.NULL);

                                       if (arrobj1.has("newValue"))
                                                       subJson.put("newValue", arrobj1.get("newValue"));
                                       else
                                                       subJson.put("newValue", JSONObject.NULL);

                                       if (arrobj1.has("lastUpdated"))
                                                       subJson.put("lastUpdated", arrobj1.get("lastUpdated"));
                                       else
                                                       subJson.put("lastUpdated", JSONObject.NULL);

                                       jsonArray.put(subJson);

                       }

                       mainjson.put("total", jobhits.get("total"));
                       mainjson.put("response", jsonArray);

                       return mainjson.toString();
       }

}

       



