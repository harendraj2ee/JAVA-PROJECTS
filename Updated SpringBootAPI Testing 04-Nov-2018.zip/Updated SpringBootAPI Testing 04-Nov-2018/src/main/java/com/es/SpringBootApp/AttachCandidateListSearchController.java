package com.es.SpringBootApp;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.es.model.Attach;
import com.es.model.Candidate;
import com.es.restServiceImpl.RestServiceImpl;
@RestController
//http://localhost:8080/ElasticAPI/objiddd?_id=5b6ea254dc38aa1f40cf086b
public class AttachCandidateListSearchController {

	RestTemplate restTemaplate = new RestTemplate();
	RestServiceImpl restService = new RestServiceImpl();
	private Integer numFound = 0;
	static String Jsonkey = "";
	JSONObject json = new JSONObject();
	static String checkcontains = "none";
	// Attach return data candidate & attach

	/*@RequestMapping(value = "/ElasticAPI/attachlistsearch", method = { RequestMethod.POST })
	public @ResponseBody String esAttach(@RequestBody String field, @RequestParam("postedby")String postedby, @RequestParam("fromdate")String fromdate,
			@RequestParam("todate")String todate,@RequestParam(value = "perpage", required = false) Integer perpage,@RequestParam(value = "next", required = false)Integer next,
			@RequestParam(value = "sort", required = false)String sort, @RequestHeader HttpHeaders headers
			
			@RequestParam("jobid") String jobid,
			@RequestParam(value = "perpage", required = false) Integer perpage,
			@RequestParam(value = "next", required = false) Integer next) throws MalformedURLException,
			URISyntaxException, ParseException, JSONException, UnsupportedEncodingException {
		
		 if (!headers.containsKey("authorization")) {
				System.out.println("No Authentication");
				return "{\"error\":\"Please Provide The Authentication\"}";
			}
			String authString = headers.getFirst("authorization");
			if (!restService.isUserAuthenticated(authString)) {
				System.out.println("Wrong Authentication.....");
				return "{\"error\":\"User not authenticated\"}";
			}

		ArrayList<Attach> list = new ArrayList<Attach>();
		//list = attach(jobid, perpage, next, field);
		 list= attach(postedby,fromdate,todate,perpage,next,sort,field);
		org.json.JSONObject obj = new org.json.JSONObject();
		org.json.JSONObject obj1 = new org.json.JSONObject();

		obj.put("attach", list);
		obj.put("numFound", list.size());
		obj1.put("response", obj);

		return obj1.toString();

	}

	// Candidate
	public static ArrayList<Candidate> candidate(String objectId, Integer perpage, Integer next,String sort, String candidateQuery)
			throws ParseException, UnsupportedEncodingException, MalformedURLException, URISyntaxException {

		String name = "";
		String first_name = "";
		String last_name = "";
		String middle_name = "";
		String mobileNumber = "";
		String email = "";

		ArrayList<Candidate> list = new ArrayList<Candidate>();
		RestTemplate restTemplate = new RestTemplate();
		String urlCandidate = "";
		if (sort.equals("postedDatea")) {
			sort="createdDate:" + " asc";
		}else if(sort.equals("postedDated")) {
			sort="createdDate:" + " desc";
		}
		
		int start = perpage * (next - 1); 
		if(candidateQuery.length()>0)
//		urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""
//				+ objectId + "\")AND(" + candidateQuery + ")";
//			urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""+objectId+"\")AND(" + candidateQuery + ")&size="+perpage+"&from="+start+"&sort="+sort+"&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
//		else
//			urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""
//					+ objectId + "\")&size="+start+"&from="+perpage+"&sort="+sort+"&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume";	

			urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""+objectId+"\")AND(" + candidateQuery + ")&sort="+sort+"&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
		else
			urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""
					+ objectId + "\")&sort="+sort+"&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume";	

			
			System.out.println("urlCandidate >> " + urlCandidate);

		URL Candidateurl = new URL(urlCandidate);
		URI uriCandidate = new URI(Candidateurl.getProtocol(), Candidateurl.getUserInfo(), Candidateurl.getHost(),
				Candidateurl.getPort(), Candidateurl.getPath(), Candidateurl.getQuery(), urlCandidate);
		String candidate = restTemplate.getForObject(uriCandidate, String.class);

		JSONParser jsonParsercan = new JSONParser();

		JSONObject jsoncan = (JSONObject) ((JSONObject) jsonParsercan.parse(candidate)).get("hits");


		JSONArray arraycan = (JSONArray) jsoncan.get("hits");
		Iterator itratorcan = arraycan.iterator();

		while (itratorcan.hasNext()) {
			Candidate e = new Candidate();

			JSONObject jsonObjectcan = (JSONObject) itratorcan.next();
			// System.out.println("jsonObject::::"+jsonObject);
			jsonObjectcan = (JSONObject) jsonObjectcan.get("_source");

			name = (String) jsonObjectcan.get("name");
			first_name = (String) jsonObjectcan.get("first_name");
			last_name = (String) jsonObjectcan.get("last_name");
			middle_name = (String) jsonObjectcan.get("middle_name");
			mobileNumber = (String) jsonObjectcan.get("mobileNumber");
			email = (String) jsonObjectcan.get("email");
			e.setName(name);
			e.setFirst_name(first_name);
			e.setLast_name(last_name);
			e.setMiddle_name(middle_name);
			e.setEmail(email);
			e.setMobileNumber(mobileNumber);

			list.add(e);

		}
		return list;
	}

	// Attach
	public ArrayList<Attach> attach(String postedby, String fromdate, String todate, Integer perpage, Integer next, String sort, String field)
			throws ParseException, UnsupportedEncodingException, MalformedURLException, URISyntaxException {

		String id = "";
		String objectId = "";
		String jobIdd = "";
		String drop = "";
		String dropComment = "";
		String lastModifiedBy = "";
		String createdDate = "";
		String anchor = "";
		String anchorId = "";
		String status = "";
		String jobName = "";
		String clientId = "";
		String clientName = "";
		String contactId = "";
		String contactName = "";
		String attachedBy = "";
		String lastModified = "";
		String cvSentDate = "";
		String statusChangeDate = "";
		String statusOutcome = "";
		String changeReason = "";
		String clientPortalStatus = "";
		String clientSheetStatus = "";
		String paTestScore = "";
		String testScore = "";
		String avgScore = "";
		Long pageUpId;
		String ghStage = "";
		String ghStatus = "";
		Long ghStageId;
		Long ghStatusId;
		Long stageId;
		Long statusId;
		String stage = "";
		String comment = "";
		Long withOutId;
		String resumeName = "";
		String attachQuery = "";
		String urlAttach = "";
		String candidateQuery = "";
		
		if (sort.equals("postedDatea")) {
			sort="createdDate:" + " asc";
		}else if(sort.equals("postedDated")) {
			sort="createdDate:" + " desc";
		}
	 
		//int start = perpage*(next);
		int start = perpage * (next - 1); 
		
		ArrayList<Attach> list = new ArrayList<Attach>();

		JSONParser parser = new JSONParser();

		JSONArray jsonArray = (JSONArray) parser.parse(field);

		for (int i = 0; i < jsonArray.size(); i++) {

			json = (JSONObject) jsonArray.get(i);

			String key = (String) json.get("key");
			json.remove("key");

			String jsonField = json.toString();

			jsonField = jsonField.replace("{", "").replace("}", "");

			if (key.equals("Begins With")) {

				jsonField = jsonField.replace("\":\"", ":").replace("\",\"", "*)AND(");
				jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";

			} else if (key.equals("Ends With")) {

				jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", ")AND(");
				jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "))";

			} else if (key.equals("Contains")) {

				jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");
				jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";

			} else if (key.equals("Doesn't contain")) {

				jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");
				jsonField = "(NOT((" + jsonField.substring(1, jsonField.length() - 1) + "*)))";

			} else if (key.equals("Equal")) {

				jsonField = jsonField.replace("\":\"", ":\"").replace("\",\"", "\")AND(");
				jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "\"))";

			}

			String check = jsonField.substring(0, jsonField.indexOf(":")).replace("(", "");

			
			String attachFields = "objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,"
                    + "anchor,cvSentDate,statusChangeDate,statusOutcome,changeReason,federated,clientPortalStatus,clientSheetStatus,paTestScore"
                    + "testScore,avgScore,pageUpId,isClientSheet,ghStatus,ghStatusId,statusId,status,dropComment,comment,withOutId,resumeName,resume";


			String candidateFields = "name,email,mobileNumber";

			if (attachFields.contains(check)) {
				attachQuery = attachQuery + "OR" + jsonField;

			} else if (candidateFields.contains(check)) {
				candidateQuery = candidateQuery + "OR" + jsonField;

			}

		}

		attachQuery = attachQuery.replaceFirst("OR", "");
		candidateQuery = candidateQuery.replaceFirst("OR", "");

		
		System.out.println("attachQuery.." + attachQuery);
		System.out.println("candidateQuery.." + candidateQuery);

		RestTemplate restTemplate = new RestTemplate();

		if (attachQuery.length() > 0)
//			urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""
//					+ jobId + "\")AND(" + attachQuery + ")";
			
			urlAttach  = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(attachedBy:\""+postedby+"\")AND(createdDate:[\""+fromdate+"\" TO \""+todate+"\"])AND(" + attachQuery + ")&size="+perpage+"&from="+start+"&sort="+sort+"&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,lastModifiedBy,lastModified,createdDate,anchor,anchorId,cvSentDate,statusChangeDate,statusOutcome,changeReason,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId,resumeName";//resume
		else
			urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(attachedBy:\""+postedby+"\")AND(createdDate:[\""+fromdate+"\" TO \""+todate+"\"])&size="+perpage+"&from="+start+"&sort="+sort+"&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,lastModifiedBy,lastModified,createdDate,anchor,anchorId,cvSentDate,statusChangeDate,statusOutcome,changeReason,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId,resumeName";//resume";

		System.out.println("urlAttach >> " + urlAttach);

		URL Attachurl = new URL(urlAttach);
		URI uriAttach = new URI(Attachurl.getProtocol(), Attachurl.getUserInfo(), Attachurl.getHost(),
				Attachurl.getPort(), Attachurl.getPath(), Attachurl.getQuery(), urlAttach);

		String attach = restTemplate.getForObject(uriAttach, String.class);

		JSONParser jsonParsercan = new JSONParser();

		JSONObject jsoncan = (JSONObject) ((JSONObject) jsonParsercan.parse(attach)).get("hits");


		JSONArray arraycan = (JSONArray) jsoncan.get("hits");

		Iterator itratorcan = arraycan.iterator();

		while (itratorcan.hasNext()) {
			Attach e = new Attach();

			JSONObject jsonObjectcan = (JSONObject) itratorcan.next();

			jsonObjectcan = (JSONObject) jsonObjectcan.get("_source");

			id = (String) jsonObjectcan.get("id");
			e.setId(id);
			objectId = (String) jsonObjectcan.get("objectId");
			ArrayList<Candidate> canlist = candidate(objectId, perpage, next, sort, candidateQuery);

			e.setCandidate(canlist);

			e.setObjectId(objectId);

			jobIdd = (String) jsonObjectcan.get("jobId");
			e.setJobIdd(jobIdd);

			drop = (String) jsonObjectcan.get("drop");
			e.setDrop(drop);

			dropComment = (String) jsonObjectcan.get("dropComment");
			e.setDropComment(dropComment);

			lastModifiedBy = (String) jsonObjectcan.get("lastModifiedBy");
			e.setLastModifiedBy(lastModifiedBy);

			createdDate = (String) jsonObjectcan.get("createdDate");
			e.setCreatedDate(createdDate);

			anchor = (String) jsonObjectcan.get("anchor");
			e.setAnchor(anchor);

			anchorId = (String) jsonObjectcan.get("anchorId");
			e.setAnchorId(anchorId);

			status = (String) jsonObjectcan.get("status");
			e.setStatus(status);

			jobName = (String) jsonObjectcan.get("jobName");
			e.setJobName(jobName);

			clientId = (String) jsonObjectcan.get("clientId");
			e.setClientId(clientId);

			clientName = (String) jsonObjectcan.get("clientName");
			e.setClientName(clientName);

			contactId = (String) jsonObjectcan.get("contactId");
			e.setContactId(contactId);

			contactName = (String) jsonObjectcan.get("contactName");
			e.setContactName(contactName);

			attachedBy = (String) jsonObjectcan.get("attachedBy");
			e.setAttachedBy(attachedBy);

			lastModified = (String) jsonObjectcan.get("lastModified");
			e.setLastModified(lastModified);

			cvSentDate = (String) jsonObjectcan.get("cvSentDate");
			e.setCvSentDate(cvSentDate);

			statusChangeDate = (String) jsonObjectcan.get("statusChangeDate");
			e.setStatusChangeDate(statusChangeDate);

			statusOutcome = (String) jsonObjectcan.get("statusOutcome");
			e.setStatusOutcome(statusOutcome);

			changeReason = (String) jsonObjectcan.get("changeReason");
			e.setChangeReason(changeReason);

			clientPortalStatus = (String) jsonObjectcan.get("clientPortalStatus");
			e.setClientPortalStatus(clientPortalStatus);

			clientSheetStatus = (String) jsonObjectcan.get("clientSheetStatus");
			e.setClientSheetStatus(clientSheetStatus);

			paTestScore = (String) jsonObjectcan.get("paTestScore");
			e.setPaTestScore(paTestScore);

			testScore = (String) jsonObjectcan.get("testScore");
			e.setTestScore(testScore);

			avgScore = (String) jsonObjectcan.get("avgScore");
			e.setAvgScore(avgScore);

			pageUpId = (Long) jsonObjectcan.get("pageUpId");

			stage = (String) jsonObjectcan.get("stage");
			e.setStage(stage);

			comment = (String) jsonObjectcan.get("comment");
			e.setComment(comment);

			resumeName = (String) jsonObjectcan.get("resumeName");
			e.setResumeName(resumeName);
			
			ghStatus =  (String) jsonObjectcan.get("ghStatus");
			e.setGhStatus(ghStatus);

			if (!canlist.isEmpty()) {
				numFound = numFound + 1;
				this.setNumFound(numFound);
				list.add(e);
			}
		}

		return list;

	}*/

	public Integer getNumFound() {
		return numFound;
	}

	public void setNumFound(Integer numFound2) {
		this.numFound = numFound2;
	}






}
