package com.es.SpringBootApp;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.es.model.AttachCount;
import com.es.model.CandidateCount;
import com.es.restServiceImpl.RestServiceImpl;
@Controller
public class HitechCRMController {
	/*@Autowired
	private RestTemplate restTemplate;*/
	RestTemplate restTemplate = new RestTemplate();
	RestServiceImpl restService = new RestServiceImpl();
	
	private Long numFound;
	
	@RequestMapping(value = "/ElasticAPI/jobcount", method = RequestMethod.GET)
	public @ResponseBody String esJobCount(@RequestParam("postedby")String postedby, @RequestParam("fromdate")String fromdate,
			@RequestParam("todate")String todate, @RequestHeader HttpHeaders headers) throws JSONException, ParseException {
		
		 if (!headers.containsKey("authorization")) {
				System.out.println("No Authentication");
				return "{\"error\":\"Please Provide The Authentication\"}";
			}
			String authString = headers.getFirst("authorization");
			if (!restService.isUserAuthenticated(authString)) {
				System.out.println("Wrong Authentication.....");
				return "{\"error\":\"User not authenticated\"}";
			}
		//job1=id,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted,clientId,contactId,jobId
		String joburl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(postedBy:\""+postedby+"\")AND(postedDate:[\""+fromdate+"\" TO \""+todate+"\"])&size=10&from=0&pretty=true&_source=id,modifiedDate,postedBy,postedDate";//id,
		System.out.println("ESURL job1    >> " + joburl);
		String jsonjobUrl = restTemplate.getForObject(joburl, String.class);
		// System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
		JSONObject jsonMain=new JSONObject();
		JSONObject jsonObjDocs = new JSONObject();
		JSONObject jsonObjResponse = new JSONObject();
		JSONArray array = new JSONArray();
		JSONArray array1 = new JSONArray();
				
		JSONObject jsonObject1=(JSONObject) new JSONObject(jsonjobUrl).get("_shards");
		System.out.println("jsonObject1 >> "+jsonObject1);
		JSONObject jsonObject2= (JSONObject) new JSONObject(jsonjobUrl).get("hits");
		
		
		
		Integer count=(Integer) jsonObject2.get("total");
		System.out.println("count total >> "+count);
		array.put(count);
		jsonMain.accumulate("job", count);
		System.out.println("jsonMain >> "+jsonMain);
		array1.put(jsonMain);
		jsonObjDocs.put("docs", array1);
		jsonObjResponse.put("response", jsonObjDocs);
		System.out.println("jsonObjResponse >> " + jsonObjResponse);
		
		
		return jsonObjResponse.toString();
	}
	
	//joblist
	
		@RequestMapping(value = "/ElasticAPI/joblist", method = { RequestMethod.GET })
	    public @ResponseBody String esJobList(@RequestParam("postedby") String postedby,
	                  @RequestParam("fromdate") String fromdate, @RequestParam("todate") String todate,
	                  @RequestParam("sort") String sort, @RequestParam("next") Integer next,
	                  @RequestParam("perpage") Integer perpage, @RequestHeader HttpHeaders headers) throws URISyntaxException, MalformedURLException, JSONException {
	           
			 if (!headers.containsKey("authorization")) {
					System.out.println("No Authentication");
					return "{\"error\":\"Please Provide The Authentication\"}";
				}
				String authString = headers.getFirst("authorization");
				if (!restService.isUserAuthenticated(authString)) {
					System.out.println("Wrong Authentication.....");
					return "{\"error\":\"User not authenticated\"}";
				}
			
			   String joburl = "";
	           String jsonEsJobUrl = "";


	           // String urljob =
	           // "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q="+dquery+"&size=10&from=0&pretty=true&sort="
	           // + sort +
	           // "&_source=name,skills,role,ctc,experience,location,postedby,id,description,industry,@timestamp,industrytype,education,funtionalarea,posteddate,noofopenings,expireddate,modifieddate,modifiedby";
	           
	           if (sort.equals("postedDatea")) {
	                  sort = "postedDate:" + " asc";
	           } else if (sort.equals("postedDated")) {
	                  sort = "postedDate:" + " desc";
	           }
	           
	           int start = perpage * (next -1);
				  //String urlAttach  = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(attachedBy:\""+postedby+"\")AND(createdDate:[\""+fromdate+"\" TO \""+todate+"\"])&size="+perpage+"&from="+start+"&sort="+sort+"&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,lastModifiedBy,lastModified,createdDate,anchor,anchorId,cvSentDate,statusChangeDate,statusOutcome,changeReason,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId,resumeName";//resume

	           joburl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(postedBy:\""
	                        + postedby + "\")AND(postedDate:[\"" + fromdate + "\" TO \"" + todate + "\"])&size=" + perpage
	                        + "&from=" + start
	                        + "&pretty=true&_source=id,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted,clientId,contactId,jobId&sort="
	                        + sort + "";// id,
	           System.out.println("ESAPI job  :>> " + joburl);
	           URL urlCandidatedata = new URL(joburl);
	           String nullFragment = null;
	           URI uriCandidatedata = new URI(urlCandidatedata.getProtocol(), urlCandidatedata.getUserInfo(),
	                        urlCandidatedata.getHost(), urlCandidatedata.getPort(), urlCandidatedata.getPath(),
	                        urlCandidatedata.getQuery(), nullFragment);

	           jsonEsJobUrl = restTemplate.getForObject(uriCandidatedata, String.class);

	           JSONObject mainjson = new JSONObject();

	           JSONArray jsonArray = new JSONArray();

	           JSONObject jsonAttach = new JSONObject(jsonEsJobUrl);
	           JSONObject jobhits = jsonAttach.getJSONObject("hits");

	           JSONArray jobhitsArr = jobhits.getJSONArray("hits");

	           for (int i = 0; i < jobhitsArr.length(); i++) {

	                  JSONObject subJson = new JSONObject();

	                  JSONObject arrobj = (JSONObject) jobhitsArr.get(i);
	                  JSONObject arrobj1 = arrobj.getJSONObject("_source");

	                  if (arrobj1.has("id"))
	                        subJson.put("id", arrobj1.get("id"));
	                  else
	                        subJson.put("id", JSONObject.NULL);

	                  if (arrobj1.has("clientId"))
	                        subJson.put("clientId", arrobj1.get("clientId"));
	                  else
	                        subJson.put("clientId", JSONObject.NULL);

	                  if (arrobj1.has("contactId"))
	                        subJson.put("contactId", arrobj1.get("contactId"));
	                  else
	                        subJson.put("contactId", JSONObject.NULL);

	                  if (arrobj1.has("name"))
	                        subJson.put("name", arrobj1.get("name"));
	                  else
	                        subJson.put("name", JSONObject.NULL);

	                  if (arrobj1.has("jobCode"))
	                        subJson.put("jobCode", arrobj1.get("jobCode"));
	                  else
	                        subJson.put("jobCode", JSONObject.NULL);

	                  if (arrobj1.has("noOfOpenings"))
	                        subJson.put("noOfOpenings", arrobj1.get("noOfOpenings"));
	                  else
	                        subJson.put("noOfOpenings", JSONObject.NULL);

	                  if (arrobj1.has("experience"))
	                        subJson.put("experience", arrobj1.get("experience"));
	                  else
	                        subJson.put("experience", JSONObject.NULL);

	                  if (arrobj1.has("ctc"))
	                        subJson.put("ctc", arrobj1.get("ctc"));
	                  else
	                        subJson.put("ctc", JSONObject.NULL);

	                  if (arrobj1.has("location"))
	                        subJson.put("location", arrobj1.get("location"));
	                  else
	                        subJson.put("location", JSONObject.NULL);

	                  if (arrobj1.has("industryType"))
	                        subJson.put("industryType", arrobj1.get("industryType"));
	                  else
	                        subJson.put("industryType", JSONObject.NULL);

	                  if (arrobj1.has("jobType"))
	                        subJson.put("jobType", arrobj1.get("jobType"));
	                  else
	                        subJson.put("jobType", JSONObject.NULL);

	                  if (arrobj1.has("industry"))
	                        subJson.put("industry", arrobj1.get("industry"));
	                  else
	                        subJson.put("industry", JSONObject.NULL);

	                  if (arrobj1.has("funtionalArea"))
	                        subJson.put("funtionalArea", arrobj1.get("funtionalArea"));
	                  else
	                        subJson.put("funtionalArea", JSONObject.NULL);

	                  if (arrobj1.has("role"))
	                        subJson.put("role", arrobj1.get("role"));
	                  else
	                        subJson.put("role", JSONObject.NULL);

	                  if (arrobj1.has("skills"))
	                        subJson.put("skills", arrobj1.get("skills"));
	                  else
	                        subJson.put("skills", JSONObject.NULL);

	                  if (arrobj1.has("education"))
	                        subJson.put("education", arrobj1.get("education"));
	                  else
	                        subJson.put("education", JSONObject.NULL);

	                  if (arrobj1.has("description"))
	                        subJson.put("description", arrobj1.get("description"));
	                  else
	                        subJson.put("description", JSONObject.NULL);

	                  if (arrobj1.has("postedDate"))
	                        subJson.put("postedDate", arrobj1.get("postedDate"));
	                  else
	                        subJson.put("postedDate", JSONObject.NULL);

	                  if (arrobj1.has("modifiedDate"))
	                        subJson.put("modifiedDate", arrobj1.get("modifiedDate"));
	                  else
	                        subJson.put("modifiedDate", JSONObject.NULL);

	                  if (arrobj1.has("postedBy"))
	                        subJson.put("postedBy", arrobj1.get("postedBy"));
	                  else
	                        subJson.put("postedBy", JSONObject.NULL);

	                  if (arrobj1.has("modifiedBy"))
	                        subJson.put("modifiedBy", arrobj1.get("modifiedBy"));
	                  else
	                        subJson.put("modifiedBy", JSONObject.NULL);

	                  if (arrobj1.has("deleted"))
	                        subJson.put("deleted", arrobj1.get("deleted"));
	                  else
	                        subJson.put("deleted", JSONObject.NULL);

	                  if (arrobj1.has("expiredDate"))
	                        subJson.put("expiredDate", arrobj1.get("expiredDate"));
	                  else
	                        subJson.put("expiredDate", JSONObject.NULL);

	                  if (arrobj1.has("status"))
	                        subJson.put("status", arrobj1.get("status"));
	                  else
	                        subJson.put("status", JSONObject.NULL);

	                  jsonArray.put(subJson);

	           }

	           mainjson.put("total", jobhits.get("total"));
	           mainjson.put("response", jsonArray);

	           return mainjson.toString();
	    }

		
	
	//JobList Search.. HitechCRM
		@RequestMapping(value = "/ElasticAPI/joblistSearch", method = { RequestMethod.POST })
		public @ResponseBody String esJobListSearch(@RequestBody String searchJson,
				@RequestParam("postedby") String postedby, @RequestParam("fromdate") String fromdate,
				@RequestParam("todate") String todate, @RequestParam("sort") String sort,
				@RequestParam("next") Integer next, @RequestParam("perpage") Integer perpage, @RequestHeader HttpHeaders headers)
				throws URISyntaxException, MalformedURLException, JSONException, ParseException {
			 if (!headers.containsKey("authorization")) {
					System.out.println("No Authentication");
					return "{\"error\":\"Please Provide The Authentication\"}";
				}
				String authString = headers.getFirst("authorization");
				if (!restService.isUserAuthenticated(authString)) {
					System.out.println("Wrong Authentication.....");
					return "{\"error\":\"User not authenticated\"}";
				}
			
			String joburl = "";
			String jsonEsJobUrl = "";
			String search = "";
			
			if (sort.equals("postedDatea")) {
				sort = "postedDate:" + " asc";
			} else if (sort.equals("postedDated")) {
				sort = "postedDate:" + " desc";
			}

			search = jobListSearchQuery(searchJson);

			
			joburl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=((postedBy:\""
					+ postedby + "\")AND(postedDate:[\"" + fromdate + "\" TO \"" + todate + "\"]))AND("+ search +")&size=" + perpage
					+ "&from=" + next
					+ "&pretty=true&_source=id,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted,clientId,contactId,jobId&sort="
					+ sort + "";

			System.out.println("ESAPI job  :>> " + joburl);
			URL urlCandidatedata = new URL(joburl);
			String nullFragment = null;
			URI uriCandidatedata = new URI(urlCandidatedata.getProtocol(), urlCandidatedata.getUserInfo(),
					urlCandidatedata.getHost(), urlCandidatedata.getPort(), urlCandidatedata.getPath(),
					urlCandidatedata.getQuery(), nullFragment);

			jsonEsJobUrl = restTemplate.getForObject(uriCandidatedata, String.class);

			JSONObject mainjson = new JSONObject();

			JSONArray jsonArray = new JSONArray();

			JSONObject jsonAttach = new JSONObject(jsonEsJobUrl);
			JSONObject jobhits = jsonAttach.getJSONObject("hits");

			JSONArray jobhitsArr = jobhits.getJSONArray("hits");

			for (int i = 0; i < jobhitsArr.length(); i++) {

				JSONObject subJson = new JSONObject();

				JSONObject arrobj = (JSONObject) jobhitsArr.get(i);
				JSONObject arrobj1 = arrobj.getJSONObject("_source");

				if (arrobj1.has("id"))
					subJson.put("id", arrobj1.get("id"));
				else
					subJson.put("id", JSONObject.NULL);

				if (arrobj1.has("clientId"))
					subJson.put("clientId", arrobj1.get("clientId"));
				else
					subJson.put("clientId", JSONObject.NULL);

				if (arrobj1.has("contactId"))
					subJson.put("contactId", arrobj1.get("contactId"));
				else
					subJson.put("contactId", JSONObject.NULL);

				if (arrobj1.has("name"))
					subJson.put("name", arrobj1.get("name"));
				else
					subJson.put("name", JSONObject.NULL);

				if (arrobj1.has("jobCode"))
					subJson.put("jobCode", arrobj1.get("jobCode"));
				else
					subJson.put("jobCode", JSONObject.NULL);

				if (arrobj1.has("noOfOpenings"))
					subJson.put("noOfOpenings", arrobj1.get("noOfOpenings"));
				else
					subJson.put("noOfOpenings", JSONObject.NULL);

				if (arrobj1.has("experience"))
					subJson.put("experience", arrobj1.get("experience"));
				else
					subJson.put("experience", JSONObject.NULL);

				if (arrobj1.has("ctc"))
					subJson.put("ctc", arrobj1.get("ctc"));
				else
					subJson.put("ctc", JSONObject.NULL);

				if (arrobj1.has("location"))
					subJson.put("location", arrobj1.get("location"));
				else
					subJson.put("location", JSONObject.NULL);

				if (arrobj1.has("industryType"))
					subJson.put("industryType", arrobj1.get("industryType"));
				else
					subJson.put("industryType", JSONObject.NULL);

				if (arrobj1.has("jobType"))
					subJson.put("jobType", arrobj1.get("jobType"));
				else
					subJson.put("jobType", JSONObject.NULL);

				if (arrobj1.has("industry"))
					subJson.put("industry", arrobj1.get("industry"));
				else
					subJson.put("industry", JSONObject.NULL);

				if (arrobj1.has("funtionalArea"))
					subJson.put("funtionalArea", arrobj1.get("funtionalArea"));
				else
					subJson.put("funtionalArea", JSONObject.NULL);

				if (arrobj1.has("role"))
					subJson.put("role", arrobj1.get("role"));
				else
					subJson.put("role", JSONObject.NULL);

				if (arrobj1.has("skills"))
					subJson.put("skills", arrobj1.get("skills"));
				else
					subJson.put("skills", JSONObject.NULL);

				if (arrobj1.has("education"))
					subJson.put("education", arrobj1.get("education"));
				else
					subJson.put("education", JSONObject.NULL);

				if (arrobj1.has("description"))
					subJson.put("description", arrobj1.get("description"));
				else
					subJson.put("description", JSONObject.NULL);

				if (arrobj1.has("postedDate"))
					subJson.put("postedDate", arrobj1.get("postedDate"));
				else
					subJson.put("postedDate", JSONObject.NULL);

				if (arrobj1.has("modifiedDate"))
					subJson.put("modifiedDate", arrobj1.get("modifiedDate"));
				else
					subJson.put("modifiedDate", JSONObject.NULL);

				if (arrobj1.has("postedBy"))
					subJson.put("postedBy", arrobj1.get("postedBy"));
				else
					subJson.put("postedBy", JSONObject.NULL);

				if (arrobj1.has("modifiedBy"))
					subJson.put("modifiedBy", arrobj1.get("modifiedBy"));
				else
					subJson.put("modifiedBy", JSONObject.NULL);

				if (arrobj1.has("deleted"))
					subJson.put("deleted", arrobj1.get("deleted"));
				else
					subJson.put("deleted", JSONObject.NULL);

				if (arrobj1.has("expiredDate"))
					subJson.put("expiredDate", arrobj1.get("expiredDate"));
				else
					subJson.put("expiredDate", JSONObject.NULL);

				if (arrobj1.has("status"))
					subJson.put("status", arrobj1.get("status"));
				else
					subJson.put("status", JSONObject.NULL);

				jsonArray.put(subJson);

			}

			mainjson.put("total", jobhits.get("total"));
			mainjson.put("response", jsonArray);

			return mainjson.toString();
		}

		public String jobListSearchQuery(String field) throws JSONException, ParseException {

			String jobListQuery = "";

			JSONParser parser = new JSONParser();

			org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) parser.parse(field);

			for (int i = 0; i < jsonArray.size(); i++) {

				org.json.simple.JSONObject json = (org.json.simple.JSONObject) jsonArray.get(i);

//				System.out.println("JsonArray........." + json);

				String key = (String) json.get("key");
				json.remove("key");

				String jsonField = json.toString();

				jsonField = jsonField.replace("{", "").replace("}", "");

			if (key.equals("Begins With")) {

				jsonField = jsonField.replace("\":\"", ":").replace("\",\"", "*)AND(");
				jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";

			} else if (key.equals("Ends With")) {

				jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", ")AND(");
				jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "))";

			} else if (key.equals("Contains")) {

				jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");
				jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";

			} else if (key.equals("Doesn't contain")) {

				jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");
				jsonField = "(NOT((" + jsonField.substring(1, jsonField.length() - 1) + "*)))";

			} else if (key.equals("Equal")) {

				jsonField = jsonField.replace("\":\"", ":\"").replace("\",\"", "\")AND(");
				jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "\"))";

			}

			jobListQuery = jobListQuery + "OR" + jsonField;
		}

		jobListQuery = jobListQuery.replaceFirst("OR", "");

		// System.out.println("Query.." + jobListQuery);

		return jobListQuery;

		}
		
		
	
	//AttachCandidate for dashboard.
	
	@RequestMapping(value = "/ElasticAPI/attachcount", method = RequestMethod.GET)
	public @ResponseBody String esAttachJobCount(@RequestParam("postedby")String postedby, @RequestParam("fromdate")String fromdate,
			@RequestParam("todate")String todate, @RequestHeader HttpHeaders headers) throws JSONException, ParseException {
		
		 if (!headers.containsKey("authorization")) {
				System.out.println("No Authentication");
				return "{\"error\":\"Please Provide The Authentication\"}";
			}
			String authString = headers.getFirst("authorization");
			if (!restService.isUserAuthenticated(authString)) {
				System.out.println("Wrong Authentication.....");
				return "{\"error\":\"User not authenticated\"}";
			}
		//job1=id,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted,clientId,contactId,jobId,
		String attachurl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(attachedBy:\""+postedby+"\")AND(createdDate:[\""+fromdate+"\" TO \""+todate+"\"])&size=10&from=0&pretty=true&_source=id,jobId,objectId,attachedBy,createdDate";//id,
		System.out.println("ESURL job1    >> " + attachurl);
		String jsonAttachUrl = restTemplate.getForObject(attachurl, String.class);
		// System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
		JSONObject jsonMain=new JSONObject();
		JSONObject jsonObjDocs = new JSONObject();
		JSONObject jsonObjResponse = new JSONObject();
		JSONArray array = new JSONArray();
		JSONArray array1 = new JSONArray();
				
		JSONObject jsonObject1=(JSONObject) new JSONObject(jsonAttachUrl).get("_shards");
		System.out.println("jsonObject1 >> "+jsonObject1);
		JSONObject jsonObject2= (JSONObject) new JSONObject(jsonAttachUrl).get("hits");
		

		/*JSONObject jsonObject2=new JSONObject(jsonIndustryUrl);
		jsonObject2=(JSONObject) jsonObject2.get("hits");
		System.out.println("jsonObject2 >> "+jsonObject2);*/
		
		/*JSONArray array2 = (JSONArray) jsonObject2.get("hits");
		JSONObject jsonObject3 = (JSONObject) array2.get(0);
		System.out.println("json value::::"+jsonObject3);
		JSONObject jsonObject4=(JSONObject) jsonObject3.get("_source");
		System.out.println("jsonObject4 >>> "+jsonObject4);*/
		
	
		Integer count=(Integer) jsonObject2.get("total");
		System.out.println("count total >> "+count);
		array.put(count);
		jsonMain.accumulate("attach", count);
		System.out.println("jsonMain >> "+jsonMain);
		array1.put(jsonMain);
		jsonObjDocs.put("docs", array1);
		jsonObjResponse.put("response", jsonObjDocs);
		System.out.println("jsonObjResponse >> " + jsonObjResponse);
		
		return jsonObjResponse.toString();
	}
	


	//atachlist
		@RequestMapping(value = "/ElasticAPI/attachlist2", method = { RequestMethod.GET })
		public @ResponseBody String esAttachList(@RequestParam("postedby")String postedby, @RequestParam("fromdate")String fromdate,
				@RequestParam("todate")String todate)throws URISyntaxException, MalformedURLException, JSONException {
			
			String attahurl="";
			String jsonEsAttachUrl ="";
			//id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,lastModifiedBy,lastModified,createdDate,anchor,anchorId,cvSentDate,statusChangeDate,statusOutcome,changeReason,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId,resumeName
			attahurl  = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(attachedBy:\""+postedby+"\")AND(createdDate:[\""+fromdate+"\" TO \""+todate+"\"])&size=10&from=0&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,lastModifiedBy,lastModified,createdDate,anchor,anchorId,cvSentDate,statusChangeDate,statusOutcome,changeReason,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId,resumeName";//resume
			System.out.println("ESAPI Attach :>> "+attahurl);
			jsonEsAttachUrl = restTemplate.getForObject(attahurl, String.class);
			
			JSONObject jsonObject1=(JSONObject) new JSONObject(jsonEsAttachUrl).get("_shards");
			System.out.println("jsonObject1 >> "+jsonObject1);
			JSONObject jsonObject2= (JSONObject) new JSONObject(jsonEsAttachUrl).get("hits");

			return jsonEsAttachUrl;
		}
		
		
		
		//AttachList for dashb
		/*@RequestMapping(value = "/ElasticAPI/attachlist", method = { RequestMethod.GET })
		public @ResponseBody String esAttachCRM(@RequestParam("postedby")String postedby, @RequestParam("fromdate")String fromdate,
				@RequestParam("todate")String todate,@RequestParam("perpage") Integer perpage,@RequestParam("next")Integer next,
				@RequestParam("sort")String sort,@RequestHeader HttpHeaders headers)throws URISyntaxException, MalformedURLException, JSONException, ParseException {
			
			 if (!headers.containsKey("authorization")) {
					System.out.println("No Authentication");
					return "{\"error\":\"Please Provide The Authentication\"}";
				}
				String authString = headers.getFirst("authorization");
				if (!restService.isUserAuthenticated(authString)) {
					System.out.println("Wrong Authentication.....");
					return "{\"error\":\"User not authenticated\"}";
				}
			
			 ArrayList<AttachCount> list = new ArrayList<AttachCount>();
			 list= attach(postedby,fromdate,todate,perpage,next,sort);
			 org.json.JSONObject obj = new org.json.JSONObject();
			 org.json.JSONObject obj1 = new org.json.JSONObject();
			 
			 
			 org.json.JSONArray array = new org.json.JSONArray();
			 array.put(list);
			 obj.put("attach", list);
			 obj.put("numFound", this.getNumFound());

			 obj1.put("response", obj);
			 //System.out.println("obj1 >> "+obj1);
			 return obj1.toString();
			  
		}
		
		//////////////////////
		
		//Candidate       
		  public static  ArrayList<CandidateCount> candidate(String objectId,Integer perpage,Integer next,String sort) throws ParseException, JSONException{
			  String urlCandidate = "";
				int start = perpage * (next - 1); 
				ArrayList<CandidateCount> list =  new ArrayList<CandidateCount>();
				RestTemplate restTemplate=new RestTemplate();
				  
				if (sort.equals("namea") || sort.equals("named") || sort.equals("fnamea") || sort.equals("fnamed") || 
						sort.equals("mnamea") || sort.equals("mnamed") || sort.equals("lnamea") || sort.equals("lnamed") || 
						sort.equals("emaila") || sort.equals("emaild") || sort.equals("mobilea") || sort.equals("mobiled")) {
					
				
			  if (sort.equals("namea")) {
					sort="name.keyword:" + "asc";
				}else if (sort.equals("named")) {
					sort="name.keyword:" + "desc";
				}
//			  if (sort.equals("enterdatea")) {
//					sort="createdDate.keyword:" + "asc";
//				}else if(sort.equals("enterdated")) {
//					sort="createdDate.keyword:" + "desc";
//				}
				 
				if (sort.equals("fnamea")) {
					sort =  "first_name.keyword:" + "asc";
				}else if (sort.equals("fnamed")) {
					sort = "first_name.keyword:" + "desc";
				}
				
				if (sort.equals("mnamea")) {
					sort = "middle_name.keyword:" + "asc";
				}else if (sort.equals("mnamed")) {
					sort = "middle_name.keyword:" + "desc";
				}
				
				if (sort.equals("lnamea")) {
					sort =  "last_name.keyword:" + "asc";
				}else if (sort.equals("lnamed")) {
					sort =  "last_name.keyword:" + "desc";
				}
				
				if (sort.equals("emaila")) {
					sort =  "email.keyword:" + "asc";
				}else if (sort.equals("emaild")) {
					sort =  "email.keyword:" + "desc";
				}
				
				if (sort.equals("mobilea")) {
					sort = "mobileNumber.keyword:" + "asc";
				}else if (sort.equals("mobiled")) {
					sort = "mobileNumber.keyword:" + "desc";
				}
			  
				   urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""+objectId+"\")&sort="+sort+"&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
				   System.out.println("urlcandidate if >> "+urlCandidate);
			}
			else{
			 
			   urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""+objectId+"\")&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
			   System.out.println("urlCandidate else>> " + urlCandidate);
				
			}
			
			  JSONParser jsonParsercan  = new JSONParser();
			  
			
			  
			  String candidate = restTemplate.getForObject(urlCandidate, String.class);
			  org.json.simple.JSONObject jsoncan= (org.json.simple.JSONObject) ((org.json.simple.JSONObject) jsonParsercan.parse(candidate)).get("hits");
					
			      //System.out.println("jsoncan::::"+jsoncan);
			        
			        org.json.simple.JSONArray arraycan = ( org.json.simple.JSONArray) jsoncan.get("hits");
			        //System.out.println("jsoncanlength::::"+arraycan.size());
			        Iterator itratorcan = arraycan.iterator();
			        
			        while(itratorcan.hasNext()){
			        	CandidateCount e = new  CandidateCount();
			     	
			        	org.json.simple.JSONObject jsonObjectcan=(org.json.simple.JSONObject) itratorcan.next();
			        //System.out.println("jsonObject::::"+jsonObject);
			        jsonObjectcan=  (org.json.simple.JSONObject) jsonObjectcan.get("_source");
			        //System.out.println("jsonObjectcan:::"+jsonObjectcan);
			        
			        if (jsonObjectcan.get("name")!=null ) {
			        	String name=(String) jsonObjectcan.get("name");
			 	        e.setName(name);
					}else {
			        	String name=(String) jsonObjectcan.get("name");
					}
				   if (jsonObjectcan.get("first_name")!=null) {
					   String first_name=(String) jsonObjectcan.get("first_name");
				        e.setFirst_name(first_name);
				}else {
					   String first_name=(String) jsonObjectcan.get("first_name");
				}
				   if (jsonObjectcan.get("middle_name")!=null) {
					   String  middle_name=(String) jsonObjectcan.get("middle_name");
				       e.setMiddle_name(middle_name);
				}else {
					   String  middle_name=(String) jsonObjectcan.get("middle_name");
				}
				   if (jsonObjectcan.get("last_name")!=null) {
					   String last_name=(String) jsonObjectcan.get("last_name");
				       e.setLast_name(last_name);
				}else {
					   String last_name=(String) jsonObjectcan.get("last_name");
				}
			      if (jsonObjectcan.get("email")!=null) {
			    	  String  email=(String) jsonObjectcan.get("email");
				       e.setEmail(email);
				}else {
		    	  	String  email=(String) jsonObjectcan.get("email");
				}  
			     if (jsonObjectcan.get("mobileNumber")!=null) {
			    	 String   mobileNumber=(String) jsonObjectcan.get("mobileNumber");
				     e.setMobileNumber(mobileNumber);
				}else {
			    	 String   mobileNumber=(String) jsonObjectcan.get("mobileNumber");
				}
			      
			        list.add(e);
				
			}  
			        return list;
		  }     
		        
		 //Attach
		 public    ArrayList<AttachCount> attach(String postedby,String fromdate,String todate,Integer perpage,Integer next,String sort) throws ParseException, JSONException{
			  System.out.println("hello!!!");
			  String urlAttach  = "";
				//int start = perpage * (next);
				//int start = 10 * (next - 1);
				int start = perpage * (next - 1); 
				
			  ArrayList<AttachCount> list =  new ArrayList<AttachCount>();
			  ArrayList<CandidateCount> canlist =  new ArrayList<CandidateCount>();
			  RestTemplate restTemplate=new RestTemplate();
				 Integer numFound=null;
				 String id="";
				 String objectId="";
				 String jobIdd="";
				 String drop="";
				 String dropComment="";
				 String lastModifiedBy="";
				 String createdDate="";
				 String anchor="";
				 String anchorId="";
				 String status="";
						
				 String jobName = "";
				 String clientId = "";
				 String clientName = "";
				 String contactId = "";
				 String contactName ="";
				 String attachedBy = "";
				 String lastModified = "";
				 String cvSentDate = "";
				 String statusChangeDate = "";
				 String statusOutcome = "";
				 String changeReason = "";
				 String clientPortalStatus = "";
				 String clientSheetStatus = "";
				 String paTestScore = "";
				 String testScore = "";
				 String avgScore = "";
				 Long pageUpId;
				 String ghStage = "";
				 String ghStatus = "";
				 Long ghStageId;
				 Long ghStatusId ;
				 Long stageId ;
				 Long statusId;
				 String stage ="";
				 String comment = "";
				 Long withOutId;
				 String resumeName= "";
				
				 Long isClientSheet;
				
					if (!sort.equals("namea") && !sort.equals("named") && !sort.equals("fnamea") && !sort.equals("fnamed") && 
							!sort.equals("mnamea") && !sort.equals("mnamed") && !sort.equals("lnamea") && !sort.equals("lnamed") && 
							!sort.equals("emaila") && !sort.equals("emaild") && !sort.equals("mobilea") && !sort.equals("mobiled")) { 
			
						 if (sort.equals("createddatea")) {
								sort = "createdDate.keyword:" + "asc";
						 }
						  else if(sort.equals("createddated")) {
								sort = "createdDate.keyword:" + "desc";
							}
						  if (sort.equals("clientnamea")) {
							sort = "clientName.keyword:" + "asc";
						  }
						  else if (sort.equals("clientnamed")) {
							  sort = "clientName.keyword:" + "desc";
						  }
						 
						  if (sort.equals("dropa")) {
							sort =  "drop.keyword:"+ "asc";
						  }else if (sort.equals("dropd")) {
							sort = "drop.keyword:" + "desc";
						}
						 
						  if (sort.equals("dropcommenta")) {
							sort =  "dropComment.keyword:"+ "asc";
						  }else if (sort.equals("dropcommentd")) {
							sort = "dropComment.keyword:" + "desc";
						}
						  if (sort.equals("lastmodifiedbya")) {
							sort =  "lastModifiedBy.keyword:"+ "asc";
						  }else if (sort.equals("lastmodifiedbyd")) {
							sort = "lastModifiedBy.keyword:" + "desc";
						}
						  if (sort.equals("anchora")) {
							sort =  "anchor.keyword:"+ "asc";
						  }else if (sort.equals("anchord")) {
							sort = "anchor.keyword:" + "desc";
						}
						  if (sort.equals("anchorida")) {
							sort =  "anchorId.keyword:"+ "asc";
						  }else if (sort.equals("anchoridd")) {
							sort = "anchorId.keyword:" + "desc";
						} 
						  if (sort.equals("statusa")) {
							sort =  "status.keyword:"+ "asc";
						  }else if (sort.equals("statusd")) {
							sort = "status.keyword:" + "desc";
						}
						  if (sort.equals("jobnamea")) {
							sort =  "jobName.keyword:"+ "asc";
						  }else if (sort.equals("jobnamed")) {
							sort = "jobName.keyword:" + "desc";
						}
						  if (sort.equals("clientida")) {
							sort =  "clientId.keyword:"+ "asc";
						  }else if (sort.equals("clientidd")) {
							sort = "clientId.keyword:" + "desc";
						}
						  if (sort.equals("contactida")) {
							sort =  "contactId.keyword:"+ "asc";
						  }else if (sort.equals("contactidd")) {
							sort = "contactId.keyword:" + "desc";
						}
						  if (sort.equals("contactnamea")) {
							sort =  "contactName.keyword:"+ "asc";
						  }else if (sort.equals("contactnamed")) {
							sort = "contactName.keyword:" + "desc";
						}
						  if (sort.equals("attachedbya")) {
							sort =  "attachedBy.keyword:"+ "asc";
						  }else if (sort.equals("attachedbyd")) {
							sort = "attachedBy.keyword:" + "desc";
						}
						  if (sort.equals("lastmodifieda")) {
							sort =  "lastModified.keyword:"+ "asc";
						  }else if (sort.equals("lastmodifiedd")) {
							sort = "lastModified.keyword:" + "desc";
						}
						  if (sort.equals("cvsentdatea")) {
							sort =  "cvSentDate.keyword:"+ "asc";
						  }else if (sort.equals("cvsentdated")) {
							sort = "cvSentDate.keyword:" + "desc";
						}
						  if (sort.equals("statuschangedatea")) {
							sort =  "statusChangeDate.keyword:"+ "asc";
						  }else if (sort.equals("statuschangedated")) {
							sort = "statusChangeDate.keyword:" + "desc";
						}
						  if (sort.equals("statusoutcomea")) {
							sort =  "statusOutcome.keyword:"+ "asc";
						  }else if (sort.equals("statusoutcomed")) {
							sort = "statusOutcome.keyword:" + "desc";
						}
						  if (sort.equals("changereasona")) {
							sort =  "changeReason.keyword:"+ "asc";
						  }else if (sort.equals("changereasond")) {
							sort = "changeReason.keyword:" + "desc";
						}
						  if (sort.equals("clientportalstatusa")) {
							sort =  "clientPortalStatus.keyword:"+ "asc";
						  }else if (sort.equals("clientportalstatusd")) {
							sort = "clientPortalStatus.keyword:" + "desc";
						}
						  if (sort.equals("patestscorea")) {
							sort =  "paTestScore.keyword:"+ "asc";
						  }else if (sort.equals("patestscored")) {
							sort = "paTestScore.keyword:" + "desc";
						}
						  if (sort.equals("testscorea")) {
							sort =  "testScore.keyword:"+ "asc";
						  }else if (sort.equals("testscored")) {
							sort = "testScore.keyword:" + "desc";
						}
						  if (sort.equals("avgscorea")) {
							sort =  "avgScore.keyword:"+ "asc";
						  }else if (sort.equals("avgscored")) {
							sort = "avgScore.keyword:" + "desc";
						}
						  if (sort.equals("pageupid")) {
							sort =  "pageUpId.keyword:"+ "asc";
						  }else if (sort.equals("pageupid")) {
							sort = "pageUpId.keyword:" + "desc";
						}
						  if (sort.equals("ghstagea")) {
							sort =  "ghStage.keyword:"+ "asc";
						  }else if (sort.equals("ghstaged")) {
							sort = "ghStage.keyword:" + "desc";
						}
						  if (sort.equals("ghstatusa")) {
							sort =  "ghStatus.keyword:"+ "asc";
						  }else if (sort.equals("ghstatusd")) {
							sort = "ghStatus.keyword:" + "desc";
						}
						  if (sort.equals("ghstageida")) {
							sort =  "ghStageId.keyword:"+ "asc";
						  }else if (sort.equals("ghstageidd")) {
							sort = "ghStageId.keyword:" + "desc";
						}
						  if (sort.equals("ghstatusida")) {
							sort =  "ghStatusId.keyword:"+ "asc";
						  }else if (sort.equals("ghstatusidd")) {
							sort = "ghStatusId.keyword:" + "desc";
						}
						  if (sort.equals("stageida")) {
							sort =  "stageId.keyword:"+ "asc";
						  }else if (sort.equals("stageidd")) {
							sort = "stageId.keyword:" + "desc";
						}      
						  if (sort.equals("statusida")) {
							sort =  "statusId.keyword:"+ "asc";
						  }else if (sort.equals("statusidd")) {
							sort = "statusId.keyword:" + "desc";
						}
						  if (sort.equals("stagea")) {
							sort =  "stage.keyword:"+ "asc";
						  }else if (sort.equals("staged")) {
							sort = "stage.keyword:" + "desc";
						}
						  if (sort.equals("commenta")) {
							sort =  "comment.keyword:"+ "asc";
						  }else if (sort.equals("commentd")) {
							sort = "comment.keyword:" + "desc";
						}
						  if (sort.equals("withoutida")) {
							sort =  "withOutId.keyword:"+ "asc";
						  }else if (sort.equals("withoutidd")) {
							sort = "withOutId.keyword:" + "desc";
						}
						  if (sort.equals("resumenamea")) {
							sort =  "resumeName.keyword:"+ "asc";
						  }else if (sort.equals("resumenamed")) {
							sort = "resumeName.keyword:" + "desc";
						}
						  						  
						 urlAttach  = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(attachedBy:\""+postedby+"\")AND(createdDate:[\""+fromdate+"\" TO \""+todate+"\"])&size="+perpage+"&from="+start+"&sort="+sort+"&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,lastModifiedBy,lastModified,createdDate,anchor,anchorId,cvSentDate,statusChangeDate,statusOutcome,changeReason,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId,resumeName";//resume
						 System.out.println("urlAttach if >> "+urlAttach);
						 
					}else {
						 urlAttach  = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(attachedBy:\""+postedby+"\")AND(createdDate:[\""+fromdate+"\" TO \""+todate+"\"])&size="+perpage+"&from="+start+"&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,lastModifiedBy,lastModified,createdDate,anchor,anchorId,cvSentDate,statusChangeDate,statusOutcome,changeReason,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId,resumeName";//resume
						 System.out.println("urlAttach else  >> " + urlAttach);
					}

			  
			  JSONParser jsonParserAttach  = new JSONParser();
			  String attach = restTemplate.getForObject(urlAttach, String.class);
			  org.json.simple.JSONObject jsonAttach= ( org.json.simple.JSONObject) (( org.json.simple.JSONObject) jsonParserAttach.parse(attach)).get("hits");
					
			        System.out.println("total:::::::"+jsonAttach.get("total"));
			        Long total=  (Long) jsonAttach.get("total");
			        this.setNumFound(total);
			        
			        //JSONObject total = new JSONObject();
			        //total.put("", jsoncan.get("total"));
			        org.json.simple.JSONArray arrayAtach = (org.json.simple.JSONArray) jsonAttach.get("hits");
			       // System.out.println("arrayAtach::::"+arrayAtach.size());
			        Iterator itratorcan = arrayAtach.iterator();
			       
			        while(itratorcan.hasNext()){
			        	AttachCount e = new  AttachCount();
			    
			        org.json.simple.JSONObject jsonObjectAttach=( org.json.simple.JSONObject) itratorcan.next();
			        //System.out.println("jsonObject::::"+jsonObject);
			        jsonObjectAttach=  ( org.json.simple.JSONObject) jsonObjectAttach.get("_source");
			       // System.out.println("jsonObjectAttach:::"+jsonObjectAttach);
				   
			        id= (String) jsonObjectAttach.get("id");
			        e.setId(id);
					
			        objectId=(String) jsonObjectAttach.get("objectId");
					e.setObjectId(objectId);
					
					jobIdd=(String) jsonObjectAttach.get("jobId");
					e.setJobIdd(jobIdd);
				
					canlist=candidate(objectId,perpage,next,sort);
					e.setCandidate(canlist);
					
					if (jsonObjectAttach.get("drop")!=null) {
						drop=(String) jsonObjectAttach.get("drop");
						e.setDrop(drop);
					}else {
						drop=(String) jsonObjectAttach.get("drop");
					}
					if (jsonObjectAttach.get("dropComment")!=null) {
						dropComment=(String) jsonObjectAttach.get("dropComment");
						e.setDropComment(dropComment);
					}else {
						dropComment=(String) jsonObjectAttach.get("dropComment");
					}
					if (jsonObjectAttach.get("lastModifiedBy")!=null) {
						lastModifiedBy=(String) jsonObjectAttach.get("lastModifiedBy");
						e.setLastModifiedBy(lastModifiedBy);
					}else {
						lastModifiedBy=(String) jsonObjectAttach.get("lastModifiedBy");
					}
					if (jsonObjectAttach.get("createdDate")!=null) {
						createdDate=(String) jsonObjectAttach.get("createdDate");
						e.setCreatedDate(createdDate);
					}else {
						createdDate=(String) jsonObjectAttach.get("createdDate");
					}
					if (jsonObjectAttach.get("anchor")!=null) {
						anchor=(String) jsonObjectAttach.get("anchor");
						e.setAnchor(anchor);
					}else {
						anchor=(String) jsonObjectAttach.get("anchor");
					}
					if (jsonObjectAttach.get("anchorId")!=null) {
						anchorId=(String) jsonObjectAttach.get("anchorId");
						e.setAnchorId(anchorId);
					}else {
						anchorId=(String) jsonObjectAttach.get("anchorId");
					}
					if (jsonObjectAttach.get("status")!=null) {
						status=(String) jsonObjectAttach.get("status");
						e.setStatus(status);
					}else {
						status=(String) jsonObjectAttach.get("status");
					}
					if (jsonObjectAttach.get("jobName")!=null) {
						jobName=(String) jsonObjectAttach.get("jobName");
						e.setJobName(jobName);
					}else {
						jobName=(String) jsonObjectAttach.get("jobName");
					}
					if (jsonObjectAttach.get("clientId")!=null) {
						clientId=(String) jsonObjectAttach.get("clientId");
						e.setClientId(clientId);
					}else {
						clientId=(String) jsonObjectAttach.get("clientId");
					}
					if (jsonObjectAttach.get("clientName")!=null) {
						clientName=(String) jsonObjectAttach.get("clientName");
						e.setClientName(clientName);
					}else {
						clientName=(String) jsonObjectAttach.get("clientName");
					}
					if (jsonObjectAttach.get("contactId")!=null) {
						contactId=(String) jsonObjectAttach.get("contactId");
						e.setContactId(contactId);
					}else {
						contactId=(String) jsonObjectAttach.get("contactId");
					}
			       if (jsonObjectAttach.get("contactName")!=null) {
			   		   contactName=(String) jsonObjectAttach.get("contactName");
					   e.setContactName(contactName);
			       }else {
			    	   contactName=(String) jsonObjectAttach.get("contactName");
			       }
					if (jsonObjectAttach.get("attachedBy")!=null) {
						attachedBy=(String) jsonObjectAttach.get("attachedBy");
						e.setAttachedBy(attachedBy);
					}else {
						attachedBy=(String) jsonObjectAttach.get("attachedBy");
					}
					if (jsonObjectAttach.get("lastModified")!=null) {
						lastModified=(String) jsonObjectAttach.get("lastModified");
						e.setLastModified(lastModified);
					}else {
						lastModified=(String) jsonObjectAttach.get("lastModified");
					}
					if (jsonObjectAttach.get("cvSentDate")!=null) {
						cvSentDate=(String) jsonObjectAttach.get("cvSentDate");
						e.setCvSentDate(cvSentDate);
					}else {
						cvSentDate=(String) jsonObjectAttach.get("cvSentDate");
					}
					if (jsonObjectAttach.get("statusChangeDate")!=null) {
						statusChangeDate=(String) jsonObjectAttach.get("statusChangeDate");
						e.setStatusChangeDate(statusChangeDate);
					}else {
						statusChangeDate=(String) jsonObjectAttach.get("statusChangeDate");
					}
					if (jsonObjectAttach.get("statusOutcome")!=null) {
						statusOutcome=(String) jsonObjectAttach.get("statusOutcome");
						e.setStatusOutcome(statusOutcome);
					}else {
						statusOutcome=(String) jsonObjectAttach.get("statusOutcome");
					}
					if (jsonObjectAttach.get("changeReason")!=null) {
						changeReason=(String) jsonObjectAttach.get("changeReason");
						e.setChangeReason(changeReason);
					}else {
						changeReason=(String) jsonObjectAttach.get("changeReason");
					}
					if (jsonObjectAttach.get("clientPortalStatus")!=null) {
						clientPortalStatus=(String) jsonObjectAttach.get("clientPortalStatus");
						e.setClientPortalStatus(clientPortalStatus);
					}else {
						clientPortalStatus=(String) jsonObjectAttach.get("clientPortalStatus");
					}
					if (jsonObjectAttach.get("paTestScore")!=null) {
						paTestScore=(String) jsonObjectAttach.get("paTestScore");
						e.setPaTestScore(paTestScore);
					}else {
						paTestScore=(String) jsonObjectAttach.get("paTestScore");
					}
					if (jsonObjectAttach.get("testScore")!=null) {
						testScore=(String) jsonObjectAttach.get("testScore");
						e.setTestScore(testScore);
					}else {
						testScore=(String) jsonObjectAttach.get("testScore");
					}
					if (jsonObjectAttach.get("avgScore")!=null) {
						avgScore=(String) jsonObjectAttach.get("avgScore");
						e.setAvgScore(avgScore);
					}else {
						avgScore=(String) jsonObjectAttach.get("avgScore");
					}
					if (jsonObjectAttach.get("pageUpId")!=null) {
						//System.out.println("pageUpId IF");
						pageUpId=(Long) jsonObjectAttach.get("pageUpId");
						e.setPageUpId(pageUpId);
					}else {
						//pageUpId=(Long) jsonObjectAttach.get("pageUpId");
						jsonObjectAttach.get("pageUpId");
						
						//System.out.println("pageUpId after else >>> "+jsonObjectAttach.get("pageUpId"));
					}
					if (jsonObjectAttach.get("ghStage")!=null) {
						ghStage=(String) jsonObjectAttach.get("ghStage");
						e.setGhStatus(ghStage);
					}else {
						ghStage=(String) jsonObjectAttach.get("ghStage");
					}
					if (jsonObjectAttach.get("ghStatus")!=null) {
						ghStatus=(String) jsonObjectAttach.get("ghStatus");
						e.setGhStatus(ghStatus);
					}else {
						ghStatus=(String) jsonObjectAttach.get("ghStatus");
					}
					if (jsonObjectAttach.get("ghStageId")!=null) {
						ghStageId=(Long) jsonObjectAttach.get("ghStageId");
						e.setGhStageId(ghStageId);
					}else {
						ghStageId=(Long) jsonObjectAttach.get("ghStageId");
					}
					if (jsonObjectAttach.get("ghStatusId")!=null) {
						ghStatusId=(Long) jsonObjectAttach.get("ghStatusId");
						e.setGhStatusId(ghStatusId);
					}else {
						ghStatusId=(Long) jsonObjectAttach.get("ghStatusId");
					}
					if (jsonObjectAttach.get("stageId")!=null) {
						stageId=(Long) jsonObjectAttach.get("stageId");
						e.setStageId(stageId);
					}else {
						stageId=(Long) jsonObjectAttach.get("stageId");
					}
					if (jsonObjectAttach.get("statusId")!=null) {
						statusId=(Long) jsonObjectAttach.get("statusId");
						e.setStatusId(statusId);
					}else {
						statusId=(Long) jsonObjectAttach.get("statusId");
					}
					if (jsonObjectAttach.get("stage")!=null) {
						stage=(String) jsonObjectAttach.get("stage");
						e.setStage(stage);
					}else {
						stage=(String) jsonObjectAttach.get("stage");
					}
					if (jsonObjectAttach.get("comment")!=null) {
						comment=(String) jsonObjectAttach.get("comment");
						e.setComment(comment);
					}else {
						jsonObjectAttach.get("comment");
					}
					if (jsonObjectAttach.get("withOutId")!=null) {
						withOutId=(Long) jsonObjectAttach.get("withOutId");
						e.setWithOutId(withOutId);
					}else {
						withOutId=(Long) jsonObjectAttach.get("withOutId");
						//jsonObjectAttach.put("withOutId", jsonAttach.get(null));
						//System.out.println(" else withOutId >> "+withOutId);
					}
					if (jsonObjectAttach.get("resumeName")!=null) {
						resumeName=(String) jsonObjectAttach.get("resumeName");
						e.setResumeName(resumeName);
					}else {
						resumeName=(String) jsonObjectAttach.get("resumeName");
					}

					
				
                    list.add(e);
				
			}  
			        return list;
		  }*/

	
		 
		 
		public Long getNumFound() {
			return numFound;
		}

		public void setNumFound(Long numFound) {
			this.numFound = numFound;
		} 
		
		
		
		// ExternalInternal Controller
		
		@RequestMapping(value = "/ElasticAPI/externalCandidates", method = { RequestMethod.GET })
		public @ResponseBody String externalCandidates(@RequestParam("jobId") String jobId)
				throws JSONException, URISyntaxException, MalformedURLException {

			String urlAttach = "";
			String jsonAttachData = "";
			

			urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:"
					+ jobId + ")AND(federated:\"ExternalPortal\")";

			System.out.println("job query..." + urlAttach);

			URL urljob = new URL(urlAttach);

			URI urijob = new URI(urljob.getProtocol(), urljob.getUserInfo(), urljob.getHost(), urljob.getPort(),
					urljob.getPath(), urljob.getQuery(), urlAttach);

			// System.out.println(urijob);

			jsonAttachData = restTemplate.getForObject(urijob, String.class);

			JSONObject mainjson = new JSONObject();

			JSONArray jsonArray = new JSONArray();

			JSONObject jsonAttach = new JSONObject(jsonAttachData);
			JSONObject jobhits = jsonAttach.getJSONObject("hits");

			JSONArray jobhitsArr = jobhits.getJSONArray("hits");

			for (int i = 0; i < jobhitsArr.length(); i++) {

				JSONObject subJson = new JSONObject();

				JSONObject arrobj = (JSONObject) jobhitsArr.get(i);
				JSONObject arrobj1 = arrobj.getJSONObject("_source");

				if (arrobj1.has("id"))
					subJson.put("id", arrobj1.get("id"));
				else
					subJson.put("id", JSONObject.NULL);

				if (arrobj1.has("objectId"))
					subJson.put("objectId", arrobj1.get("objectId"));
				else
					subJson.put("objectId", JSONObject.NULL);

				if (arrobj1.has("jobId"))
					subJson.put("jobId", arrobj1.get("jobId"));
				else
					subJson.put("jobId", JSONObject.NULL);

				if (arrobj1.has("jobName"))
					subJson.put("jobName", arrobj1.get("jobName"));
				else
					subJson.put("jobName", JSONObject.NULL);

				if (arrobj1.has("clientId"))
					subJson.put("clientId", arrobj1.get("clientId"));
				else
					subJson.put("clientId", JSONObject.NULL);

				if (arrobj1.has("clientName"))
					subJson.put("clientName", arrobj1.get("clientName"));
				else
					subJson.put("clientName", JSONObject.NULL);

				if (arrobj1.has("contactId"))
					subJson.put("contactId", arrobj1.get("contactId"));
				else
					subJson.put("contactId", JSONObject.NULL);

				if (arrobj1.has("contactName"))
					subJson.put("contactName", arrobj1.get("contactName"));
				else
					subJson.put("contactName", JSONObject.NULL);

				if (arrobj1.has("attachedBy"))
					subJson.put("attachedBy", arrobj1.get("attachedBy"));
				else
					subJson.put("attachedBy", JSONObject.NULL);

				if (arrobj1.has("lastModifiedBy"))
					subJson.put("lastModifiedBy", arrobj1.get("lastModifiedBy"));
				else
					subJson.put("lastModifiedBy", JSONObject.NULL);

				if (arrobj1.has("lastModified"))
					subJson.put("lastModified", arrobj1.get("lastModified"));
				else
					subJson.put("lastModified", JSONObject.NULL);

				if (arrobj1.has("createdDate"))
					subJson.put("createdDate", arrobj1.get("createdDate"));
				else
					subJson.put("createdDate", JSONObject.NULL);

				if (arrobj1.has("anchor"))
					subJson.put("anchor", arrobj1.get("anchor"));
				else
					subJson.put("anchor", JSONObject.NULL);

				if (arrobj1.has("cvSentDate"))
					subJson.put("cvSentDate", arrobj1.get("cvSentDate"));
				else
					subJson.put("cvSentDate", JSONObject.NULL);

				if (arrobj1.has("statusChangeDate"))
					subJson.put("statusChangeDate", arrobj1.get("statusChangeDate"));
				else
					subJson.put("statusChangeDate", JSONObject.NULL);

				if (arrobj1.has("statusOutcome"))
					subJson.put("statusOutcome", arrobj1.get("statusOutcome"));
				else
					subJson.put("statusOutcome", JSONObject.NULL);

				if (arrobj1.has("changeReason"))
					subJson.put("changeReason", arrobj1.get("changeReason"));
				else
					subJson.put("changeReason", JSONObject.NULL);

				if (arrobj1.has("federated"))
					subJson.put("federated", arrobj1.get("federated"));
				else
					subJson.put("federated", JSONObject.NULL);

				if (arrobj1.has("clientPortalStatus"))
					subJson.put("clientPortalStatus", arrobj1.get("clientPortalStatus"));
				else
					subJson.put("clientPortalStatus", JSONObject.NULL);

				if (arrobj1.has("clientSheetStatus"))
					subJson.put("clientSheetStatus", arrobj1.get("clientSheetStatus"));
				else
					subJson.put("clientSheetStatus", JSONObject.NULL);

				if (arrobj1.has("paTestScore"))
					subJson.put("paTestScore", arrobj1.get("paTestScore"));
				else
					subJson.put("paTestScore", JSONObject.NULL);

				if (arrobj1.has("testScore"))
					subJson.put("testScore", arrobj1.get("testScore"));
				else
					subJson.put("testScore", JSONObject.NULL);

				if (arrobj1.has("avgScore"))
					subJson.put("avgScore", arrobj1.get("avgScore"));
				else
					subJson.put("avgScore", JSONObject.NULL);

				if (arrobj1.has("pageUpId"))
					subJson.put("pageUpId", arrobj1.get("pageUpId"));
				else
					subJson.put("pageUpId", JSONObject.NULL);

				if (arrobj1.has("isClientSheet"))
					subJson.put("isClientSheet", arrobj1.get("isClientSheet"));
				else
					subJson.put("isClientSheet", JSONObject.NULL);

				if (arrobj1.has("ghStatus"))
					subJson.put("ghStatus", arrobj1.get("ghStatus"));
				else
					subJson.put("ghStatus", JSONObject.NULL);

				if (arrobj1.has("ghStatusId"))
					subJson.put("ghStatusId", arrobj1.get("ghStatusId"));
				else
					subJson.put("ghStatusId", JSONObject.NULL);

				if (arrobj1.has("statusId"))
					subJson.put("statusId", arrobj1.get("statusId"));
				else
					subJson.put("statusId", JSONObject.NULL);

				if (arrobj1.has("status"))
					subJson.put("status", arrobj1.get("status"));
				else
					subJson.put("status", JSONObject.NULL);

				if (arrobj1.has("dropComment"))
					subJson.put("dropComment", arrobj1.get("dropComment"));
				else
					subJson.put("dropComment", JSONObject.NULL);

				if (arrobj1.has("comment"))
					subJson.put("comment", arrobj1.get("comment"));
				else
					subJson.put("comment", JSONObject.NULL);

				if (arrobj1.has("withOutId"))
					subJson.put("withOutId", arrobj1.get("withOutId"));
				else
					subJson.put("withOutId", JSONObject.NULL);

				if (arrobj1.has("resumeName"))
					subJson.put("resumeName", arrobj1.get("resumeName"));
				else
					subJson.put("resumeName", JSONObject.NULL);

				if (arrobj1.has("resume"))
					subJson.put("resume", arrobj1.get("resume"));
				else
					subJson.put("resume", JSONObject.NULL);

				jsonArray.put(subJson);

			}

			mainjson.put("total", jobhits.get("total"));
			mainjson.put("response", jsonArray);

			return mainjson.toString();
		}

		@RequestMapping(value = "/ElasticAPI/externalCandidatesSearch", method = { RequestMethod.POST })
		public @ResponseBody String externalCandidatesSearch(@RequestBody String searchFields,
				@RequestParam("jobId") String jobId)
				throws JSONException, URISyntaxException, MalformedURLException, ParseException {

			String urlAttach = "";
			String jsonAttachData = "";
			String search = "";
			search = getSearchQuery(searchFields);
			System.out.println(search);

			if (!search.trim().equals(""))
				urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:"
						+ jobId + ")AND(federated:\"ExternalPortal\")AND(" + search + ")";
			else
				urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:"
						+ jobId + ")AND(federated:\"ExternalPortal\")";

			System.out.println("job query..." + urlAttach);

			URL urljob = new URL(urlAttach);

			URI urijob = new URI(urljob.getProtocol(), urljob.getUserInfo(), urljob.getHost(), urljob.getPort(),
					urljob.getPath(), urljob.getQuery(), urlAttach);

			// System.out.println(urijob);

			jsonAttachData = restTemplate.getForObject(urijob, String.class);

			JSONObject mainjson = new JSONObject();

			JSONArray jsonArray = new JSONArray();

			JSONObject jsonAttach = new JSONObject(jsonAttachData);
			JSONObject jobhits = jsonAttach.getJSONObject("hits");

			JSONArray jobhitsArr = jobhits.getJSONArray("hits");

			for (int i = 0; i < jobhitsArr.length(); i++) {

				JSONObject subJson = new JSONObject();

				JSONObject arrobj = (JSONObject) jobhitsArr.get(i);
				JSONObject arrobj1 = arrobj.getJSONObject("_source");

				if (arrobj1.has("id"))
					subJson.put("id", arrobj1.get("id"));
				else
					subJson.put("id", JSONObject.NULL);

				if (arrobj1.has("objectId"))
					subJson.put("objectId", arrobj1.get("objectId"));
				else
					subJson.put("objectId", JSONObject.NULL);

				if (arrobj1.has("jobId"))
					subJson.put("jobId", arrobj1.get("jobId"));
				else
					subJson.put("jobId", JSONObject.NULL);

				if (arrobj1.has("jobName"))
					subJson.put("jobName", arrobj1.get("jobName"));
				else
					subJson.put("jobName", JSONObject.NULL);

				if (arrobj1.has("clientId"))
					subJson.put("clientId", arrobj1.get("clientId"));
				else
					subJson.put("clientId", JSONObject.NULL);

				if (arrobj1.has("clientName"))
					subJson.put("clientName", arrobj1.get("clientName"));
				else
					subJson.put("clientName", JSONObject.NULL);

				if (arrobj1.has("contactId"))
					subJson.put("contactId", arrobj1.get("contactId"));
				else
					subJson.put("contactId", JSONObject.NULL);

				if (arrobj1.has("contactName"))
					subJson.put("contactName", arrobj1.get("contactName"));
				else
					subJson.put("contactName", JSONObject.NULL);

				if (arrobj1.has("attachedBy"))
					subJson.put("attachedBy", arrobj1.get("attachedBy"));
				else
					subJson.put("attachedBy", JSONObject.NULL);

				if (arrobj1.has("lastModifiedBy"))
					subJson.put("lastModifiedBy", arrobj1.get("lastModifiedBy"));
				else
					subJson.put("lastModifiedBy", JSONObject.NULL);

				if (arrobj1.has("lastModified"))
					subJson.put("lastModified", arrobj1.get("lastModified"));
				else
					subJson.put("lastModified", JSONObject.NULL);

				if (arrobj1.has("createdDate"))
					subJson.put("createdDate", arrobj1.get("createdDate"));
				else
					subJson.put("createdDate", JSONObject.NULL);

				if (arrobj1.has("anchor"))
					subJson.put("anchor", arrobj1.get("anchor"));
				else
					subJson.put("anchor", JSONObject.NULL);

				if (arrobj1.has("cvSentDate"))
					subJson.put("cvSentDate", arrobj1.get("cvSentDate"));
				else
					subJson.put("cvSentDate", JSONObject.NULL);

				if (arrobj1.has("statusChangeDate"))
					subJson.put("statusChangeDate", arrobj1.get("statusChangeDate"));
				else
					subJson.put("statusChangeDate", JSONObject.NULL);

				if (arrobj1.has("statusOutcome"))
					subJson.put("statusOutcome", arrobj1.get("statusOutcome"));
				else
					subJson.put("statusOutcome", JSONObject.NULL);

				if (arrobj1.has("changeReason"))
					subJson.put("changeReason", arrobj1.get("changeReason"));
				else
					subJson.put("changeReason", JSONObject.NULL);

				if (arrobj1.has("federated"))
					subJson.put("federated", arrobj1.get("federated"));
				else
					subJson.put("federated", JSONObject.NULL);

				if (arrobj1.has("clientPortalStatus"))
					subJson.put("clientPortalStatus", arrobj1.get("clientPortalStatus"));
				else
					subJson.put("clientPortalStatus", JSONObject.NULL);

				if (arrobj1.has("clientSheetStatus"))
					subJson.put("clientSheetStatus", arrobj1.get("clientSheetStatus"));
				else
					subJson.put("clientSheetStatus", JSONObject.NULL);

				if (arrobj1.has("paTestScore"))
					subJson.put("paTestScore", arrobj1.get("paTestScore"));
				else
					subJson.put("paTestScore", JSONObject.NULL);

				if (arrobj1.has("testScore"))
					subJson.put("testScore", arrobj1.get("testScore"));
				else
					subJson.put("testScore", JSONObject.NULL);

				if (arrobj1.has("avgScore"))
					subJson.put("avgScore", arrobj1.get("avgScore"));
				else
					subJson.put("avgScore", JSONObject.NULL);

				if (arrobj1.has("pageUpId"))
					subJson.put("pageUpId", arrobj1.get("pageUpId"));
				else
					subJson.put("pageUpId", JSONObject.NULL);

				if (arrobj1.has("isClientSheet"))
					subJson.put("isClientSheet", arrobj1.get("isClientSheet"));
				else
					subJson.put("isClientSheet", JSONObject.NULL);

				if (arrobj1.has("ghStatus"))
					subJson.put("ghStatus", arrobj1.get("ghStatus"));
				else
					subJson.put("ghStatus", JSONObject.NULL);

				if (arrobj1.has("ghStatusId"))
					subJson.put("ghStatusId", arrobj1.get("ghStatusId"));
				else
					subJson.put("ghStatusId", JSONObject.NULL);

				if (arrobj1.has("statusId"))
					subJson.put("statusId", arrobj1.get("statusId"));
				else
					subJson.put("statusId", JSONObject.NULL);

				if (arrobj1.has("status"))
					subJson.put("status", arrobj1.get("status"));
				else
					subJson.put("status", JSONObject.NULL);

				if (arrobj1.has("dropComment"))
					subJson.put("dropComment", arrobj1.get("dropComment"));
				else
					subJson.put("dropComment", JSONObject.NULL);

				if (arrobj1.has("comment"))
					subJson.put("comment", arrobj1.get("comment"));
				else
					subJson.put("comment", JSONObject.NULL);

				if (arrobj1.has("withOutId"))
					subJson.put("withOutId", arrobj1.get("withOutId"));
				else
					subJson.put("withOutId", JSONObject.NULL);

				if (arrobj1.has("resumeName"))
					subJson.put("resumeName", arrobj1.get("resumeName"));
				else
					subJson.put("resumeName", JSONObject.NULL);

				if (arrobj1.has("resume"))
					subJson.put("resume", arrobj1.get("resume"));
				else
					subJson.put("resume", JSONObject.NULL);

				jsonArray.put(subJson);

			}

			mainjson.put("total", jobhits.get("total"));
			mainjson.put("response", jsonArray);

			return mainjson.toString();
		}

		
	       // method to create search query
	       
	       public String getSearchQuery(String field) throws JSONException, ParseException {

	              String query = "";

	              JSONParser parser = new JSONParser();

	              org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) parser.parse(field);

	              for (int i = 0; i < jsonArray.size(); i++) {

	                     org.json.simple.JSONObject json = (org.json.simple.JSONObject) jsonArray.get(i);

	                     // System.out.println("JsonArray........." + json);

	                     String key = (String) json.get("key");
	                     json.remove("key");

	                     String jsonField = json.toString();

	                     jsonField = jsonField.replace("{", "").replace("}", "");

	                     jsonField = jsonField.replaceAll("\"", "");
	                     
	                     if (key.equals("Begins With")) {

	                           jsonField = jsonField.replace(",", "*)AND(");
	                           jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";

	                     } else if (key.equals("Ends With")) {

	                           jsonField = jsonField.replace(":", ":*").replace(",", ")AND(");
	                           jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "))";

	                     } else if (key.equals("Contains")) {

	                           jsonField = jsonField.replace(":", ":*").replace(",", "*)AND(");
	                           jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";

	                     } else if (key.equals("Doesn't contain")) {

	                           jsonField = jsonField.replace(":", ":*").replace(",", "*)AND(");
	                           jsonField = "(NOT((" + jsonField.substring(1, jsonField.length() - 1) + "*)))";

	                     } else if (key.equals("Equal")) {

	                           jsonField = jsonField.replace(":", ":").replace(",", "\")AND(");
	                           jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "\"))";

	                     }

	                     query = query + "OR" + jsonField;
	              }

	              query = query.replaceFirst("OR", "");

	              return query;

	       }

		
		
		
	
}
