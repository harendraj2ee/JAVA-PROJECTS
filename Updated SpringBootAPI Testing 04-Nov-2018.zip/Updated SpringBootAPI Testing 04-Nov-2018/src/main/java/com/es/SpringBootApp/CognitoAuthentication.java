package com.es.SpringBootApp;

import java.security.SignatureException;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONException;
import org.json.JSONObject;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProviderClient;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthRequest;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthResult;
import com.amazonaws.services.cognitoidp.model.AuthFlowType;
import com.amazonaws.services.cognitoidp.model.AuthenticationResultType;
import com.amazonaws.services.cognitoidp.model.ChallengeNameType;
import com.amazonaws.services.cognitoidp.model.NotAuthorizedException;
import com.amazonaws.services.cognitoidp.model.UserNotFoundException;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwt.interfaces.RSAKeyProvider;

public class CognitoAuthentication {

	public static String cognitoAuthenticatin(String username, String password) throws JSONException {
		System.out.println("Hello Test Authentication.... !!!!");
		System.out.println("username >>> " + username);
		System.out.println("password >> " + password);
		String email = "";
		// String username="balraj";
		// String password="Pass@123";
		try {

			System.setProperty("aws.accessKeyId", "AKIAJ2VDULH5BF7AMRAA");
			System.setProperty("aws.secretKey", "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");

			AdminInitiateAuthRequest adminInitiateAuthRequest = new AdminInitiateAuthRequest()
					.withAuthFlow(AuthFlowType.ADMIN_NO_SRP_AUTH).withClientId("iusesa1sgdb20rv7jloju7uok")
					.withUserPoolId("ap-south-1_n3qtyyPr7").addAuthParametersEntry("USERNAME", username)
					.addAuthParametersEntry("PASSWORD", password);

			AWSCognitoIdentityProviderClient awsCognitoIdentityProviderClient = new AWSCognitoIdentityProviderClient()
					.withRegion(Regions.AP_SOUTH_1);

			AdminInitiateAuthResult authResponse = awsCognitoIdentityProviderClient
					.adminInitiateAuth(adminInitiateAuthRequest);

			// authResult.addChallengeParametersEntry(key, value)
			// System.out.println("Hello::::::"+authResponse.toString());

			if (authResponse.getChallengeName() == null) {

				System.out.println("Helloooooooooooo!!!!");
				AuthenticationResultType authResult = authResponse.getAuthenticationResult();

				String tokendata = authResult.getIdToken();
				System.out.println("tokendata >> " + tokendata);

				String[] auth_data = tokendata.split("[.]");
				System.out.println("auth_data >> " + auth_data);
				String encoded_data = auth_data[1];
				System.out.println("encoded_data >> " + encoded_data);

				System.out.println("Cognito Body Data!!!!");

				String body_data = new String(Base64.decodeBase64(encoded_data));
				System.out.println("body_data >> " + body_data);

				JSONObject jsonObject = new JSONObject(body_data);
				// String name = jsonObject.getString("name");
				email = jsonObject.getString("email");
				// System.out.println("name::::" + name);
				System.out.println("email::::" + email);

			} else if (ChallengeNameType.NEW_PASSWORD_REQUIRED.name().equals(authResponse.getChallengeName())) {
				System.out.println("Helloooooooooooo!!!!");
				AuthenticationResultType authResult = authResponse.getAuthenticationResult();

				String tokendata = authResult.getIdToken();
				System.out.println("tokendata::::" + tokendata);
				System.out.println("tokendata::::" + authResult.getIdToken());
				String[] auth_data = tokendata.split("[.]");
				String encoded_data = auth_data[1];
				System.out.println("encoded_data::::" + encoded_data);

				System.out.println("Cognito Body Data!!!!");

				String body_data = new String(Base64.decodeBase64(encoded_data));

				System.out.println("body_data::::" + body_data);

				JSONObject jsonObject = new JSONObject(body_data);
				// String name = jsonObject.getString("name");
				email = jsonObject.getString("email");
				// System.out.println("name::::" + name);
				System.out.println("email::::" + email);
			}

		} catch (UserNotFoundException une) {
			une.printStackTrace();
			System.out.println("getErrorMessage:::" + une.getErrorMessage());
			System.out.println("getMessage:::" + une.getMessage());

			return "{\"error\":\"User Not Found\"}";
		} catch (NotAuthorizedException nae) {
			nae.printStackTrace();
			return "{\"error\":\"Not Authorized\"}";
		} catch (Exception e) {
			e.printStackTrace();
			return "{\"error\":\"Please Provide valid Authentication\"}";
		}
		JSONObject jsonObject = new JSONObject();
		// jsonObject.put("email", email);
		//
		// return jsonObject.toString();

		return email;
	}

	
	
	public static String getToken(String username, String password) throws JSONException {

		String tokendata = "";
		try {

			System.setProperty("aws.accessKeyId", "AKIAJ2VDULH5BF7AMRAA");
			System.setProperty("aws.secretKey", "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");

			AdminInitiateAuthRequest adminInitiateAuthRequest = new AdminInitiateAuthRequest()
					.withAuthFlow(AuthFlowType.ADMIN_NO_SRP_AUTH).withClientId("iusesa1sgdb20rv7jloju7uok")
					.withUserPoolId("ap-south-1_n3qtyyPr7").addAuthParametersEntry("USERNAME", username)
					.addAuthParametersEntry("PASSWORD", password);

			AWSCognitoIdentityProviderClient awsCognitoIdentityProviderClient = new AWSCognitoIdentityProviderClient()
					.withRegion(Regions.AP_SOUTH_1);

			AdminInitiateAuthResult authResponse = awsCognitoIdentityProviderClient
					.adminInitiateAuth(adminInitiateAuthRequest);

//			if (authResponse.getChallengeName() == null) {
				AuthenticationResultType authResult = authResponse.getAuthenticationResult();
				tokendata = authResult.getAccessToken();
//			}
		} catch (UserNotFoundException une) {
			une.printStackTrace();
			return "{\"error\":\"User Not Found\"}";
		} catch (NotAuthorizedException nae) {
			nae.printStackTrace();
			return "{\"error\":\"Not Authorized\"}";
		} catch (Exception e) {
			e.printStackTrace();
			return "{\"error\":\"Please Provide valid Authentication\"}";
		}
		return tokendata;
	}

	

	public static String userAuthentication(String authString) {
		
		String details = "";
		try {
			String arr[] = authString.split(" ");
			String auth = arr[1];
			String authInfo = new String(Base64.decodeBase64(auth));
			String[] u = authInfo.split(":");
			String user = u[0];
			String pass = u[1];
			details = getToken(user, pass);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return details;
	}
	
	
	public static String getValidAuthentication(String auth) throws JSONException {

		String aws_cognito_region = "ap-south-1";
		String aws_user_pools_id = "ap-south-1_n3qtyyPr7";

		RSAKeyProvider keyProvider = new AwsCognitoRSAKeyProvider(aws_cognito_region, aws_user_pools_id);
		Algorithm algorithm = Algorithm.RSA256(keyProvider);
		JWTVerifier jwtVerifier = JWT.require(algorithm).build();

//		try {
			jwtVerifier.verify(auth);
//		} 		
//		catch (TokenExpiredException e) {
//			return "{\"error\":\"Token Expired\"}";
//		} 
//		catch (Exception e) {
//			return "{\"error\":\"Not authenticated User\"}";
//		}
		
		return "valid";

	}

}
