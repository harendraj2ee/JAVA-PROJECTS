
package com.es.SpringBootApp;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.es.model.AttachCount;
import com.es.model.CandidateCount;
import com.es.restServiceImpl.RestService;
import com.es.restServiceImpl.RestServiceImpl;

@Controller
public class ExternalAttachController {
	@Autowired
	private static RestTemplate restTemplate;
	static String sortParam = "";
	RestServiceImpl restService = new RestServiceImpl();

	@RequestMapping(value = "/ElasticAPI/externalattach", method = { RequestMethod.GET })
	public @ResponseBody String externalAttachCandidate(@RequestParam("jobid") String jobid,
			@RequestParam("perpage") Integer perpage, @RequestParam("next") Integer next,
			@RequestParam("sort") String sort, @RequestHeader HttpHeaders headers)
			throws MalformedURLException, URISyntaxException, ParseException, JSONException {


		 if (!headers.containsKey("authorization")) {
				System.out.println("No Authentication");
				return "{\"error\":\"Please Provide The Authentication\"}";
			}
			String authString = headers.getFirst("authorization");
			if (!restService.isUserAuthenticated(authString)) {
				System.out.println("Wrong Authentication.....");
				return "{\"error\":\"User not authenticated\"}";
			}
		ArrayList<AttachCount> list = new ArrayList<AttachCount>();
		list = attachExternal(jobid, perpage, next, sort);
		org.json.JSONObject obj = new org.json.JSONObject();
		org.json.JSONObject obj1 = new org.json.JSONObject();

		org.json.JSONArray array = new org.json.JSONArray();
		array.put(list);
		obj.put("attach", list);
		obj1.put("response", obj);

		String json = getFormattedJson(obj1.toString());

		return json;

	}

	// Candidate External
	public static ArrayList<CandidateCount> candidateExternal(String objectId, String sort) throws ParseException {

		ArrayList<CandidateCount> list = new ArrayList<CandidateCount>();
		RestTemplate restTemplate = new RestTemplate();
		String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:"
				+ objectId + ")AND(federated:\"externalPortal\")";

		if (sort.equals("namea") || sort.equals("named") || sort.equals("fnamea") || sort.equals("fnamed")
				|| sort.equals("mnamea") || sort.equals("mnamed") || sort.equals("lnamea") || sort.equals("lnamed")
				|| sort.equals("emaila") || sort.equals("emaild") || sort.equals("mobilea") || sort.equals("mobiled") ||
				sort.equals("birthdatea") || sort.equals("birthdated") || sort.equals("altemaila") || sort.equals("altemaild")) {

			sortParam = "candidate";

			if (sort.equals("namea")) {
				sort = "name.keyword:" + "asc";
			} else if (sort.equals("named")) {
				sort = "name.keyword:" + "desc";
			}

			if (sort.equals("fnamea")) {
				sort = "first_name.keyword:" + "asc";
			} else if (sort.equals("fnamed")) {
				sort = "first_name.keyword:" + "desc";
			}

			if (sort.equals("mnamea")) {
				sort = "middle_name.keyword:" + "asc";
			} else if (sort.equals("mnamed")) {
				sort = "middle_name.keyword:" + "desc";
			}

			if (sort.equals("lnamea")) {
				sort = "last_name.keyword:" + "asc";
			} else if (sort.equals("lnamed")) {
				sort = "last_name.keyword:" + "desc";
			}

			if (sort.equals("emaila")) {
				sort = "email.keyword:" + "asc";
			} else if (sort.equals("emaild")) {
				sort = "email.keyword:" + "desc";
			}

			if (sort.equals("mobilea")) {
				sort = "mobileNumber.keyword:" + "asc";
			} else if (sort.equals("mobiled")) {
				sort = "mobileNumber.keyword:" + "desc";
			}
			if (sort.equals("birthdatea")) {
				sort = "birthdate.keyword:" + "asc";
			} else if (sort.equals("birthdated")) {
				sort = "birthdate.keyword:" + "desc";
			}
			if (sort.equals("altemaila")) {
				sort = "alternateEmail.keyword:" + "asc";
			} else if (sort.equals("altemaild")) {
				sort = "alternateEmail.keyword:" + "desc";
			}

			urlCandidate = urlCandidate + "&sort=" + sort;

		}

		urlCandidate = urlCandidate
				+ "&pretty=true&_source=id,name,first_name,middle_name,last_name,email,alternateEmail,birthdate,mobileNumber";

		System.out.println("urlCandidate>> " + urlCandidate);
		JSONParser jsonParsercan = new JSONParser();

		String candidate = restTemplate.getForObject(urlCandidate, String.class);
		org.json.simple.JSONObject jsoncan = (org.json.simple.JSONObject) ((org.json.simple.JSONObject) jsonParsercan
				.parse(candidate)).get("hits");

		org.json.simple.JSONArray arraycan = (org.json.simple.JSONArray) jsoncan.get("hits");
		Iterator itratorcan = arraycan.iterator();

		while (itratorcan.hasNext()) {
			CandidateCount e = new CandidateCount();

			org.json.simple.JSONObject jsonObjectcan = (org.json.simple.JSONObject) itratorcan.next();
			jsonObjectcan = (org.json.simple.JSONObject) jsonObjectcan.get("_source");

			if (jsonObjectcan.get("id") != null) {
				String id = (String) jsonObjectcan.get("id");
				e.setId(id);
			} else {
				String id = (String) jsonObjectcan.get("id");
			}
			if (jsonObjectcan.get("name") != null) {
				String name = (String) jsonObjectcan.get("name");
				e.setName(name);
			} else {
				String name = (String) jsonObjectcan.get("name");
			}
			if (jsonObjectcan.get("first_name") != null) {
				String first_name = (String) jsonObjectcan.get("first_name");
				e.setFirst_name(first_name);
			} else {
				String first_name = (String) jsonObjectcan.get("first_name");
			}
			if (jsonObjectcan.get("middle_name") != null) {
				String middle_name = (String) jsonObjectcan.get("middle_name");
				e.setMiddle_name(middle_name);
			} else {
				String middle_name = (String) jsonObjectcan.get("middle_name");
			}
			if (jsonObjectcan.get("last_name") != null) {
				String last_name = (String) jsonObjectcan.get("last_name");
				e.setLast_name(last_name);
			} else {
				String last_name = (String) jsonObjectcan.get("last_name");
			}
			if (jsonObjectcan.get("email") != null) {
				String email = (String) jsonObjectcan.get("email");
				e.setEmail(email);
			} else {
				String email = (String) jsonObjectcan.get("email");
			}
			if (jsonObjectcan.get("alternateEmail") != null) {
				List<String> alternateEmail = (List<String>) jsonObjectcan.get("alternateEmail");
				e.setAlternateEmail(alternateEmail);
			} else {
				List alternateEmail = (List) jsonObjectcan.get("alternateEmail");
			}

			if (jsonObjectcan.get("birthdate") != null) {
				String birthdate = (String) jsonObjectcan.get("birthdate");
				e.setBirthdate(birthdate);
			} else {
				String birthdate = (String) jsonObjectcan.get("birthdate");
			}
			if (jsonObjectcan.get("mobileNumber") != null) {
				String mobileNumber = (String) jsonObjectcan.get("mobileNumber");
				e.setMobileNumber(mobileNumber);
			} else {
				String mobileNumber = (String) jsonObjectcan.get("mobileNumber");
			}

			list.add(e);

		}
		return list;
	}

	// Attach External
	public ArrayList<AttachCount> attachExternal(String jobId, Integer perpage, Integer next, String sort)
			throws ParseException {

		String urlAttach = "";
		int start = perpage * (next - 1);

		ArrayList<AttachCount> list = new ArrayList<AttachCount>();
		ArrayList mainlist = new ArrayList();
		ArrayList<CandidateCount> canlist = new ArrayList<CandidateCount>();
		RestTemplate restTemplate = new RestTemplate();

		String id = "";
		String objectId = "";
		String jobIdd = "";
		String jobName = "";
		String clientId = "";
		String clientName = "";
		String contactId = "";
		String contactName = "";
		String attachedBy = "";
		String lastModifiedBy = "";
		String lastModified = "";
		String createdDate = "";
		String anchor = "";
		String cvSentDate = "";
		String statusChangeDate = "";
		String statusOutcome = "";
		String federated = "";
		String changeReason = "";
		String clientPortalStatus = "";
		String clientSheetStatus = "";
		String paTestScore = "";
		String testScore = "";
		String avgScore = "";
		Long pageUpId;
		Long isClientSheet;
		String ghStatus = "";
		Long ghStatusId;
		Long statusId;
		String status = "";
		String dropComment = "";
		String comment = "";
		Long withOutId;

		urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""
				+ jobId + "\")AND(federated:\"externalPortal\")&size=" + perpage + "&from=" + start;

		if (!sort.equals("namea") && !sort.equals("named") && !sort.equals("fnamea") && !sort.equals("fnamed")
				&& !sort.equals("mnamea") && !sort.equals("mnamed") && !sort.equals("lnamea") && !sort.equals("lnamed")
				&& !sort.equals("emaila") && !sort.equals("emaild") && !sort.equals("mobilea") && !sort.equals("mobiled") && 
				!sort.equals("birthdatea") && !sort.equals("birthdated") && !sort.equals("altemaila") && !sort.equals("altemaild")) {

			sortParam = "attach";

			if (sort.equals("createddatea")) {
				sort = "createdDate.keyword:" + "asc";
			} else if (sort.equals("createddated")) {
				sort = "createdDate.keyword:" + "desc";
			}
			if (sort.equals("clientnamea")) {
				sort = "clientName.keyword:" + "asc";
			} else if (sort.equals("clientnamed")) {
				sort = "clientName.keyword:" + "desc";
			}

			if (sort.equals("dropcommenta")) {
				sort = "dropComment.keyword:" + "asc";
			} else if (sort.equals("dropcommentd")) {
				sort = "dropComment.keyword:" + "desc";
			}
			if (sort.equals("lastmodifiedbya")) {
				sort = "lastModifiedBy.keyword:" + "asc";
			} else if (sort.equals("lastmodifiedbyd")) {
				sort = "lastModifiedBy.keyword:" + "desc";
			}
			if (sort.equals("anchora")) {
				sort = "anchor.keyword:" + "asc";
			} else if (sort.equals("anchord")) {
				sort = "anchor.keyword:" + "desc";
			}
			if (sort.equals("anchorida")) {
				sort = "anchorId.keyword:" + "asc";
			} else if (sort.equals("anchoridd")) {
				sort = "anchorId.keyword:" + "desc";
			}
			if (sort.equals("statusa")) {
				sort = "status.keyword:" + "asc";
			} else if (sort.equals("statusd")) {
				sort = "status.keyword:" + "desc";
			}
			if (sort.equals("jobnamea")) {
				sort = "jobName.keyword:" + "asc";
			} else if (sort.equals("jobnamed")) {
				sort = "jobName.keyword:" + "desc";
			}
			if (sort.equals("clientida")) {
				sort = "clientId.keyword:" + "asc";
			} else if (sort.equals("clientidd")) {
				sort = "clientId.keyword:" + "desc";
			}
			if (sort.equals("contactida")) {
				sort = "contactId.keyword:" + "asc";
			} else if (sort.equals("contactidd")) {
				sort = "contactId.keyword:" + "desc";
			}
			if (sort.equals("contactnamea")) {
				sort = "contactName.keyword:" + "asc";
			} else if (sort.equals("contactnamed")) {
				sort = "contactName.keyword:" + "desc";
			}
			if (sort.equals("attachedbya")) {
				sort = "attachedBy.keyword:" + "asc";
			} else if (sort.equals("attachedbyd")) {
				sort = "attachedBy.keyword:" + "desc";
			}
			if (sort.equals("lastmodifieda")) {
				sort = "lastModified.keyword:" + "asc";
			} else if (sort.equals("lastmodifiedd")) {
				sort = "lastModified.keyword:" + "desc";
			}
			if (sort.equals("cvsentdatea")) {
				sort = "cvSentDate.keyword:" + "asc";
			} else if (sort.equals("cvsentdated")) {
				sort = "cvSentDate.keyword:" + "desc";
			}
			if (sort.equals("statuschangedatea")) {
				sort = "statusChangeDate.keyword:" + "asc";
			} else if (sort.equals("statuschangedated")) {
				sort = "statusChangeDate.keyword:" + "desc";
			}
			if (sort.equals("statusoutcomea")) {
				sort = "statusOutcome.keyword:" + "asc";
			} else if (sort.equals("statusoutcomed")) {
				sort = "statusOutcome.keyword:" + "desc";
			}
			if (sort.equals("changereasona")) {
				sort = "changeReason.keyword:" + "asc";
			} else if (sort.equals("changereasond")) {
				sort = "changeReason.keyword:" + "desc";
			}
			if (sort.equals("clientportalstatusa")) {
				sort = "clientPortalStatus.keyword:" + "asc";
			} else if (sort.equals("clientportalstatusd")) {
				sort = "clientPortalStatus.keyword:" + "desc";
			}
			
			if (sort.equals("clientsheetstatusa")) {
				sort = "clientSheetStatus.keyword:" + "asc";
			} else if (sort.equals("clientsheetstatusd")) {
				sort = "clientSheetStatus.keyword:" + "desc";
			}
			
			if (sort.equals("patestscorea")) {
				sort = "paTestScore.keyword:" + "asc";
			} else if (sort.equals("patestscored")) {
				sort = "paTestScore.keyword:" + "desc";
			}
			if (sort.equals("testscorea")) {
				sort = "testScore.keyword:" + "asc";
			} else if (sort.equals("testscored")) {
				sort = "testScore.keyword:" + "desc";
			}
			if (sort.equals("avgscorea")) {
				sort = "avgScore.keyword:" + "asc";
			} else if (sort.equals("avgscored")) {
				sort = "avgScore.keyword:" + "desc";
			}
			if (sort.equals("pageupida")) {
				sort = "pageUpId.keyword:" + "asc";
			} else if (sort.equals("pageupidd")) {
				sort = "pageUpId.keyword:" + "desc";
			}
			if (sort.equals("isclientSheeta")) {
				sort = "isClientSheet.keyword:" + "asc";
			} else if (sort.equals("isclientSheetd")) {
				sort = "isClientSheet.keyword:" + "desc";
			}
			
			if (sort.equals("ghstatusa")) {
				sort = "ghStatus.keyword:" + "asc";
			} else if (sort.equals("ghstatusd")) {
				sort = "ghStatus.keyword:" + "desc";
			}
			
			if (sort.equals("ghstatusida")) {
				sort = "ghStatusId.keyword:" + "asc";
			} else if (sort.equals("ghstatusidd")) {
				sort = "ghStatusId.keyword:" + "desc";
			}
	
			if (sort.equals("statusida")) {
				sort = "statusId.keyword:" + "asc";
			} else if (sort.equals("statusidd")) {
				sort = "statusId.keyword:" + "desc";
			}
			
			if (sort.equals("commenta")) {
				sort = "comment.keyword:" + "asc";
			} else if (sort.equals("commentd")) {
				sort = "comment.keyword:" + "desc";
			}
			if (sort.equals("withoutida")) {
				sort = "withOutId.keyword:" + "asc";
			} else if (sort.equals("withoutidd")) {
				sort = "withOutId.keyword:" + "desc";
			}
			if (sort.equals("federateda")) {
				sort =  "federated.keyword:" +"asc";
			}else if (sort.equals("federatedd")) {
				sort = "federated.keyword:" + "desc";
			}
			urlAttach = urlAttach + "&sort=" + sort;

		}

		urlAttach = urlAttach
				+ "&pretty=true&_source=federated,id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,lastModifiedBy,lastModified,createdDate,anchor,anchorId,cvSentDate,statusChangeDate,statusOutcome,changeReason,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId";// resume
		System.out.println("urlAttach>> " + urlAttach);

		JSONParser jsonParserAttach = new JSONParser();
		String attach = restTemplate.getForObject(urlAttach, String.class);
		org.json.simple.JSONObject jsonAttach = (org.json.simple.JSONObject) ((org.json.simple.JSONObject) jsonParserAttach
				.parse(attach)).get("hits");

		org.json.simple.JSONArray arrayAtach = (org.json.simple.JSONArray) jsonAttach.get("hits");
		Iterator itratorcan = arrayAtach.iterator();

		String ids = "";
		AttachCount e1 = new AttachCount();

		while (itratorcan.hasNext()) {
			AttachCount e = new AttachCount();

			org.json.simple.JSONObject jsonObjectAttach = (org.json.simple.JSONObject) itratorcan.next();
			jsonObjectAttach = (org.json.simple.JSONObject) jsonObjectAttach.get("_source");

			id = (String) jsonObjectAttach.get("id");
			e.setId(id);

			objectId = (String) jsonObjectAttach.get("objectId");
			e.setObjectId(objectId);

			jobIdd = (String) jsonObjectAttach.get("jobId");
			e.setJobId(jobIdd);
			// can

			ids = ids + "," + objectId;
			if (jsonObjectAttach.get("dropComment") != null) {
				dropComment = (String) jsonObjectAttach.get("dropComment");
				e.setDropComment(dropComment);
			} else {
				dropComment = (String) jsonObjectAttach.get("dropComment");
			}
			if (jsonObjectAttach.get("lastModifiedBy") != null) {
				lastModifiedBy = (String) jsonObjectAttach.get("lastModifiedBy");
				e.setLastModifiedBy(lastModifiedBy);
			} else {
				lastModifiedBy = (String) jsonObjectAttach.get("lastModifiedBy");
			}
			if (jsonObjectAttach.get("createdDate") != null) {
				createdDate = (String) jsonObjectAttach.get("createdDate");
				e.setCreatedDate(createdDate);
			} else {
				createdDate = (String) jsonObjectAttach.get("createdDate");
			}
			if (jsonObjectAttach.get("anchor") != null) {
				anchor = (String) jsonObjectAttach.get("anchor");
				e.setAnchor(anchor);
			} else {
				anchor = (String) jsonObjectAttach.get("anchor");
			}
			
			if (jsonObjectAttach.get("status") != null) {
				status = (String) jsonObjectAttach.get("status");
				e.setStatus(status);
			} else {
				status = (String) jsonObjectAttach.get("status");
			}
			if (jsonObjectAttach.get("jobName") != null) {
				jobName = (String) jsonObjectAttach.get("jobName");
				e.setJobName(jobName);
			} else {
				jobName = (String) jsonObjectAttach.get("jobName");
			}
			if (jsonObjectAttach.get("clientId") != null) {
				clientId = (String) jsonObjectAttach.get("clientId");
				e.setClientId(clientId);
			} else {
				clientId = (String) jsonObjectAttach.get("clientId");
			}
			if (jsonObjectAttach.get("clientName") != null) {
				clientName = (String) jsonObjectAttach.get("clientName");
				e.setClientName(clientName);
			} else {
				clientName = (String) jsonObjectAttach.get("clientName");
			}
			if (jsonObjectAttach.get("contactId") != null) {
				contactId = (String) jsonObjectAttach.get("contactId");
				e.setContactId(contactId);
			} else {
				contactId = (String) jsonObjectAttach.get("contactId");
			}
			if (jsonObjectAttach.get("contactName") != null) {
				contactName = (String) jsonObjectAttach.get("contactName");
				e.setContactName(contactName);
			} else {
				contactName = (String) jsonObjectAttach.get("contactName");
			}
			if (jsonObjectAttach.get("attachedBy") != null) {
				attachedBy = (String) jsonObjectAttach.get("attachedBy");
				e.setAttachedBy(attachedBy);
			} else {
				attachedBy = (String) jsonObjectAttach.get("attachedBy");
			}
			if (jsonObjectAttach.get("lastModified") != null) {
				lastModified = (String) jsonObjectAttach.get("lastModified");
				e.setLastModified(lastModified);
			} else {
				lastModified = (String) jsonObjectAttach.get("lastModified");
			}
			if (jsonObjectAttach.get("cvSentDate") != null) {
				cvSentDate = (String) jsonObjectAttach.get("cvSentDate");
				e.setCvSentDate(cvSentDate);
			} else {
				cvSentDate = (String) jsonObjectAttach.get("cvSentDate");
			}
			if (jsonObjectAttach.get("statusChangeDate") != null) {
				statusChangeDate = (String) jsonObjectAttach.get("statusChangeDate");
				e.setStatusChangeDate(statusChangeDate);
			} else {
				statusChangeDate = (String) jsonObjectAttach.get("statusChangeDate");
			}
			if (jsonObjectAttach.get("statusOutcome") != null) {
				statusOutcome = (String) jsonObjectAttach.get("statusOutcome");
				e.setStatusOutcome(statusOutcome);
			} else {
				statusOutcome = (String) jsonObjectAttach.get("statusOutcome");
			}
			if (jsonObjectAttach.get("changeReason") != null) {
				changeReason = (String) jsonObjectAttach.get("changeReason");
				e.setChangeReason(changeReason);
			} else {
				changeReason = (String) jsonObjectAttach.get("changeReason");
			}
			if (jsonObjectAttach.get("clientPortalStatus") != null) {
				clientPortalStatus = (String) jsonObjectAttach.get("clientPortalStatus");
				e.setClientPortalStatus(clientPortalStatus);
			} else {
				clientPortalStatus = (String) jsonObjectAttach.get("clientPortalStatus");
			}
			if (jsonObjectAttach.get("clientSheetStatus") !=null) {
				clientSheetStatus = (String) jsonObjectAttach.get("clientSheetStatus");
				e.setClientSheetStatus(clientSheetStatus);
			}else {
				clientSheetStatus = (String) jsonObjectAttach.get("clientSheetStatus");
			}
			
			if (jsonObjectAttach.get("paTestScore") != null) {
				paTestScore = (String) jsonObjectAttach.get("paTestScore");
				e.setPaTestScore(paTestScore);
			} else {
				paTestScore = (String) jsonObjectAttach.get("paTestScore");
			}
			if (jsonObjectAttach.get("testScore") != null) {
				testScore = (String) jsonObjectAttach.get("testScore");
				e.setTestScore(testScore);
			} else {
				testScore = (String) jsonObjectAttach.get("testScore");
			}
			if (jsonObjectAttach.get("avgScore") != null) {
				avgScore = (String) jsonObjectAttach.get("avgScore");
				e.setAvgScore(avgScore);
			} else {
				avgScore = (String) jsonObjectAttach.get("avgScore");
			}
			if (jsonObjectAttach.get("pageUpId") != null) {
				pageUpId = (Long) jsonObjectAttach.get("pageUpId");
				e.setPageUpId(pageUpId);
			} else {
				pageUpId = (Long) jsonObjectAttach.get("pageUpId");
			}
			if (jsonObjectAttach.get("isClientSheet") !=null) {
				isClientSheet = (Long) jsonObjectAttach.get("isClientSheet");
				e.setIsClientSheet(isClientSheet);
			}else {
				isClientSheet = (Long) jsonObjectAttach.get("isClientSheet");
			}
			
				
			if (jsonObjectAttach.get("ghStatus") != null) {
				ghStatus = (String) jsonObjectAttach.get("ghStatus");
				e.setGhStatus(ghStatus);
			} else {
				ghStatus = (String) jsonObjectAttach.get("ghStatus");
			}
			
			if (jsonObjectAttach.get("ghStatusId") != null) {
				ghStatusId = (Long) jsonObjectAttach.get("ghStatusId");
				e.setGhStatusId(ghStatusId);
			} else {
				ghStatusId = (Long) jsonObjectAttach.get("ghStatusId");
			}
			
			if (jsonObjectAttach.get("statusId") != null) {
				statusId = (Long) jsonObjectAttach.get("statusId");
				e.setStatusId(statusId);
			} else {
				statusId = (Long) jsonObjectAttach.get("statusId");
			}
			
			if (jsonObjectAttach.get("comment") != null) {
				comment = (String) jsonObjectAttach.get("comment");
				e.setComment(comment);
			} else {
				jsonObjectAttach.get("comment");
			}
			if (jsonObjectAttach.get("withOutId") != null) {
				withOutId = (Long) jsonObjectAttach.get("withOutId");
				e.setWithOutId(withOutId);
			} else {
				withOutId = (Long) jsonObjectAttach.get("withOutId");
			}
			
			if (jsonObjectAttach.get("federated") != null) {
				federated = (String) jsonObjectAttach.get("federated");
				e.setFederated(federated);
			} else {
				federated = (String) jsonObjectAttach.get("federated");
			}
			

			list.add(e);

		}
		mainlist.add(list);

		ids = ids.replaceFirst(",", "");
		ids = ids.replace(",", ")OR(id:");
		canlist = candidateExternal(ids, sort);

		mainlist.add(canlist);
		e1.setCandidate(mainlist);

		return mainlist;
	}

	// External Candidate Search API...
	@RequestMapping(value = "/ElasticAPI/externalattachsearch", method = { RequestMethod.POST })
	public @ResponseBody String externalAttachCandidateSearch(@RequestBody String field,
			@RequestParam("jobid") String jobid, @RequestParam("perpage") Integer perpage,
			@RequestParam("next") Integer next, @RequestParam("sort") String sort, @RequestHeader HttpHeaders headers) throws MalformedURLException,
			URISyntaxException, ParseException, JSONException, UnsupportedEncodingException {

		 if (!headers.containsKey("authorization")) {
				System.out.println("No Authentication");
				return "{\"error\":\"Please Provide The Authentication\"}";
			}
			String authString = headers.getFirst("authorization");
			if (!restService.isUserAuthenticated(authString)) {
				System.out.println("Wrong Authentication.....");
				return "{\"error\":\"User not authenticated\"}";
			}
		
		ArrayList<AttachCount> list = new ArrayList<AttachCount>();
		list = attachExternalSearch(jobid, perpage, next, field, sort);
		org.json.JSONObject obj = new org.json.JSONObject();
		org.json.JSONObject obj1 = new org.json.JSONObject();

		obj.put("attach", list);
		obj1.put("response", obj);

		String json = getFormattedJson(obj1.toString());

		return json;

	}

	// Candidate External portal search AND(federated:\"externalPortal\")

	public static ArrayList<CandidateCount> candidateExternalSearch(String objectId, String sort, String candidateQuery)
			throws ParseException, UnsupportedEncodingException, MalformedURLException, URISyntaxException {
		String urlCandidate = "";
		ArrayList<CandidateCount> list = new ArrayList<CandidateCount>();
		RestTemplate restTemplate = new RestTemplate();

		urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=((id:"
				+ objectId + "))AND(federated:\"externalPortal\")";

		if (candidateQuery.length() > 0)
			urlCandidate = urlCandidate + "AND(" + candidateQuery + ")";

		if (sort.equals("namea") || sort.equals("named") || sort.equals("fnamea") || sort.equals("fnamed")
				|| sort.equals("mnamea") || sort.equals("mnamed") || sort.equals("lnamea") || sort.equals("lnamed")
				|| sort.equals("emaila") || sort.equals("emaild") || sort.equals("mobilea") || sort.equals("mobiled") ||
				sort.equals("birthdatea") || sort.equals("birthdated") || sort.equals("altemaila") || sort.equals("altemaild")) {

			sortParam = "candidate";

			if (sort.equals("namea")) {
				sort = "name.keyword:" + "asc";
			} else if (sort.equals("named")) {
				sort = "name.keyword:" + "desc";
			}

			if (sort.equals("fnamea")) {
				sort = "first_name.keyword:" + "asc";
			} else if (sort.equals("fnamed")) {
				sort = "first_name.keyword:" + "desc";
			}

			if (sort.equals("mnamea")) {
				sort = "middle_name.keyword:" + "asc";
			} else if (sort.equals("mnamed")) {
				sort = "middle_name.keyword:" + "desc";
			}

			if (sort.equals("lnamea")) {
				sort = "last_name.keyword:" + "asc";
			} else if (sort.equals("lnamed")) {
				sort = "last_name.keyword:" + "desc";
			}

			if (sort.equals("emaila")) {
				sort = "email.keyword:" + "asc";
			} else if (sort.equals("emaild")) {
				sort = "email.keyword:" + "desc";
			}

			if (sort.equals("mobilea")) {
				sort = "mobileNumber.keyword:" + "asc";
			} else if (sort.equals("mobiled")) {
				sort = "mobileNumber.keyword:" + "desc";
			}
			if (sort.equals("birthdatea")) {
				sort = "birthdate.keyword:" + "asc";
			} else if (sort.equals("birthdated")) {
				sort = "birthdate.keyword:" + "desc";
			}
			if (sort.equals("altemaila")) {
				sort = "alternateEmail.keyword:" + "asc";
			} else if (sort.equals("altemaild")) {
				sort = "alternateEmail.keyword:" + "desc";
			}

			urlCandidate = urlCandidate + "&sort=" + sort;

		}

		urlCandidate = urlCandidate
				+ "&pretty=true&_source=id,name,first_name,middle_name,last_name,email,alternateEmail,birthdate,mobileNumber";

		System.out.println("urlCandidate>> " + urlCandidate);
		JSONParser jsonParsercan = new JSONParser();

		String candidate = restTemplate.getForObject(urlCandidate, String.class);
		org.json.simple.JSONObject jsoncan = (org.json.simple.JSONObject) ((org.json.simple.JSONObject) jsonParsercan
				.parse(candidate)).get("hits");

		org.json.simple.JSONArray arraycan = (org.json.simple.JSONArray) jsoncan.get("hits");
		Iterator<?> itratorcan = arraycan.iterator();

		while (itratorcan.hasNext()) {
			CandidateCount e = new CandidateCount();

			org.json.simple.JSONObject jsonObjectcan = (org.json.simple.JSONObject) itratorcan.next();
			jsonObjectcan = (org.json.simple.JSONObject) jsonObjectcan.get("_source");

			if (jsonObjectcan.get("id") != null) {
				String id = (String) jsonObjectcan.get("id");
				e.setId(id);
			}
			if (jsonObjectcan.get("name") != null) {
				String name = (String) jsonObjectcan.get("name");
				e.setName(name);
			}
			if (jsonObjectcan.get("first_name") != null) {
				String first_name = (String) jsonObjectcan.get("first_name");
				e.setFirst_name(first_name);
			}
			if (jsonObjectcan.get("middle_name") != null) {
				String middle_name = (String) jsonObjectcan.get("middle_name");
				e.setMiddle_name(middle_name);
			}
			if (jsonObjectcan.get("last_name") != null) {
				String last_name = (String) jsonObjectcan.get("last_name");
				e.setLast_name(last_name);
			}
			if (jsonObjectcan.get("email") != null) {
				String email = (String) jsonObjectcan.get("email");
				e.setEmail(email);
			}
			if (jsonObjectcan.get("alternateEmail") != null) {
				List<String> alternateEmail = (List<String>) jsonObjectcan.get("alternateEmail");
				e.setAlternateEmail(alternateEmail);
			}
			if (jsonObjectcan.get("birthdate") != null) {
				String birthdate = (String) jsonObjectcan.get("birthdate");
				e.setBirthdate(birthdate);
			}
			if (jsonObjectcan.get("mobileNumber") != null) {
				String mobileNumber = (String) jsonObjectcan.get("mobileNumber");
				e.setMobileNumber(mobileNumber);
			}

			list.add(e);

		}
		return list;
	}

	// Attach ExternalPortal Search
	public ArrayList<AttachCount> attachExternalSearch(String jobId, Integer perpage, Integer next, String field,
			String sort)
			throws ParseException, UnsupportedEncodingException, MalformedURLException, URISyntaxException {
		String urlAttach = "";
		int start = perpage * (next - 1);

		ArrayList<AttachCount> list = new ArrayList<AttachCount>();
		ArrayList mainlist = new ArrayList();
		ArrayList<CandidateCount> canlist = new ArrayList<CandidateCount>();
		RestTemplate restTemplate = new RestTemplate();
		
		String id = "";
		String objectId = "";
		String jobIdd = "";
		String jobName = "";
		String clientId = "";
		String clientName = "";
		String contactId = "";
		String contactName = "";
		String attachedBy = "";
		String lastModifiedBy = "";
		String lastModified = "";
		String createdDate = "";
		String anchor = "";
		String cvSentDate = "";
		String statusChangeDate = "";
		String statusOutcome = "";
		String federated = "";
		String changeReason = "";
		String clientPortalStatus = "";
		String clientSheetStatus = "";
		String paTestScore = "";
		String testScore = "";
		String avgScore = "";
		Long pageUpId;
		Long isClientSheet;
		String ghStatus = "";
		Long ghStatusId;
		Long statusId;
		String status = "";
		String dropComment = "";
		String comment = "";
		Long withOutId;

		
		String attachQuery = "";
		String candidateQuery = "";
		JSONObject json = new JSONObject();

		/* main URL */

		urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""
				+ jobId + "\")AND(federated:\"externalPortal\")";

		/* search query */
		JSONParser parser = new JSONParser();

		JSONArray jsonArray = (JSONArray) parser.parse(field);

		for (int i = 0; i < jsonArray.size(); i++) {

			json = (JSONObject) jsonArray.get(i);

			String key = (String) json.get("key");
			json.remove("key");

			String jsonField = json.toString();

			jsonField = jsonField.replace("{", "").replace("}", "");

			if (key.equals("Begins With")) {

				jsonField = jsonField.replace("\":\"", ":").replace("\",\"", "*)AND(");
				if (jsonField.contains("AND"))
					jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";
				else
					jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + "*)";

			} else if (key.equals("Ends With")) {

				jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", ")AND(");
				if (jsonField.contains("AND"))
					jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "))";
				else
					jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + ")";

			} else if (key.equals("Contains")) {

				jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");
				if (jsonField.contains("AND"))
					jsonField = "((" + jsonField.substring(1, jsonField.length() - 1) + "*))";
				else
					jsonField = "(" + jsonField.substring(1, jsonField.length() - 1) + "*)";

			} else if (key.equals("Doesn't contain")) {

				jsonField = jsonField.replace("\":\"", ":*").replace("\",\"", "*)AND(");

				if (jsonField.contains("AND"))
					jsonField = "(NOT((" + jsonField.substring(1, jsonField.length() - 1) + "*)))";
				else
					jsonField = "(NOT(" + jsonField.substring(1, jsonField.length() - 1) + "*))";

			} else if (key.equals("Equal")) {

				jsonField = jsonField.replace("\":\"", ":\"").replace("\",\"", "\")AND(");
				if (jsonField.contains("AND"))
					jsonField = "((" + jsonField.substring(1, jsonField.length()) + "))";
				else
					jsonField = "(" + jsonField.substring(1, jsonField.length()) + ")";
			}

			String check = jsonField.substring(0, jsonField.indexOf(":")).replace("(", "");

			String attachFields = "objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,"
					+ "anchor,cvSentDate,statusChangeDate,statusOutcome,changeReason,federated,clientPortalStatus,clientSheetStatus,paTestScore"
					+ "testScore,avgScore,pageUpId,isClientSheet,ghStatus,ghStatusId,statusId,status,dropComment,comment,withOutId";

			String candidateFields = "id,name,first_name,middle_name,last_name,email,alternateEmail,birthdate,mobileNumber";

			if (attachFields.contains(check)) {
				attachQuery = attachQuery + "OR" + jsonField;

			} else if (candidateFields.contains(check)) {
				candidateQuery = candidateQuery + "OR" + jsonField;

			}
		}

		attachQuery = attachQuery.replaceFirst("OR", "");
		candidateQuery = candidateQuery.replaceFirst("OR", "");

		System.out.println(attachQuery);
		System.out.println(candidateQuery);

		if (attachQuery.length() > 0)
			urlAttach = urlAttach + "AND(" + attachQuery + ")";

		urlAttach = urlAttach + "&size=" + perpage + "&from=" + start;

		/* sort query */
		if (!sort.equals("namea") && !sort.equals("named") && !sort.equals("fnamea") && !sort.equals("fnamed")
				&& !sort.equals("mnamea") && !sort.equals("mnamed") && !sort.equals("lnamea") && !sort.equals("lnamed")
				&& !sort.equals("emaila") && !sort.equals("emaild") && !sort.equals("mobilea") && !sort.equals("mobiled") && 
				!sort.equals("birthdatea") && !sort.equals("birthdated") && !sort.equals("altemaila") && !sort.equals("altemaild")) {

			sortParam = "attach";

			if (sort.equals("createddatea")) {
				sort = "createdDate.keyword:" + "asc";
			} else if (sort.equals("createddated")) {
				sort = "createdDate.keyword:" + "desc";
			}
			if (sort.equals("clientnamea")) {
				sort = "clientName.keyword:" + "asc";
			} else if (sort.equals("clientnamed")) {
				sort = "clientName.keyword:" + "desc";
			}

			if (sort.equals("dropcommenta")) {
				sort = "dropComment.keyword:" + "asc";
			} else if (sort.equals("dropcommentd")) {
				sort = "dropComment.keyword:" + "desc";
			}
			if (sort.equals("lastmodifiedbya")) {
				sort = "lastModifiedBy.keyword:" + "asc";
			} else if (sort.equals("lastmodifiedbyd")) {
				sort = "lastModifiedBy.keyword:" + "desc";
			}
			if (sort.equals("anchora")) {
				sort = "anchor.keyword:" + "asc";
			} else if (sort.equals("anchord")) {
				sort = "anchor.keyword:" + "desc";
			}
			if (sort.equals("anchorida")) {
				sort = "anchorId.keyword:" + "asc";
			} else if (sort.equals("anchoridd")) {
				sort = "anchorId.keyword:" + "desc";
			}
			if (sort.equals("statusa")) {
				sort = "status.keyword:" + "asc";
			} else if (sort.equals("statusd")) {
				sort = "status.keyword:" + "desc";
			}
			if (sort.equals("jobnamea")) {
				sort = "jobName.keyword:" + "asc";
			} else if (sort.equals("jobnamed")) {
				sort = "jobName.keyword:" + "desc";
			}
			if (sort.equals("clientida")) {
				sort = "clientId.keyword:" + "asc";
			} else if (sort.equals("clientidd")) {
				sort = "clientId.keyword:" + "desc";
			}
			if (sort.equals("contactida")) {
				sort = "contactId.keyword:" + "asc";
			} else if (sort.equals("contactidd")) {
				sort = "contactId.keyword:" + "desc";
			}
			if (sort.equals("contactnamea")) {
				sort = "contactName.keyword:" + "asc";
			} else if (sort.equals("contactnamed")) {
				sort = "contactName.keyword:" + "desc";
			}
			if (sort.equals("attachedbya")) {
				sort = "attachedBy.keyword:" + "asc";
			} else if (sort.equals("attachedbyd")) {
				sort = "attachedBy.keyword:" + "desc";
			}
			if (sort.equals("lastmodifieda")) {
				sort = "lastModified.keyword:" + "asc";
			} else if (sort.equals("lastmodifiedd")) {
				sort = "lastModified.keyword:" + "desc";
			}
			if (sort.equals("cvsentdatea")) {
				sort = "cvSentDate.keyword:" + "asc";
			} else if (sort.equals("cvsentdated")) {
				sort = "cvSentDate.keyword:" + "desc";
			}
			if (sort.equals("statuschangedatea")) {
				sort = "statusChangeDate.keyword:" + "asc";
			} else if (sort.equals("statuschangedated")) {
				sort = "statusChangeDate.keyword:" + "desc";
			}
			if (sort.equals("statusoutcomea")) {
				sort = "statusOutcome.keyword:" + "asc";
			} else if (sort.equals("statusoutcomed")) {
				sort = "statusOutcome.keyword:" + "desc";
			}
			if (sort.equals("changereasona")) {
				sort = "changeReason.keyword:" + "asc";
			} else if (sort.equals("changereasond")) {
				sort = "changeReason.keyword:" + "desc";
			}
			if (sort.equals("clientportalstatusa")) {
				sort = "clientPortalStatus.keyword:" + "asc";
			} else if (sort.equals("clientportalstatusd")) {
				sort = "clientPortalStatus.keyword:" + "desc";
			}
			
			if (sort.equals("clientsheetstatusa")) {
				sort = "clientSheetStatus.keyword:" + "asc";
			} else if (sort.equals("clientsheetstatusd")) {
				sort = "clientSheetStatus.keyword:" + "desc";
			}
			
			if (sort.equals("patestscorea")) {
				sort = "paTestScore.keyword:" + "asc";
			} else if (sort.equals("patestscored")) {
				sort = "paTestScore.keyword:" + "desc";
			}
			if (sort.equals("testscorea")) {
				sort = "testScore.keyword:" + "asc";
			} else if (sort.equals("testscored")) {
				sort = "testScore.keyword:" + "desc";
			}
			if (sort.equals("avgscorea")) {
				sort = "avgScore.keyword:" + "asc";
			} else if (sort.equals("avgscored")) {
				sort = "avgScore.keyword:" + "desc";
			}
			if (sort.equals("pageupida")) {
				sort = "pageUpId.keyword:" + "asc";
			} else if (sort.equals("pageupidd")) {
				sort = "pageUpId.keyword:" + "desc";
			}
			if (sort.equals("isclientSheeta")) {
				sort = "isClientSheet.keyword:" + "asc";
			} else if (sort.equals("isclientSheetd")) {
				sort = "isClientSheet.keyword:" + "desc";
			}
			
			if (sort.equals("ghstatusa")) {
				sort = "ghStatus.keyword:" + "asc";
			} else if (sort.equals("ghstatusd")) {
				sort = "ghStatus.keyword:" + "desc";
			}
			
			if (sort.equals("ghstatusida")) {
				sort = "ghStatusId.keyword:" + "asc";
			} else if (sort.equals("ghstatusidd")) {
				sort = "ghStatusId.keyword:" + "desc";
			}
	
			if (sort.equals("statusida")) {
				sort = "statusId.keyword:" + "asc";
			} else if (sort.equals("statusidd")) {
				sort = "statusId.keyword:" + "desc";
			}
			
			if (sort.equals("commenta")) {
				sort = "comment.keyword:" + "asc";
			} else if (sort.equals("commentd")) {
				sort = "comment.keyword:" + "desc";
			}
			if (sort.equals("withoutida")) {
				sort = "withOutId.keyword:" + "asc";
			} else if (sort.equals("withoutidd")) {
				sort = "withOutId.keyword:" + "desc";
			}
			if (sort.equals("federateda")) {
				sort =  "federated.keyword:" +"asc";
			}else if (sort.equals("federatedd")) {
				sort = "federated.keyword:" + "desc";
			}

			urlAttach = urlAttach + "&sort=" + sort;

		}

		urlAttach = urlAttach
				+ "&pretty=true&_source=federated,id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,lastModifiedBy,lastModified,createdDate,anchor,anchorId,cvSentDate,statusChangeDate,statusOutcome,changeReason,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId";// resume

		System.out.println("urlAttach>> " + urlAttach);

		JSONParser jsonParserAttach = new JSONParser();
		String attach = restTemplate.getForObject(urlAttach, String.class);
		org.json.simple.JSONObject jsonAttach = (org.json.simple.JSONObject) ((org.json.simple.JSONObject) jsonParserAttach
				.parse(attach)).get("hits");

		org.json.simple.JSONArray arrayAtach = (org.json.simple.JSONArray) jsonAttach.get("hits");
		Iterator itratorcan = arrayAtach.iterator();

		String ids = "";
		AttachCount e1 = new AttachCount();

		while (itratorcan.hasNext()) {
			AttachCount e = new AttachCount();

			org.json.simple.JSONObject jsonObjectAttach = (org.json.simple.JSONObject) itratorcan.next();
			jsonObjectAttach = (org.json.simple.JSONObject) jsonObjectAttach.get("_source");

			id = (String) jsonObjectAttach.get("id");
			e.setId(id);

			objectId = (String) jsonObjectAttach.get("objectId");
			e.setObjectId(objectId);

			jobIdd = (String) jsonObjectAttach.get("jobId");
			e.setJobId(jobIdd);
			// can

			ids = ids + "," + objectId;

			if (jsonObjectAttach.get("dropComment") != null) {
				dropComment = (String) jsonObjectAttach.get("dropComment");
				e.setDropComment(dropComment);
			} else {
				dropComment = (String) jsonObjectAttach.get("dropComment");
			}
			if (jsonObjectAttach.get("lastModifiedBy") != null) {
				lastModifiedBy = (String) jsonObjectAttach.get("lastModifiedBy");
				e.setLastModifiedBy(lastModifiedBy);
			} else {
				lastModifiedBy = (String) jsonObjectAttach.get("lastModifiedBy");
			}
			if (jsonObjectAttach.get("createdDate") != null) {
				createdDate = (String) jsonObjectAttach.get("createdDate");
				e.setCreatedDate(createdDate);
			} else {
				createdDate = (String) jsonObjectAttach.get("createdDate");
			}
			if (jsonObjectAttach.get("anchor") != null) {
				anchor = (String) jsonObjectAttach.get("anchor");
				e.setAnchor(anchor);
			} else {
				anchor = (String) jsonObjectAttach.get("anchor");
			}
			
			if (jsonObjectAttach.get("status") != null) {
				status = (String) jsonObjectAttach.get("status");
				e.setStatus(status);
			} else {
				status = (String) jsonObjectAttach.get("status");
			}
			if (jsonObjectAttach.get("jobName") != null) {
				jobName = (String) jsonObjectAttach.get("jobName");
				e.setJobName(jobName);
			} else {
				jobName = (String) jsonObjectAttach.get("jobName");
			}
			if (jsonObjectAttach.get("clientId") != null) {
				clientId = (String) jsonObjectAttach.get("clientId");
				e.setClientId(clientId);
			} else {
				clientId = (String) jsonObjectAttach.get("clientId");
			}
			if (jsonObjectAttach.get("clientName") != null) {
				clientName = (String) jsonObjectAttach.get("clientName");
				e.setClientName(clientName);
			} else {
				clientName = (String) jsonObjectAttach.get("clientName");
			}
			if (jsonObjectAttach.get("contactId") != null) {
				contactId = (String) jsonObjectAttach.get("contactId");
				e.setContactId(contactId);
			} else {
				contactId = (String) jsonObjectAttach.get("contactId");
			}
			if (jsonObjectAttach.get("contactName") != null) {
				contactName = (String) jsonObjectAttach.get("contactName");
				e.setContactName(contactName);
			} else {
				contactName = (String) jsonObjectAttach.get("contactName");
			}
			if (jsonObjectAttach.get("attachedBy") != null) {
				attachedBy = (String) jsonObjectAttach.get("attachedBy");
				e.setAttachedBy(attachedBy);
			} else {
				attachedBy = (String) jsonObjectAttach.get("attachedBy");
			}
			if (jsonObjectAttach.get("lastModified") != null) {
				lastModified = (String) jsonObjectAttach.get("lastModified");
				e.setLastModified(lastModified);
			} else {
				lastModified = (String) jsonObjectAttach.get("lastModified");
			}
			if (jsonObjectAttach.get("cvSentDate") != null) {
				cvSentDate = (String) jsonObjectAttach.get("cvSentDate");
				e.setCvSentDate(cvSentDate);
			} else {
				cvSentDate = (String) jsonObjectAttach.get("cvSentDate");
			}
			if (jsonObjectAttach.get("statusChangeDate") != null) {
				statusChangeDate = (String) jsonObjectAttach.get("statusChangeDate");
				e.setStatusChangeDate(statusChangeDate);
			} else {
				statusChangeDate = (String) jsonObjectAttach.get("statusChangeDate");
			}
			if (jsonObjectAttach.get("statusOutcome") != null) {
				statusOutcome = (String) jsonObjectAttach.get("statusOutcome");
				e.setStatusOutcome(statusOutcome);
			} else {
				statusOutcome = (String) jsonObjectAttach.get("statusOutcome");
			}
			if (jsonObjectAttach.get("changeReason") != null) {
				changeReason = (String) jsonObjectAttach.get("changeReason");
				e.setChangeReason(changeReason);
			} else {
				changeReason = (String) jsonObjectAttach.get("changeReason");
			}
			if (jsonObjectAttach.get("clientPortalStatus") != null) {
				clientPortalStatus = (String) jsonObjectAttach.get("clientPortalStatus");
				e.setClientPortalStatus(clientPortalStatus);
			} else {
				clientPortalStatus = (String) jsonObjectAttach.get("clientPortalStatus");
			}
			if (jsonObjectAttach.get("clientSheetStatus") !=null) {
				clientSheetStatus = (String) jsonObjectAttach.get("clientSheetStatus");
				e.setClientSheetStatus(clientSheetStatus);
			}else {
				clientSheetStatus = (String) jsonObjectAttach.get("clientSheetStatus");
			}
			
			if (jsonObjectAttach.get("paTestScore") != null) {
				paTestScore = (String) jsonObjectAttach.get("paTestScore");
				e.setPaTestScore(paTestScore);
			} else {
				paTestScore = (String) jsonObjectAttach.get("paTestScore");
			}
			if (jsonObjectAttach.get("testScore") != null) {
				testScore = (String) jsonObjectAttach.get("testScore");
				e.setTestScore(testScore);
			} else {
				testScore = (String) jsonObjectAttach.get("testScore");
			}
			if (jsonObjectAttach.get("avgScore") != null) {
				avgScore = (String) jsonObjectAttach.get("avgScore");
				e.setAvgScore(avgScore);
			} else {
				avgScore = (String) jsonObjectAttach.get("avgScore");
			}
			if (jsonObjectAttach.get("pageUpId") != null) {
				pageUpId = (Long) jsonObjectAttach.get("pageUpId");
				e.setPageUpId(pageUpId);
			} else {
				pageUpId = (Long) jsonObjectAttach.get("pageUpId");
			}
			if (jsonObjectAttach.get("isClientSheet") !=null) {
				isClientSheet = (Long) jsonObjectAttach.get("isClientSheet");
				e.setIsClientSheet(isClientSheet);
			}else {
				isClientSheet = (Long) jsonObjectAttach.get("isClientSheet");
			}
			
				
			if (jsonObjectAttach.get("ghStatus") != null) {
				ghStatus = (String) jsonObjectAttach.get("ghStatus");
				e.setGhStatus(ghStatus);
			} else {
				ghStatus = (String) jsonObjectAttach.get("ghStatus");
			}
			
			if (jsonObjectAttach.get("ghStatusId") != null) {
				ghStatusId = (Long) jsonObjectAttach.get("ghStatusId");
				e.setGhStatusId(ghStatusId);
			} else {
				ghStatusId = (Long) jsonObjectAttach.get("ghStatusId");
			}
			
			if (jsonObjectAttach.get("statusId") != null) {
				statusId = (Long) jsonObjectAttach.get("statusId");
				e.setStatusId(statusId);
			} else {
				statusId = (Long) jsonObjectAttach.get("statusId");
			}
			
			if (jsonObjectAttach.get("comment") != null) {
				comment = (String) jsonObjectAttach.get("comment");
				e.setComment(comment);
			} else {
				jsonObjectAttach.get("comment");
			}
			if (jsonObjectAttach.get("withOutId") != null) {
				withOutId = (Long) jsonObjectAttach.get("withOutId");
				e.setWithOutId(withOutId);
			} else {
				withOutId = (Long) jsonObjectAttach.get("withOutId");
			}
			
			if (jsonObjectAttach.get("federated") != null) {
				federated = (String) jsonObjectAttach.get("federated");
				e.setFederated(federated);
			} else {
				federated = (String) jsonObjectAttach.get("federated");
			}
			

			list.add(e);

		}
		mainlist.add(list);

		ids = ids.replaceFirst(",", "");
		ids = ids.replace(",", ")OR(id:");

		if (ids.length() > 0)
			canlist = candidateExternalSearch(ids, sort, candidateQuery);

		mainlist.add(canlist);
		e1.setCandidate(mainlist);

		return mainlist;
	}

	/*
	 * Method to get formatted JSON
	 */

	public String getFormattedJson(String json) {

		JSONObject response = new JSONObject();
		JSONObject subResponse = new JSONObject();
		try {

			JSONArray attach = new JSONArray();

			JSONParser parser = new JSONParser();

			JSONObject jsonObj = (JSONObject) parser.parse(json);
			JSONArray jsonArray = (JSONArray) (((JSONObject) jsonObj.get("response")).get("attach"));

			if (jsonArray.size() >= 2) {
				JSONArray attachArray = (JSONArray) jsonArray.get(0);
				JSONArray candidateArray = (JSONArray) jsonArray.get(1);

				if (sortParam.equals("attach")) {

					for (int i = 0; i < attachArray.size(); i++) {
						JSONArray candidate = new JSONArray();
						JSONObject subCandidateJson = new JSONObject();
						JSONObject subAttachJson = new JSONObject();

						subAttachJson = (JSONObject) attachArray.get(i);

						subCandidateJson = getMappedData("" + subAttachJson.get("objectId"), candidateArray);

						if (subCandidateJson != null) {

							if (!subCandidateJson.containsKey("alternateEmail"))
								subCandidateJson.put("alternateEmail", org.json.JSONObject.NULL);
							subCandidateJson.put("alternateEmail", org.json.JSONObject.NULL);
							candidate.add(subCandidateJson);

							subAttachJson.put("candidate", candidate);
							attach.add(subAttachJson);
						}
					}

				} else if (sortParam.equals("candidate")) {

					for (int i = 0; i < candidateArray.size(); i++) {
						JSONArray candidate = new JSONArray();
						JSONObject subCandidateJson = new JSONObject();
						JSONObject subAttachJson = new JSONObject();

						subCandidateJson = (JSONObject) candidateArray.get(i);

						if (!subCandidateJson.containsKey("alternateEmail"))
							subCandidateJson.put("alternateEmail", org.json.JSONObject.NULL);
						candidate.add((candidateArray.get(i)));

						subAttachJson = getMappedData("" + subCandidateJson.get("id"), attachArray);
						subAttachJson.put("candidate", candidate);
						attach.add(subAttachJson);
					}
				}

				subResponse.put("numFound", attach.size());
				subResponse.put("attach", attach);
			}

			response.put("response", subResponse);

		} catch (ParseException e) {
			e.printStackTrace();
		}

		return response.toString();
	}

	public JSONObject getMappedData(String id, JSONArray array) {

		for (int i = 0; i < array.size(); i++) {

			if (sortParam.equals("attach") && ((String) ((JSONObject) array.get(i)).get("id")).equals(id))
				return (JSONObject) array.get(i);
			else if (sortParam.equals("candidate") && ((String) ((JSONObject) array.get(i)).get("objectId")).equals(id))
				return (JSONObject) array.get(i);

		}

		return null;
	}
}
