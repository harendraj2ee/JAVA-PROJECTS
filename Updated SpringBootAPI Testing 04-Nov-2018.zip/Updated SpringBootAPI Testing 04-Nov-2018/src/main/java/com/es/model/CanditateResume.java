package com.es.model;

import org.bson.types.Binary;

public class CanditateResume {
	
private String linkedin_html;
	
	private String resume=null;
	
	private Binary binaryData=null;
	
	//private String resume_data ="";
	private String filename="";
	
	
	//private int canId;
	private String objectid=""; 
	private String email="";
	private String first_name="";
	private String middle_name="";
	private String last_name="";
	private String name="";

	public String getObjectid() {
		return objectid;
	}
	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	

	


	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getMiddle_name() {
		return middle_name;
	}
	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLinkedin_html() {
		return linkedin_html;
	}

	public void setLinkedin_html(String linkedin_html) {
		this.linkedin_html = linkedin_html;
	}

	public Binary getBinaryData() {
		return binaryData;
	}

	public void setBinaryData(Binary binaryData) {
		this.binaryData = binaryData;
	}

	public String getResume() {
		return resume;
	}

	public void setResume(String resume) {
		this.resume = resume;
	}

//	public String getResume_data() {
//		return resume_data;
//	}
//
//	public void setResume_data(String string) {
//		this.resume_data = string;
//	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

}
