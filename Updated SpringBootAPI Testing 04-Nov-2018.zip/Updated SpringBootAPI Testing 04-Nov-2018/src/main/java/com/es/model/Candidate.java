package com.es.model;

import java.util.List;

public class Candidate {
		private String first_name="";
		private  String last_name="";
		private  String middle_name="";
		private String name="";
		private String email="";
		private String mobileNumber="";
		private String birthdate = "";
		private List<String> alternateEmail;
		
		
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		private String id="";
		
	/*	private Integer numFound= null;*/
	    @SuppressWarnings("unchecked")
		
		private List<Candidate> candidate; 
	    
		
	    
	    public String getBirthdate() {
			return birthdate;
		}
		public void setBirthdate(String birthdate) {
			this.birthdate = birthdate;
		}
		public List<String> getAlternateEmail() {
			return alternateEmail;
		}
		public void setAlternateEmail(List<String> alternateEmail) {
			this.alternateEmail = alternateEmail;
		}
		public String getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public String getFirst_name() {
			return first_name;
		}
		public void setFirst_name(String first_name) {
			this.first_name = first_name;
		}
		public String getLast_name() {
			return last_name;
		}
		public void setLast_name(String last_name) {
			this.last_name = last_name;
		}
		public String getMiddle_name() {
			return middle_name;
		}
		public void setMiddle_name(String middle_name) {
			this.middle_name = middle_name;
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name){
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public List<Candidate> getCandidate() {
			return candidate;
		}
		public void setCandidate(List<Candidate> candidate) {
			this.candidate = candidate;
		}
	/*	public Integer getNumFound() {
			return numFound;
		}
		public void setNumFound(Integer numFound) {
			this.numFound = numFound;
		}*/
		
		
		
		

}
