package com.es.resumeparse;

import java.util.List;

import com.es.bean.CanInfo;

public interface Restdao {
	
	//public List<RootConfig> getFileName(int id);
	
	public List<CanInfo> getValues(String fileName, String empId, String fedrated, String canId) throws Exception;
	
	public  List<CanInfo> getResumeValues(String fileName, String empId, String fedrated, String canId) throws Exception;
		
	}
