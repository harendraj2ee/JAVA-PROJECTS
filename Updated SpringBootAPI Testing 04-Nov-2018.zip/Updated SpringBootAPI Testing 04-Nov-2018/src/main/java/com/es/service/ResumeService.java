package com.es.service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.bson.Document;
import org.bson.types.Binary;
import org.bson.types.ObjectId;

import com.es.dbconnection.MongoConnection;
import com.es.dbconnection.MongoConnectionAttach;
import com.es.model.AttachResume;
import com.es.model.CanditateResume;
import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

public class ResumeService {
	
		
	public List<CanditateResume> getResumeDataElasticAPIMongo(String objectid) {
		List<CanditateResume> al=null;
		try{
			//System.out.println("ElasticAPI REsume ObjectId Mongodb");
			al = new ArrayList<CanditateResume>();
			
			MongoCollection<Document> collection = null;
			MongoConnection mcl = new MongoConnection();
			collection = mcl.getInstanceCandidate();
			//System.out.println("collection:::::::::::::"+collection);
			ObjectId id = new ObjectId(objectid);

			String linkedinhtml=null;
			BasicDBObject whereQuery = new BasicDBObject();
			whereQuery.put("_id", id);
			//whereQuery.put("_id", objectid);
			
			System.out.println("_id Query >> "+whereQuery);
			for (Document doc : collection.find(whereQuery)) {
				//System.out.println("doc >> "+doc);
				CanditateResume cd = new CanditateResume();
				String objectId = ""+doc.get("_id");
				String EmailId = ""+doc.getString("email");
				String firstname = ""+doc.getString("first_name");
				String middlename = ""+doc.getString("middle_name");
				String lastname =  ""+doc.getString("last_name");
				String name = ""+doc.getString("name");
				
				System.out.println("objectId >> "+objectId);
							
			if (doc.get("resume")!=null) {
				String filename = ""+doc.getString("resumeName");

				Binary b = (Binary) doc.get("resume");
					System.out.println("binary::::::"+b);
				    byte[] bytes = b.getData();
				    String data=  Base64.getEncoder().encodeToString(bytes);
				    String decodedData = new String(b.getData());
					InputStream is = null;
				    is = new ByteArrayInputStream(bytes);
				  
					cd.setFilename(filename);
					cd.setResume(data);
					cd.setObjectid(objectId);
					cd.setEmail(EmailId);
					cd.setFirst_name(firstname);
					cd.setMiddle_name(middlename);
					cd.setLast_name(lastname);
					cd.setName(name);
					
					al.add(cd);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return al;
	}
	
	
	//behalf of email
	
	public List<CanditateResume> getResumeHitechBrowser(String email) {
		List<CanditateResume> al=new ArrayList<CanditateResume>();
		try{
			//System.out.println("ElasticAPI REsume ObjectId Mongodb");
//			al = new ArrayList<CanditateResume>();
			
			
			MongoConnection mcl = new MongoConnection();
			MongoCollection<Document> collection  = mcl.getInstanceCandidate();
			//System.out.println("collection:::::::::::::"+collection);
			//ObjectId id = new ObjectId(objectid);

			//String linkedinhtml=null;
			BasicDBObject whereQuery = new BasicDBObject();
			whereQuery.put("email", email);
			//whereQuery.put("_id", objectid);
			CanditateResume cd = new CanditateResume();
            String objectId = "";
            String emailId = "";
            String firstname = "";
            String middlename = "";
            String lastname = "";
            String name = "";
            String filename = "";
            String data = "";
            System.out.println("email Query >> " + whereQuery);

            FindIterable<Document> document = collection.find(whereQuery);
            for (Document doc : document) {

                  objectId = "" + doc.get("_id");
                  emailId = doc.getString("email");
                  firstname = doc.getString("first_name");
                  middlename = doc.getString("middle_name");
                  lastname = doc.getString("last_name");
                  name = doc.getString("name");

                  filename = doc.getString("resumeName");

                  Binary b = (Binary) doc.get("resume");

                  if (b != null) {
                         byte[] bytes = b.getData();
                         data = Base64.getEncoder().encodeToString(bytes);
                  }

            }

            cd.setFilename(filename);
            cd.setResume(data);
            cd.setEmail(emailId);
            cd.setObjectid(objectId);
            cd.setFirst_name(firstname);
            cd.setMiddle_name(middlename);
            cd.setLast_name(lastname);
            cd.setName(name);
            al.add(cd);
     } catch (Exception e) {
            e.printStackTrace();
     }
     return al;
}

	
	
	
	public List<AttachResume> getResumeDataAttachMongo(String objectid) {
		List<AttachResume> al=null;
		try{
			//System.out.println("ElasticAPI REsume ObjectId Mongodb");
			al = new ArrayList<AttachResume>();
			
			MongoCollection<Document> collection = null;
			MongoConnectionAttach mcl = new MongoConnectionAttach();
			collection = mcl.getInstanceAttach();
			//System.out.println("collection:::::::::::::"+collection);
			ObjectId id = new ObjectId(objectid);

			String linkedinhtml=null;
			BasicDBObject whereQuery = new BasicDBObject();
			whereQuery.put("_id", id);
			//whereQuery.put("_id", objectid);
			
			System.out.println("_id Query >> "+whereQuery);
			for (Document doc : collection.find(whereQuery)) {
				//System.out.println("doc >> "+doc);
				AttachResume cd = new AttachResume();
				String objectId = ""+doc.get("_id");
				System.out.println("objectId Attach>> "+objectId);
							
			if (doc.get("resume")!=null) {
				String filename = ""+doc.getString("resumeName");
				Binary b = (Binary) doc.get("resume");
					System.out.println("binary Attach ::::::"+b);
				    byte[] bytes = b.getData();
				    String data=  Base64.getEncoder().encodeToString(bytes);
				    String decodedData = new String(b.getData());
					InputStream is = null;
				    is = new ByteArrayInputStream(bytes);
				  
					cd.setFilename(filename);
					cd.setResume(data);
					cd.setObjectid(objectId);
					
					al.add(cd);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return al;
	}

}
