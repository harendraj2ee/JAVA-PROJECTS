package com.es.bean;

public class CanInfo {
	
	private String firstName;
	private String midName;
	private String lastName;
	private String gender;
	private String pincode;
	private String dob;
	private String designation;
	private String eduBasic;
	private String eduMaster;
	private String eduDoc;
	private String mStatus;
	private String currentCtc;
	private String location;
	private String country;
	private String state;
	private String mob;
	private String email;
	private String altrMob;
	private String altrEmail;
	private String skill;
	private String passportNum;
	private String pancard;
	private String employer;
	private String certification;
	private String address;
	private String language;
	private String totalExp;
	private String age;
	
	private String SkillsPath;
	private String name ="";
	
	
	
	
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSkillsPath() {
		return SkillsPath;
	}
	public void setSkillsPath(String skillsPath) {
		SkillsPath = skillsPath;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMidName() {
		return midName;
	}
	public void setMidName(String midName) {
		this.midName = midName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getEduBasic() {
		return eduBasic;
	}
	public void setEduBasic(String eduBasic) {
		this.eduBasic = eduBasic;
	}
	public String getEduMaster() {
		return eduMaster;
	}
	public void setEduMaster(String eduMaster) {
		this.eduMaster = eduMaster;
	}
	public String getEduDoc() {
		return eduDoc;
	}
	public void setEduDoc(String eduDoc) {
		this.eduDoc = eduDoc;
	}
	public String getmStatus() {
		return mStatus;
	}
	public void setmStatus(String mStatus) {
		this.mStatus = mStatus;
	}
	public String getCurrentCtc() {
		return currentCtc;
	}
	public void setCurrentCtc(String currentCtc) {
		this.currentCtc = currentCtc;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getPassportNum() {
		return passportNum;
	}
	public void setPassportNum(String passportNum) {
		this.passportNum = passportNum;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getEmployer() {
		return employer;
	}
	public void setEmployer(String employer) {
		this.employer = employer;
	}
	public String getCertification() {
		return certification;
	}
	public void setCertification(String certification) {
		this.certification = certification;
	}
	public String getAltrMob() {
		return altrMob;
	}
	public void setAltrMob(String altrMob) {
		this.altrMob = altrMob;
	}
	public String getAltrEmail() {
		return altrEmail;
	}
	public void setAltrEmail(String altrEmail) {
		this.altrEmail = altrEmail;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getTotalExp() {
		return totalExp;
	}
	public void setTotalExp(String totalExp) {
		this.totalExp = totalExp;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	
	

}
